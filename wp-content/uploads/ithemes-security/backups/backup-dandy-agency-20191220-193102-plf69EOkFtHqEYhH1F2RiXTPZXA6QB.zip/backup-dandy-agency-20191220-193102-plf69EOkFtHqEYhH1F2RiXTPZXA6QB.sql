CREATE TABLE IF NOT EXISTS `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `wp_itsec_distributed_storage` (
  `storage_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `storage_group` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `storage_key` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `storage_chunk` int(11) NOT NULL DEFAULT '0',
  `storage_data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `storage_updated` datetime NOT NULL,
  PRIMARY KEY (`storage_id`),
  UNIQUE KEY `storage_group__key__chunk` (`storage_group`,`storage_key`,`storage_chunk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



CREATE TABLE IF NOT EXISTS `wp_itsec_lockouts` (
  `lockout_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lockout_type` varchar(20) NOT NULL,
  `lockout_start` datetime NOT NULL,
  `lockout_start_gmt` datetime NOT NULL,
  `lockout_expire` datetime NOT NULL,
  `lockout_expire_gmt` datetime NOT NULL,
  `lockout_host` varchar(40) DEFAULT NULL,
  `lockout_user` bigint(20) unsigned DEFAULT NULL,
  `lockout_username` varchar(60) DEFAULT NULL,
  `lockout_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`lockout_id`),
  KEY `lockout_expire_gmt` (`lockout_expire_gmt`),
  KEY `lockout_host` (`lockout_host`),
  KEY `lockout_user` (`lockout_user`),
  KEY `lockout_username` (`lockout_username`),
  KEY `lockout_active` (`lockout_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE IF NOT EXISTS `wp_itsec_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_type` varchar(20) NOT NULL DEFAULT '',
  `log_function` varchar(255) NOT NULL DEFAULT '',
  `log_priority` int(2) NOT NULL DEFAULT '1',
  `log_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_host` varchar(20) DEFAULT NULL,
  `log_username` varchar(20) DEFAULT NULL,
  `log_user` bigint(20) unsigned DEFAULT NULL,
  `log_url` varchar(255) DEFAULT NULL,
  `log_referrer` varchar(255) DEFAULT NULL,
  `log_data` longtext NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `log_type` (`log_type`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=20333 DEFAULT CHARSET=utf8;



CREATE TABLE IF NOT EXISTS `wp_itsec_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `module` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `code` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'notice',
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `init_timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `memory_current` bigint(20) unsigned NOT NULL DEFAULT '0',
  `memory_peak` bigint(20) unsigned NOT NULL DEFAULT '0',
  `url` varchar(500) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `remote_ip` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `module` (`module`),
  KEY `code` (`code`),
  KEY `type` (`type`),
  KEY `timestamp` (`timestamp`),
  KEY `user_id` (`user_id`),
  KEY `blog_id` (`blog_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



CREATE TABLE IF NOT EXISTS `wp_itsec_temp` (
  `temp_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `temp_type` varchar(20) NOT NULL,
  `temp_date` datetime NOT NULL,
  `temp_date_gmt` datetime NOT NULL,
  `temp_host` varchar(40) DEFAULT NULL,
  `temp_user` bigint(20) unsigned DEFAULT NULL,
  `temp_username` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`temp_id`),
  KEY `temp_date_gmt` (`temp_date_gmt`),
  KEY `temp_host` (`temp_host`),
  KEY `temp_user` (`temp_user`),
  KEY `temp_username` (`temp_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE IF NOT EXISTS `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=63929 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_options` VALUES ("1","siteurl","https://www.wearedandy.com","yes");
INSERT INTO `wp_options` VALUES ("2","blogname","Dandy Agency","yes");
INSERT INTO `wp_options` VALUES ("3","blogdescription","","yes");
INSERT INTO `wp_options` VALUES ("4","users_can_register","0","yes");
INSERT INTO `wp_options` VALUES ("5","admin_email","guille070@gmail.com","yes");
INSERT INTO `wp_options` VALUES ("6","start_of_week","1","yes");
INSERT INTO `wp_options` VALUES ("7","use_balanceTags","0","yes");
INSERT INTO `wp_options` VALUES ("8","use_smilies","1","yes");
INSERT INTO `wp_options` VALUES ("9","require_name_email","1","yes");
INSERT INTO `wp_options` VALUES ("10","comments_notify","","yes");
INSERT INTO `wp_options` VALUES ("11","posts_per_rss","10","yes");
INSERT INTO `wp_options` VALUES ("12","rss_use_excerpt","0","yes");
INSERT INTO `wp_options` VALUES ("13","mailserver_url","mail.example.com","yes");
INSERT INTO `wp_options` VALUES ("14","mailserver_login","login@example.com","yes");
INSERT INTO `wp_options` VALUES ("15","mailserver_pass","password","yes");
INSERT INTO `wp_options` VALUES ("16","mailserver_port","110","yes");
INSERT INTO `wp_options` VALUES ("17","default_category","1","yes");
INSERT INTO `wp_options` VALUES ("18","default_comment_status","closed","yes");
INSERT INTO `wp_options` VALUES ("19","default_ping_status","closed","yes");
INSERT INTO `wp_options` VALUES ("20","default_pingback_flag","","yes");
INSERT INTO `wp_options` VALUES ("21","posts_per_page","10","yes");
INSERT INTO `wp_options` VALUES ("22","date_format","j F, Y","yes");
INSERT INTO `wp_options` VALUES ("23","time_format","g:i a","yes");
INSERT INTO `wp_options` VALUES ("24","links_updated_date_format","j F, Y g:i a","yes");
INSERT INTO `wp_options` VALUES ("28","comment_moderation","1","yes");
INSERT INTO `wp_options` VALUES ("29","moderation_notify","","yes");
INSERT INTO `wp_options` VALUES ("30","permalink_structure","/%postname%/","yes");
INSERT INTO `wp_options` VALUES ("32","hack_file","0","yes");
INSERT INTO `wp_options` VALUES ("33","blog_charset","UTF-8","yes");
INSERT INTO `wp_options` VALUES ("34","moderation_keys","","no");
INSERT INTO `wp_options` VALUES ("35","active_plugins","a:12:{i:0;s:57:\"acf-content-analysis-for-yoast-seo/yoast-acf-analysis.php\";i:2;s:30:\"advanced-custom-fields/acf.php\";i:3;s:27:\"autoptimize/autoptimize.php\";i:4;s:41:\"better-wp-security/better-wp-security.php\";i:5;s:32:\"custom-post-type-works/works.php\";i:6;s:25:\"qtranslate/qtranslate.php\";i:7;s:21:\"raw-html/raw_html.php\";i:8;s:53:\"simple-custom-post-order/simple-custom-post-order.php\";i:9;s:51:\"thumbnail-crop-position/thumbnail-crop-position.php\";i:10;s:27:\"updraftplus/updraftplus.php\";i:11;s:24:\"wordpress-seo/wp-seo.php\";i:12;s:23:\"wp-smushit/wp-smush.php\";}","yes");
INSERT INTO `wp_options` VALUES ("36","home","https://www.wearedandy.com","yes");
INSERT INTO `wp_options` VALUES ("37","category_base","","yes");
INSERT INTO `wp_options` VALUES ("38","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `wp_options` VALUES ("40","comment_max_links","2","yes");
INSERT INTO `wp_options` VALUES ("41","gmt_offset","0","yes");
INSERT INTO `wp_options` VALUES ("42","default_email_category","1","yes");
INSERT INTO `wp_options` VALUES ("43","recently_edited","a:4:{i:0;s:72:\"/home/wearedandy/wearedandy.com/wp-content/themes/dandy-agency/style.css\";i:1;s:76:\"/home/wearedandy/wearedandy.com/wp-content/themes/dandy-agency/style.min.css\";i:3;s:86:\"/home/wearedandy/wearedandy.com/wp-content/themes/dandy-agency/parts/shared/footer.php\";i:4;s:0:\"\";}","no");
INSERT INTO `wp_options` VALUES ("44","template","dandy-agency","yes");
INSERT INTO `wp_options` VALUES ("45","stylesheet","dandy-agency","yes");
INSERT INTO `wp_options` VALUES ("46","comment_whitelist","1","yes");
INSERT INTO `wp_options` VALUES ("47","blacklist_keys","","no");
INSERT INTO `wp_options` VALUES ("48","comment_registration","1","yes");
INSERT INTO `wp_options` VALUES ("49","html_type","text/html","yes");
INSERT INTO `wp_options` VALUES ("50","use_trackback","0","yes");
INSERT INTO `wp_options` VALUES ("51","default_role","subscriber","yes");
INSERT INTO `wp_options` VALUES ("52","db_version","38590","yes");
INSERT INTO `wp_options` VALUES ("53","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `wp_options` VALUES ("54","upload_path","","yes");
INSERT INTO `wp_options` VALUES ("55","blog_public","1","yes");
INSERT INTO `wp_options` VALUES ("56","default_link_category","2","yes");
INSERT INTO `wp_options` VALUES ("57","show_on_front","page","yes");
INSERT INTO `wp_options` VALUES ("58","tag_base","","yes");
INSERT INTO `wp_options` VALUES ("59","show_avatars","","yes");
INSERT INTO `wp_options` VALUES ("60","avatar_rating","G","yes");
INSERT INTO `wp_options` VALUES ("61","upload_url_path","","yes");
INSERT INTO `wp_options` VALUES ("62","thumbnail_size_w","150","yes");
INSERT INTO `wp_options` VALUES ("63","thumbnail_size_h","150","yes");
INSERT INTO `wp_options` VALUES ("64","thumbnail_crop","1","yes");
INSERT INTO `wp_options` VALUES ("65","medium_size_w","300","yes");
INSERT INTO `wp_options` VALUES ("66","medium_size_h","300","yes");
INSERT INTO `wp_options` VALUES ("67","avatar_default","mystery","yes");
INSERT INTO `wp_options` VALUES ("68","large_size_w","1024","yes");
INSERT INTO `wp_options` VALUES ("69","large_size_h","1024","yes");
INSERT INTO `wp_options` VALUES ("70","image_default_link_type","file","yes");
INSERT INTO `wp_options` VALUES ("71","image_default_size","","yes");
INSERT INTO `wp_options` VALUES ("72","image_default_align","","yes");
INSERT INTO `wp_options` VALUES ("73","close_comments_for_old_posts","","yes");
INSERT INTO `wp_options` VALUES ("74","close_comments_days_old","14","yes");
INSERT INTO `wp_options` VALUES ("75","thread_comments","1","yes");
INSERT INTO `wp_options` VALUES ("76","thread_comments_depth","5","yes");
INSERT INTO `wp_options` VALUES ("77","page_comments","","yes");
INSERT INTO `wp_options` VALUES ("78","comments_per_page","50","yes");
INSERT INTO `wp_options` VALUES ("79","default_comments_page","newest","yes");
INSERT INTO `wp_options` VALUES ("80","comment_order","asc","yes");
INSERT INTO `wp_options` VALUES ("81","sticky_posts","a:0:{}","yes");
INSERT INTO `wp_options` VALUES ("82","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES ("83","widget_text","a:0:{}","yes");
INSERT INTO `wp_options` VALUES ("84","widget_rss","a:0:{}","yes");
INSERT INTO `wp_options` VALUES ("85","uninstall_plugins","a:5:{s:51:\"thumbnail-crop-position/thumbnail-crop-position.php\";s:13:\"tcp_uninstall\";s:41:\"better-wp-security/better-wp-security.php\";a:2:{i:0;s:10:\"ITSEC_Core\";i:1;s:16:\"handle_uninstall\";}s:35:\"qtranslate-slug/qtranslate-slug.php\";s:13:\"qts_uninstall\";s:53:\"simple-custom-post-order/simple-custom-post-order.php\";s:18:\"scporder_uninstall\";s:27:\"autoptimize/autoptimize.php\";s:29:\"autoptimizeMain::on_uninstall\";}","no");
INSERT INTO `wp_options` VALUES ("86","timezone_string","","yes");
INSERT INTO `wp_options` VALUES ("87","page_for_posts","0","yes");
INSERT INTO `wp_options` VALUES ("88","page_on_front","5","yes");
INSERT INTO `wp_options` VALUES ("89","default_post_format","0","yes");
INSERT INTO `wp_options` VALUES ("90","link_manager_enabled","0","yes");
INSERT INTO `wp_options` VALUES ("91","initial_db_version","26149","yes");
INSERT INTO `wp_options` VALUES ("92","wp_user_roles","a:7:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:62:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:35:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:13:\"wpseo_manager\";a:2:{s:4:\"name\";s:11:\"SEO Manager\";s:12:\"capabilities\";a:37:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:12:\"wpseo_editor\";a:2:{s:4:\"name\";s:10:\"SEO Editor\";s:12:\"capabilities\";a:36:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;}}}","yes");
INSERT INTO `wp_options` VALUES ("93","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES ("94","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES ("95","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES ("96","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES ("97","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES ("98","sidebars_widgets","a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:18:\"orphaned_widgets_1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `wp_options` VALUES ("99","cron","a:16:{i:1576869311;a:1:{s:10:\"itsec_cron\";a:1:{s:32:\"3ec3d6914daf50bcdb5e5b065213e29b\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:1:{i:0;s:17:\"purge-log-entries\";}s:8:\"interval\";i:86400;}}}i:1576869355;a:1:{s:12:\"qs_cron_hook\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1576871265;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1576879573;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1576879585;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1576901525;a:1:{s:15:\"itsec_cron_test\";a:1:{s:32:\"55ec3e698c276bc016759a321adffd07\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:1:{i:0;i:1576901525;}}}}i:1576940690;a:1:{s:16:\"itsec_purge_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1576953528;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1576954080;a:1:{s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1576954552;a:1:{s:19:\"wpseo-reindex-links\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1576954694;a:1:{s:15:\"ao_cachechecker\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1576954991;a:1:{s:10:\"itsec_cron\";a:1:{s:32:\"7a0fd5d064c59cf40c3df9ad0bb6e63d\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:1:{i:0;s:11:\"clear-locks\";}s:8:\"interval\";i:86400;}}}i:1576955171;a:1:{s:10:\"itsec_cron\";a:1:{s:32:\"aa768a35ceed34e467f270ebdc5d82f4\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:1:{i:0;s:14:\"purge-lockouts\";}s:8:\"interval\";i:86400;}}}i:1577300152;a:1:{s:18:\"wpseo_onpage_fetch\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1584645191;a:1:{s:10:\"itsec_cron\";a:1:{s:32:\"e0d50030fc9bde5ba86be99826a116eb\";a:3:{s:8:\"schedule\";s:12:\"itsec-backup\";s:4:\"args\";a:1:{i:0;s:6:\"backup\";}s:8:\"interval\";i:7776000;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `wp_options` VALUES ("102","_transient_random_seed","3b78dbb86e59ee5b62f8ebfa3f82dced","yes");
INSERT INTO `wp_options` VALUES ("103","auth_key","$6SX[{;KPzq6h&[AgQDT p>*P&.YttP_VIk,E*!Otx4$RQ3v5_6$%U,lIxCK[o;;","yes");
INSERT INTO `wp_options` VALUES ("104","auth_salt",")`{+CC7)sq3%eUW7FSEk,m)kbTZ>eS}w[HW%nv~nv^5oLd#k)^&N-o!(7#|~Hmo8","yes");
INSERT INTO `wp_options` VALUES ("105","logged_in_key","-Diy0*?709]b8&M/L3j2q<v4!CZG$nB/0]=(T}`l34G6>#]<{&vzlJ_|02}xf9N ","yes");
INSERT INTO `wp_options` VALUES ("106","logged_in_salt","z%QG!:G<uj j~lSCog$VAOxi^65-+cV.Li(:n7axX;qY57J@_^QExak_p,aH-j74","yes");
INSERT INTO `wp_options` VALUES ("107","nonce_key",",G=+C?p[m1tEX.FqE*h*Lt *,/4W?:$FFhWt-(62}^`3(|I=kqw}d&:eP2(6xoH0","yes");
INSERT INTO `wp_options` VALUES ("108","nonce_salt","A@6pJ5^<O~j@?WM#/m=$%1,1E%KP.Rjd])1dU g`}^YKc:XM#vW*~< fg&w=ua_-","yes");
INSERT INTO `wp_options` VALUES ("115","dashboard_widget_options","a:4:{s:25:\"dashboard_recent_comments\";a:1:{s:5:\"items\";i:5;}s:24:\"dashboard_incoming_links\";a:5:{s:4:\"home\";s:26:\"https://www.wearedandy.com\";s:4:\"link\";s:102:\"http://blogsearch.google.com/blogsearch?scoring=d&partner=wordpress&q=link:https://www.wearedandy.com/\";s:3:\"url\";s:134:\"http://blogsearch.google.com/blogsearch_feeds?scoring=d&ie=utf-8&num=10&output=rss&partner=wordpress&q=link:http://www.wearedandy.com/\";s:5:\"items\";i:10;s:9:\"show_date\";b:0;}s:17:\"dashboard_primary\";a:7:{s:4:\"link\";s:26:\"http://wordpress.org/news/\";s:3:\"url\";s:31:\"http://wordpress.org/news/feed/\";s:5:\"title\";s:22:\"Blog oficial WordPress\";s:5:\"items\";i:2;s:12:\"show_summary\";i:1;s:11:\"show_author\";i:0;s:9:\"show_date\";i:1;}s:19:\"dashboard_secondary\";a:7:{s:4:\"link\";s:28:\"http://planet.wordpress.org/\";s:3:\"url\";s:33:\"http://planet.wordpress.org/feed/\";s:5:\"title\";s:30:\"Otras noticias sobre WordPress\";s:5:\"items\";i:5;s:12:\"show_summary\";i:0;s:11:\"show_author\";i:0;s:9:\"show_date\";i:0;}}","yes");
INSERT INTO `wp_options` VALUES ("147","current_theme","Dandy Agency","yes");
INSERT INTO `wp_options` VALUES ("148","theme_mods_dandy-agency","a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:11:\"header-menu\";i:2;}s:18:\"custom_css_post_id\";i:-1;}","yes");
INSERT INTO `wp_options` VALUES ("149","theme_switched","","yes");
INSERT INTO `wp_options` VALUES ("150","recently_activated","a:1:{s:45:\"acf-flexible-content/acf-flexible-content.php\";i:1537989367;}","yes");
INSERT INTO `wp_options` VALUES ("151","thumb_crop_position_option","a:1:{s:8:\"position\";i:4;}","yes");
INSERT INTO `wp_options` VALUES ("152","scporder_options","a:1:{s:7:\"objects\";a:3:{i:0;s:4:\"post\";i:1;s:4:\"page\";i:2;s:5:\"works\";}}","yes");
INSERT INTO `wp_options` VALUES ("153","acf_version","5.7.6","yes");
INSERT INTO `wp_options` VALUES ("314","itsec_four_oh_four","a:5:{s:7:\"enabled\";b:1;s:12:\"check_period\";i:5;s:15:\"error_threshold\";i:20;s:10:\"white_list\";a:9:{i:0;s:12:\"/favicon.ico\";i:1;s:11:\"/robots.txt\";i:2;s:21:\"/apple-touch-icon.png\";i:3;s:33:\"/apple-touch-icon-precomposed.png\";i:4;s:17:\"/wp-content/cache\";i:5;s:18:\"/browserconfig.xml\";i:6;s:16:\"/crossdomain.xml\";i:7;s:11:\"/labels.rdf\";i:8;s:27:\"/trafficbasedsspsitemap.xml\";}s:5:\"types\";a:5:{i:0;s:4:\".jpg\";i:1;s:5:\".jpeg\";i:2;s:4:\".png\";i:3;s:4:\".gif\";i:4;s:4:\".css\";}}","yes");
INSERT INTO `wp_options` VALUES ("315","itsec_away_mode","a:4:{s:4:\"type\";i:1;s:7:\"enabled\";b:0;s:5:\"start\";i:1492473600;s:3:\"end\";i:1492581600;}","yes");
INSERT INTO `wp_options` VALUES ("318","itsec_brute_force","a:5:{s:7:\"enabled\";b:1;s:17:\"max_attempts_host\";i:5;s:17:\"max_attempts_user\";i:10;s:12:\"check_period\";i:5;s:14:\"auto_ban_admin\";b:0;}","yes");
INSERT INTO `wp_options` VALUES ("320","itsec_file_change","a:9:{s:6:\"method\";b:1;s:9:\"file_list\";a:1:{i:0;s:0:\"\";}s:5:\"types\";a:6:{i:0;s:4:\".jpg\";i:1;s:5:\".jpeg\";i:2;s:4:\".png\";i:3;s:4:\".log\";i:4;s:3:\".mo\";i:5;s:3:\".po\";}s:5:\"email\";b:1;s:12:\"notify_admin\";b:1;s:7:\"enabled\";b:0;s:5:\"split\";b:0;s:10:\"last_chunk\";b:0;s:8:\"last_run\";i:1492370324;}","yes");
INSERT INTO `wp_options` VALUES ("323","itsec_ssl","a:3:{s:8:\"frontend\";i:0;s:5:\"login\";b:0;s:5:\"admin\";b:0;}","yes");
INSERT INTO `wp_options` VALUES ("325","itsec_strong_passwords","a:2:{s:7:\"enabled\";b:1;s:4:\"roll\";s:13:\"administrator\";}","yes");
INSERT INTO `wp_options` VALUES ("326","itsec_tweaks","a:22:{s:13:\"protect_files\";b:1;s:18:\"directory_browsing\";b:1;s:13:\"generator_tag\";b:1;s:18:\"wlwmanifest_header\";b:1;s:14:\"edituri_header\";b:1;s:12:\"comment_spam\";b:1;s:14:\"disable_xmlrpc\";i:1;s:12:\"login_errors\";b:1;s:21:\"force_unique_nicename\";b:1;s:27:\"disable_unused_author_pages\";b:1;s:15:\"request_methods\";b:0;s:24:\"suspicious_query_strings\";b:0;s:22:\"non_english_characters\";b:0;s:16:\"long_url_strings\";b:0;s:17:\"write_permissions\";b:0;s:13:\"theme_updates\";b:0;s:14:\"plugin_updates\";b:0;s:12:\"core_updates\";b:0;s:14:\"random_version\";b:0;s:11:\"file_editor\";b:0;s:11:\"uploads_php\";b:0;s:11:\"safe_jquery\";b:0;}","yes");
INSERT INTO `wp_options` VALUES ("339","nav_menu_options","a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES ("397","qtranslate_next_update_mo","1421158606","yes");
INSERT INTO `wp_options` VALUES ("399","qtranslate_qtranslate_services","0","yes");
INSERT INTO `wp_options` VALUES ("400","qtranslate_default_language","en","yes");
INSERT INTO `wp_options` VALUES ("401","qtranslate_flag_location","plugins/qtranslate/flags/","yes");
INSERT INTO `wp_options` VALUES ("402","qtranslate_ignore_file_types","gif,jpg,jpeg,png,pdf,swf,tif,rar,zip,7z,mpg,divx,mpeg,avi,css,js","yes");
INSERT INTO `wp_options` VALUES ("403","qtranslate_detect_browser_language","0","yes");
INSERT INTO `wp_options` VALUES ("404","qtranslate_hide_untranslated","0","yes");
INSERT INTO `wp_options` VALUES ("405","qtranslate_use_strftime","3","yes");
INSERT INTO `wp_options` VALUES ("406","qtranslate_url_mode","2","yes");
INSERT INTO `wp_options` VALUES ("407","qtranslate_auto_update_mo","0","yes");
INSERT INTO `wp_options` VALUES ("408","qtranslate_hide_default_language","1","yes");
INSERT INTO `wp_options` VALUES ("409","qtranslate_language_names","a:2:{s:2:\"en\";s:7:\"English\";s:2:\"es\";s:8:\"Español\";}","yes");
INSERT INTO `wp_options` VALUES ("410","qtranslate_enabled_languages","a:2:{i:0;s:2:\"en\";i:1;s:2:\"es\";}","yes");
INSERT INTO `wp_options` VALUES ("411","qtranslate_flags","a:2:{s:2:\"en\";s:6:\"gb.png\";s:2:\"es\";s:6:\"es.png\";}","yes");
INSERT INTO `wp_options` VALUES ("412","qtranslate_locales","a:2:{s:2:\"en\";s:5:\"en_US\";s:2:\"es\";s:5:\"es_ES\";}","yes");
INSERT INTO `wp_options` VALUES ("413","qtranslate_na_messages","a:2:{s:2:\"en\";s:55:\"Sorry, this entry is only available in %LANG:, : and %.\";s:2:\"es\";s:68:\"Disculpa, pero esta entrada está disponible sólo en %LANG:, : y %.\";}","yes");
INSERT INTO `wp_options` VALUES ("414","qtranslate_date_formats","a:2:{s:2:\"en\";s:14:\"%A %B %e%q, %Y\";s:2:\"es\";s:14:\"%d de %B de %Y\";}","yes");
INSERT INTO `wp_options` VALUES ("415","qtranslate_time_formats","a:2:{s:2:\"en\";s:8:\"%I:%M %p\";s:2:\"es\";s:10:\"%H:%M hrs.\";}","yes");
INSERT INTO `wp_options` VALUES ("416","qtranslate_term_name","a:0:{}","yes");
INSERT INTO `wp_options` VALUES ("691","qts_options","a:4:{s:11:\"_qts_styles\";s:4:\"file\";s:20:\"_qts_post_type_works\";a:2:{s:2:\"en\";s:0:\"\";s:2:\"es\";s:0:\"\";}s:22:\"_qts_taxonomy_category\";a:2:{s:2:\"en\";s:0:\"\";s:2:\"es\";s:0:\"\";}s:22:\"_qts_taxonomy_post_tag\";a:2:{s:2:\"en\";s:0:\"\";s:2:\"es\";s:0:\"\";}}","yes");
INSERT INTO `wp_options` VALUES ("692","qts_version","1.1.12","yes");
INSERT INTO `wp_options` VALUES ("759","txfx_plt_schema_version","3","yes");
INSERT INTO `wp_options` VALUES ("929","category_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES ("1208","theme_mods_twentythirteen","a:1:{s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1426278310;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:18:\"orphaned_widgets_1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:18:\"orphaned_widgets_2\";a:0:{}}}}","yes");
INSERT INTO `wp_options` VALUES ("38393","secure_auth_key",".7^Xs]rlgF[Wa7B@xSxmG~^50*l2BlRTJW5^!9^N?`V<C!L5.Lt%WLmGls!FwLZ6","yes");
INSERT INTO `wp_options` VALUES ("38394","secure_auth_salt","n@)obS-JzB6hwuD/0%Rwkmduq9m<I`5%sqSX@l2bYVO[<nS,~pX~=flzs*`-uS6V","yes");
INSERT INTO `wp_options` VALUES ("38398","updraftplus_tour_cancelled_on","intro","yes");
INSERT INTO `wp_options` VALUES ("38399","updraftplus_version","1.15.2","yes");
INSERT INTO `wp_options` VALUES ("38400","updraft_updraftvault","a:2:{s:7:\"version\";i:1;s:8:\"settings\";a:1:{s:34:\"s-bddc23327d01dfc995a83f1896b4c5ff\";a:3:{s:5:\"token\";s:0:\"\";s:5:\"email\";s:0:\"\";s:5:\"quota\";i:-1;}}}","yes");
INSERT INTO `wp_options` VALUES ("38401","updraft_dropbox","a:2:{s:7:\"version\";i:1;s:8:\"settings\";a:1:{s:34:\"s-d32693a3df1921766a0a1dc95a3464f1\";a:4:{s:6:\"appkey\";s:0:\"\";s:6:\"secret\";s:0:\"\";s:6:\"folder\";s:0:\"\";s:15:\"tk_access_token\";s:0:\"\";}}}","yes");
INSERT INTO `wp_options` VALUES ("38402","updraft_s3","a:2:{s:7:\"version\";i:1;s:8:\"settings\";a:1:{s:34:\"s-2024d22f808f7c05380d9e1d135d2389\";a:5:{s:9:\"accesskey\";s:0:\"\";s:9:\"secretkey\";s:0:\"\";s:4:\"path\";s:0:\"\";s:3:\"rrs\";s:0:\"\";s:22:\"server_side_encryption\";s:0:\"\";}}}","yes");
INSERT INTO `wp_options` VALUES ("38403","updraft_cloudfiles","a:2:{s:7:\"version\";i:1;s:8:\"settings\";a:1:{s:34:\"s-7a2e5826da6bb7897125c8a5ccf6df59\";a:5:{s:4:\"user\";s:0:\"\";s:7:\"authurl\";s:35:\"https://auth.api.rackspacecloud.com\";s:6:\"apikey\";s:0:\"\";s:4:\"path\";s:0:\"\";s:6:\"region\";N;}}}","yes");
INSERT INTO `wp_options` VALUES ("38404","updraft_googledrive","a:2:{s:7:\"version\";i:1;s:8:\"settings\";a:1:{s:34:\"s-fab4581327c843cfccb8b396293bf9c0\";a:3:{s:8:\"clientid\";s:0:\"\";s:6:\"secret\";s:0:\"\";s:5:\"token\";s:0:\"\";}}}","yes");
INSERT INTO `wp_options` VALUES ("38405","updraft_onedrive","a:2:{s:7:\"version\";i:1;s:8:\"settings\";a:1:{s:34:\"s-d5df8955c46c779e0a64afff7c315f5f\";a:0:{}}}","yes");
INSERT INTO `wp_options` VALUES ("38406","updraft_ftp","a:2:{s:7:\"version\";i:1;s:8:\"settings\";a:1:{s:34:\"s-1e1284d8055baafe6a5f28e73e648f3e\";a:5:{s:4:\"host\";s:0:\"\";s:4:\"user\";s:0:\"\";s:4:\"pass\";s:0:\"\";s:4:\"path\";s:0:\"\";s:7:\"passive\";i:1;}}}","yes");
INSERT INTO `wp_options` VALUES ("38407","updraft_azure","a:2:{s:7:\"version\";i:1;s:8:\"settings\";a:1:{s:34:\"s-38e18069e4e85bf90560ea84129ccc19\";a:0:{}}}","yes");
INSERT INTO `wp_options` VALUES ("38408","updraft_sftp","a:2:{s:7:\"version\";i:1;s:8:\"settings\";a:1:{s:34:\"s-616b8cf7d84569099b4deeeddb38aae6\";a:0:{}}}","yes");
INSERT INTO `wp_options` VALUES ("38409","updraft_googlecloud","a:2:{s:7:\"version\";i:1;s:8:\"settings\";a:1:{s:34:\"s-1f2dbf6c62de58b70475654ae039ec37\";a:0:{}}}","yes");
INSERT INTO `wp_options` VALUES ("38410","updraft_backblaze","a:2:{s:7:\"version\";i:1;s:8:\"settings\";a:1:{s:34:\"s-fe894ecdd72f189783765661e610714e\";a:0:{}}}","yes");
INSERT INTO `wp_options` VALUES ("38411","updraft_webdav","a:2:{s:7:\"version\";i:1;s:8:\"settings\";a:1:{s:34:\"s-704e15010216c95d93b1b83dfea9a1a6\";a:0:{}}}","yes");
INSERT INTO `wp_options` VALUES ("38412","updraft_s3generic","a:2:{s:7:\"version\";i:1;s:8:\"settings\";a:1:{s:34:\"s-ee4b5b671ac05fdb407e7869967ef817\";a:4:{s:9:\"accesskey\";s:0:\"\";s:9:\"secretkey\";s:0:\"\";s:4:\"path\";s:0:\"\";s:8:\"endpoint\";s:0:\"\";}}}","yes");
INSERT INTO `wp_options` VALUES ("38413","updraft_openstack","a:2:{s:7:\"version\";i:1;s:8:\"settings\";a:1:{s:34:\"s-322662362912f156a43ffe28edd4e73c\";a:6:{s:4:\"user\";s:0:\"\";s:7:\"authurl\";s:0:\"\";s:8:\"password\";s:0:\"\";s:6:\"tenant\";s:0:\"\";s:4:\"path\";s:0:\"\";s:6:\"region\";s:0:\"\";}}}","yes");
INSERT INTO `wp_options` VALUES ("38414","updraft_dreamobjects","a:2:{s:7:\"version\";i:1;s:8:\"settings\";a:1:{s:34:\"s-678754a26e767054a8984152446ee232\";a:3:{s:9:\"accesskey\";s:0:\"\";s:9:\"secretkey\";s:0:\"\";s:4:\"path\";s:0:\"\";}}}","yes");
INSERT INTO `wp_options` VALUES ("38415","updraftplus-addons_siteid","b4660bf71253958092644fb507e464de","yes");
INSERT INTO `wp_options` VALUES ("38416","updraft_lastmessage","The backup apparently succeeded and is now complete (Sep 26 19:25:14)","yes");
INSERT INTO `wp_options` VALUES ("38417","updraftplus_locked_fd","1","no");
INSERT INTO `wp_options` VALUES ("38418","updraftplus_last_lock_time_fd","2018-09-26 19:18:56","no");
INSERT INTO `wp_options` VALUES ("38419","updraftplus_semaphore_fd","1","no");
INSERT INTO `wp_options` VALUES ("38420","updraft_last_scheduled_fd","1537989536","yes");
INSERT INTO `wp_options` VALUES ("38423","updraft_backup_history","a:2:{i:1537989536;a:12:{s:7:\"plugins\";a:1:{i:0;s:60:\"backup_2018-09-26-1918_Dandy_Agency_680d299197b7-plugins.zip\";}s:12:\"plugins-size\";i:19124727;s:2:\"db\";s:54:\"backup_2018-09-26-1918_Dandy_Agency_680d299197b7-db.gz\";s:7:\"db-size\";i:244884;s:9:\"checksums\";a:2:{s:4:\"sha1\";a:2:{s:8:\"plugins0\";s:40:\"aec31536c0e6256bb2ea1faaa3270f7a5d460f10\";s:3:\"db0\";s:40:\"77ef93a4234af1bb710540c0acca550abe127b22\";}s:6:\"sha256\";a:2:{s:8:\"plugins0\";s:64:\"375a466f994ae341aeb71650081e20ae9fc533e2cc81d30c493cebb48dd6f77d\";s:3:\"db0\";s:64:\"213b96f9630607df464a156c73d1f151e1831476a720b341ccb5771d22c026a6\";}}s:5:\"nonce\";s:12:\"680d299197b7\";s:7:\"service\";a:1:{i:0;s:4:\"none\";}s:20:\"service_instance_ids\";a:0:{}s:11:\"always_keep\";b:0;s:19:\"files_enumerated_at\";a:1:{s:7:\"plugins\";i:1537989860;}s:18:\"created_by_version\";s:6:\"1.15.2\";s:12:\"is_multisite\";b:0;}i:1537987118;a:18:{s:7:\"plugins\";a:1:{i:0;s:60:\"backup_2018-09-26-1838_Dandy_Agency_18cd7b5958fb-plugins.zip\";}s:12:\"plugins-size\";i:9578562;s:6:\"themes\";a:1:{i:0;s:59:\"backup_2018-09-26-1838_Dandy_Agency_18cd7b5958fb-themes.zip\";}s:11:\"themes-size\";i:605685;s:7:\"uploads\";a:1:{i:0;s:60:\"backup_2018-09-26-1838_Dandy_Agency_18cd7b5958fb-uploads.zip\";}s:12:\"uploads-size\";i:65535815;s:6:\"others\";a:1:{i:0;s:59:\"backup_2018-09-26-1838_Dandy_Agency_18cd7b5958fb-others.zip\";}s:11:\"others-size\";i:505189;s:2:\"db\";s:54:\"backup_2018-09-26-1838_Dandy_Agency_18cd7b5958fb-db.gz\";s:7:\"db-size\";i:104651;s:9:\"checksums\";a:2:{s:4:\"sha1\";a:5:{s:8:\"plugins0\";s:40:\"645f6439087c39f894e2a8a84492aea19f096f07\";s:7:\"themes0\";s:40:\"92a8e6f0ceba06421f2ef2f262d9790a57c9641a\";s:8:\"uploads0\";s:40:\"04630ffeca5c86102761fd0b66bb49bd589249c2\";s:7:\"others0\";s:40:\"dd2dc5225e823779ee1b0260baadc0a99df26029\";s:3:\"db0\";s:40:\"7aaaa0968f27aa34082a20dc141072cad861df35\";}s:6:\"sha256\";a:5:{s:8:\"plugins0\";s:64:\"e1ce6116a3dd8e9a92b71f211beb1150fcbac8d9e5b55b305b1c07c7df40ec05\";s:7:\"themes0\";s:64:\"1bf2c45299e6f2362b38091a59211d2ef789151a438532a98ec0e56000437d51\";s:8:\"uploads0\";s:64:\"b6422cea5a984d175ce262b01d69ea67eea62840f11fa267334252fed7ecbf01\";s:7:\"others0\";s:64:\"831c81b8569959aa8112c26cb7e4c1fb080a34029ab916f688dc69df86d2dbe5\";s:3:\"db0\";s:64:\"c84683d5329eddefda871281085c77fa24fbcb83935f08068c09a2aefed112e3\";}}s:5:\"nonce\";s:12:\"18cd7b5958fb\";s:7:\"service\";a:1:{i:0;s:4:\"none\";}s:20:\"service_instance_ids\";a:0:{}s:11:\"always_keep\";b:0;s:19:\"files_enumerated_at\";a:4:{s:7:\"plugins\";i:1537987118;s:6:\"themes\";i:1537987126;s:7:\"uploads\";i:1537987126;s:6:\"others\";i:1537987149;}s:18:\"created_by_version\";s:6:\"1.15.2\";s:12:\"is_multisite\";b:0;}}","yes");
INSERT INTO `wp_options` VALUES ("38424","updraft_last_backup","a:5:{s:11:\"backup_time\";i:1537989536;s:12:\"backup_array\";a:5:{s:7:\"plugins\";a:1:{i:0;s:60:\"backup_2018-09-26-1918_Dandy_Agency_680d299197b7-plugins.zip\";}s:12:\"plugins-size\";i:19124727;s:2:\"db\";s:54:\"backup_2018-09-26-1918_Dandy_Agency_680d299197b7-db.gz\";s:7:\"db-size\";i:244884;s:9:\"checksums\";a:2:{s:4:\"sha1\";a:2:{s:8:\"plugins0\";s:40:\"aec31536c0e6256bb2ea1faaa3270f7a5d460f10\";s:3:\"db0\";s:40:\"77ef93a4234af1bb710540c0acca550abe127b22\";}s:6:\"sha256\";a:2:{s:8:\"plugins0\";s:64:\"375a466f994ae341aeb71650081e20ae9fc533e2cc81d30c493cebb48dd6f77d\";s:3:\"db0\";s:64:\"213b96f9630607df464a156c73d1f151e1831476a720b341ccb5771d22c026a6\";}}}s:7:\"success\";i:1;s:6:\"errors\";a:0:{}s:12:\"backup_nonce\";s:12:\"680d299197b7\";}","yes");
INSERT INTO `wp_options` VALUES ("38428","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES ("38429","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES ("38430","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES ("38431","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES ("38432","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES ("38433","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES ("38434","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES ("38435","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES ("38436","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES ("38437","finished_splitting_shared_terms","1","yes");
INSERT INTO `wp_options` VALUES ("38438","site_icon","0","yes");
INSERT INTO `wp_options` VALUES ("38439","medium_large_size_w","768","yes");
INSERT INTO `wp_options` VALUES ("38440","medium_large_size_h","0","yes");
INSERT INTO `wp_options` VALUES ("38441","wp_page_for_privacy_policy","0","yes");
INSERT INTO `wp_options` VALUES ("38442","show_comments_cookies_opt_in","0","yes");
INSERT INTO `wp_options` VALUES ("38443","WPLANG","es_ES","yes");
INSERT INTO `wp_options` VALUES ("38444","db_upgraded","","yes");
INSERT INTO `wp_options` VALUES ("38447","widget_qtranslate","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES ("38452","can_compress_scripts","1","no");
INSERT INTO `wp_options` VALUES ("38467","scporder_install","1","yes");
INSERT INTO `wp_options` VALUES ("38470","itsec_active_modules","a:10:{s:9:\"ban-users\";b:1;s:6:\"backup\";b:1;s:11:\"brute-force\";b:1;s:19:\"network-brute-force\";b:1;s:16:\"wordpress-tweaks\";b:1;s:13:\"404-detection\";b:0;s:9:\"away-mode\";b:0;s:11:\"file-change\";b:0;s:3:\"ssl\";b:0;s:13:\"system-tweaks\";b:1;}","yes");
INSERT INTO `wp_options` VALUES ("38481","itsec_cron","a:2:{s:6:\"single\";a:0:{}s:9:\"recurring\";a:4:{s:17:\"purge-log-entries\";a:1:{s:4:\"data\";a:0:{}}s:14:\"purge-lockouts\";a:1:{s:4:\"data\";a:0:{}}s:11:\"clear-locks\";a:1:{s:4:\"data\";a:0:{}}s:6:\"backup\";a:1:{s:4:\"data\";a:0:{}}}}","no");
INSERT INTO `wp_options` VALUES ("38489","itsec_temp_whitelist_ip","a:1:{s:15:\"181.167.100.209\";i:1547838877;}","no");
INSERT INTO `wp_options` VALUES ("38493","itsec-storage","a:14:{s:6:\"global\";a:29:{s:15:\"lockout_message\";s:5:\"error\";s:20:\"user_lockout_message\";s:64:\"You have been locked out due to too many invalid login attempts.\";s:25:\"community_lockout_message\";s:77:\"Your IP address has been flagged as a threat by the iThemes Security network.\";s:9:\"blacklist\";b:1;s:15:\"blacklist_count\";i:3;s:16:\"blacklist_period\";i:7;s:14:\"lockout_period\";i:15;s:18:\"lockout_white_list\";a:2:{i:0;s:14:\"190.195.194.99\";i:1;s:15:\"181.167.100.209\";}s:12:\"log_rotation\";i:14;s:17:\"file_log_rotation\";i:180;s:8:\"log_type\";s:8:\"database\";s:12:\"log_location\";s:72:\"/home/wearedandy/wearedandy.com/wp-content/uploads/ithemes-security/logs\";s:8:\"log_info\";s:20:\"dandy-agency-sfBPUhX\";s:14:\"allow_tracking\";b:0;s:11:\"write_files\";b:1;s:10:\"nginx_file\";s:42:\"/home/wearedandy/wearedandy.com/nginx.conf\";s:24:\"infinitewp_compatibility\";b:0;s:11:\"did_upgrade\";b:0;s:9:\"lock_file\";b:0;s:14:\"proxy_override\";b:0;s:14:\"hide_admin_bar\";b:0;s:16:\"show_error_codes\";b:0;s:19:\"show_security_check\";b:0;s:5:\"build\";i:4106;s:20:\"activation_timestamp\";i:0;s:11:\"cron_status\";i:1;s:8:\"use_cron\";b:1;s:14:\"cron_test_time\";i:1576901525;s:19:\"enable_grade_report\";b:0;}s:19:\"notification-center\";a:8:{s:10:\"from_email\";s:0:\"\";s:18:\"default_recipients\";a:1:{s:9:\"user_list\";a:1:{i:0;s:18:\"role:administrator\";}}s:13:\"notifications\";a:3:{s:12:\"hide-backend\";a:4:{s:7:\"subject\";N;s:7:\"message\";N;s:14:\"recipient_type\";s:7:\"default\";s:9:\"user_list\";a:1:{i:0;s:18:\"role:administrator\";}}s:6:\"digest\";a:5:{s:7:\"subject\";N;s:8:\"schedule\";s:5:\"daily\";s:14:\"recipient_type\";s:7:\"default\";s:9:\"user_list\";a:1:{i:0;s:18:\"role:administrator\";}s:7:\"enabled\";b:0;}s:7:\"lockout\";a:4:{s:7:\"subject\";N;s:14:\"recipient_type\";s:7:\"default\";s:9:\"user_list\";a:1:{i:0;s:18:\"role:administrator\";}s:7:\"enabled\";b:0;}}s:9:\"last_sent\";a:1:{s:6:\"digest\";N;}s:4:\"data\";a:0:{}s:9:\"resend_at\";a:0:{}s:12:\"admin_emails\";a:0:{}s:15:\"last_mail_error\";s:0:\"\";}s:13:\"404-detection\";a:4:{s:12:\"check_period\";i:5;s:15:\"error_threshold\";i:20;s:10:\"white_list\";a:9:{i:0;s:12:\"/favicon.ico\";i:1;s:11:\"/robots.txt\";i:2;s:21:\"/apple-touch-icon.png\";i:3;s:33:\"/apple-touch-icon-precomposed.png\";i:4;s:17:\"/wp-content/cache\";i:5;s:18:\"/browserconfig.xml\";i:6;s:16:\"/crossdomain.xml\";i:7;s:11:\"/labels.rdf\";i:8;s:27:\"/trafficbasedsspsitemap.xml\";}s:5:\"types\";a:5:{i:0;s:4:\".jpg\";i:1;s:5:\".jpeg\";i:2;s:4:\".png\";i:3;s:4:\".gif\";i:4;s:4:\".css\";}}s:9:\"away-mode\";a:7:{s:4:\"type\";s:5:\"daily\";s:5:\"start\";i:1492473600;s:10:\"start_time\";i:0;s:3:\"end\";i:1492581600;s:8:\"end_time\";i:21600;s:13:\"override_type\";s:0:\"\";s:12:\"override_end\";i:0;}s:9:\"ban-users\";a:4:{s:7:\"default\";b:1;s:9:\"host_list\";a:19:{i:0;s:12:\"46.148.22.18\";i:1;s:13:\"46.148.18.162\";i:2;s:15:\"184.168.192.107\";i:3;s:14:\"155.133.82.112\";i:4;s:13:\"64.29.146.187\";i:5;s:14:\"31.184.238.200\";i:6;s:12:\"202.28.10.20\";i:7;s:11:\"185.40.4.66\";i:8;s:13:\"103.241.0.191\";i:9;s:14:\"103.255.236.34\";i:10;s:12:\"121.41.7.161\";i:11;s:14:\"217.14.176.191\";i:12;s:14:\"203.170.85.111\";i:13;s:14:\"46.105.102.203\";i:14;s:14:\"178.137.82.201\";i:15;s:13:\"37.59.178.104\";i:16;s:12:\"5.188.62.117\";i:17;s:14:\"35.185.125.147\";i:18;s:15:\"199.188.103.175\";}s:10:\"agent_list\";a:0:{}s:16:\"enable_ban_lists\";b:1;}s:6:\"backup\";a:9:{s:9:\"all_sites\";b:1;s:6:\"method\";i:2;s:8:\"location\";s:75:\"/home/wearedandy/wearedandy.com/wp-content/uploads/ithemes-security/backups\";s:6:\"retain\";i:3;s:3:\"zip\";b:1;s:7:\"exclude\";a:3:{i:0;s:14:\"itsec_lockouts\";i:1;s:9:\"itsec_log\";i:2;s:10:\"itsec_temp\";}s:7:\"enabled\";b:1;s:8:\"interval\";i:90;s:8:\"last_run\";i:1569093262;}s:11:\"file-change\";a:11:{s:6:\"method\";s:7:\"exclude\";s:9:\"file_list\";a:0:{}s:5:\"types\";a:39:{i:0;s:4:\".log\";i:1;s:3:\".mo\";i:2;s:3:\".po\";i:3;s:4:\".bmp\";i:4;s:4:\".gif\";i:5;s:4:\".ico\";i:6;s:4:\".jpe\";i:7;s:5:\".jpeg\";i:8;s:4:\".jpg\";i:9;s:4:\".png\";i:10;s:4:\".psd\";i:11;s:4:\".raw\";i:12;s:4:\".svg\";i:13;s:4:\".tif\";i:14;s:5:\".tiff\";i:15;s:4:\".aif\";i:16;s:5:\".flac\";i:17;s:4:\".m4a\";i:18;s:4:\".mp3\";i:19;s:4:\".oga\";i:20;s:4:\".ogg\";i:22;s:3:\".ra\";i:23;s:4:\".wav\";i:24;s:4:\".wma\";i:25;s:4:\".asf\";i:26;s:4:\".avi\";i:27;s:4:\".mkv\";i:28;s:4:\".mov\";i:29;s:4:\".mp4\";i:30;s:4:\".mpe\";i:31;s:5:\".mpeg\";i:32;s:4:\".mpg\";i:33;s:4:\".ogv\";i:34;s:3:\".qt\";i:35;s:3:\".rm\";i:36;s:4:\".vob\";i:37;s:5:\".webm\";i:38;s:3:\".wm\";i:39;s:4:\".wmv\";}s:5:\"email\";b:1;s:12:\"notify_admin\";b:1;s:5:\"split\";b:0;s:10:\"last_chunk\";b:0;s:8:\"last_run\";i:1492370324;s:12:\"show_warning\";b:0;s:15:\"expected_hashes\";a:0:{}s:9:\"last_scan\";i:0;}s:12:\"hide-backend\";a:6:{s:7:\"enabled\";b:1;s:4:\"slug\";s:10:\"loginadmin\";s:12:\"theme_compat\";b:1;s:17:\"theme_compat_slug\";s:9:\"not_found\";s:16:\"post_logout_slug\";s:0:\"\";s:8:\"register\";s:15:\"wp-register-php\";}s:11:\"brute-force\";a:4:{s:17:\"max_attempts_host\";i:5;s:17:\"max_attempts_user\";i:10;s:12:\"check_period\";i:5;s:14:\"auto_ban_admin\";b:0;}s:19:\"network-brute-force\";a:5:{s:7:\"api_key\";s:32:\"Wez5h4jD6Y25td1N6SBmHVoZ35DSDU00\";s:10:\"api_secret\";s:128:\"zth0ZFcimt0cr622Ayo55d5O71BoJ8DVkT4ME33Vf915M7dqUB1hLlt8WRHJclIw1zSj6Qh4IB51kjdI99TVKBrM9ut5f5q7mf416rX06z197I786858nj052sELbs59\";s:10:\"enable_ban\";b:0;s:13:\"updates_optin\";b:0;s:7:\"api_nag\";b:0;}s:16:\"strong-passwords\";a:1:{s:4:\"role\";s:13:\"administrator\";}s:21:\"password-requirements\";a:2:{s:20:\"enabled_requirements\";a:1:{s:8:\"strength\";b:1;}s:20:\"requirement_settings\";a:1:{s:8:\"strength\";a:1:{s:4:\"role\";s:13:\"administrator\";}}}s:13:\"system-tweaks\";a:10:{s:13:\"protect_files\";b:1;s:18:\"directory_browsing\";b:1;s:15:\"request_methods\";b:0;s:24:\"suspicious_query_strings\";b:0;s:22:\"non_english_characters\";b:0;s:16:\"long_url_strings\";b:0;s:17:\"write_permissions\";b:0;s:11:\"uploads_php\";b:0;s:10:\"themes_php\";b:0;s:11:\"plugins_php\";b:0;}s:16:\"wordpress-tweaks\";a:13:{s:18:\"wlwmanifest_header\";b:1;s:14:\"edituri_header\";b:1;s:12:\"comment_spam\";b:1;s:14:\"disable_xmlrpc\";i:2;s:22:\"allow_xmlrpc_multiauth\";b:0;s:8:\"rest_api\";s:15:\"restrict-access\";s:21:\"valid_user_login_type\";s:4:\"both\";s:26:\"patch_thumb_file_traversal\";b:1;s:11:\"file_editor\";b:0;s:12:\"login_errors\";b:0;s:21:\"force_unique_nicename\";b:0;s:27:\"disable_unused_author_pages\";b:0;s:16:\"block_tabnapping\";b:0;}}","yes");
INSERT INTO `wp_options` VALUES ("38498","wpseo","a:19:{s:15:\"ms_defaults_set\";b:0;s:7:\"version\";s:3:\"8.3\";s:20:\"disableadvanced_meta\";b:1;s:19:\"onpage_indexability\";b:0;s:11:\"baiduverify\";s:0:\"\";s:12:\"googleverify\";s:0:\"\";s:8:\"msverify\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:0:\"\";s:20:\"has_multiple_authors\";s:0:\"\";s:16:\"environment_type\";s:0:\"\";s:23:\"content_analysis_active\";b:1;s:23:\"keyword_analysis_active\";b:1;s:21:\"enable_admin_bar_menu\";b:1;s:26:\"enable_cornerstone_content\";b:0;s:18:\"enable_xml_sitemap\";b:1;s:24:\"enable_text_link_counter\";b:1;s:22:\"show_onboarding_notice\";b:1;s:18:\"first_activated_on\";b:0;}","yes");
INSERT INTO `wp_options` VALUES ("38499","wpseo_titles","a:70:{s:10:\"title_test\";i:0;s:17:\"forcerewritetitle\";b:1;s:9:\"separator\";s:7:\"sc-dash\";s:16:\"title-home-wpseo\";s:42:\"%%sitename%% %%page%% %%sep%% %%sitedesc%%\";s:18:\"title-author-wpseo\";s:41:\"%%name%%, Author at %%sitename%% %%page%%\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:63:\"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%\";s:15:\"title-404-wpseo\";s:35:\"Page not found %%sep%% %%sitename%%\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:9:\"rssbefore\";s:0:\"\";s:8:\"rssafter\";s:53:\"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.\";s:20:\"noindex-author-wpseo\";b:0;s:28:\"noindex-author-noposts-wpseo\";b:1;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:1;s:12:\"disable-date\";b:1;s:19:\"disable-post_format\";b:1;s:18:\"disable-attachment\";b:1;s:23:\"is-media-purge-relevant\";b:0;s:20:\"breadcrumbs-404crumb\";s:25:\"Error 404: Page not found\";s:29:\"breadcrumbs-display-blog-page\";b:0;s:20:\"breadcrumbs-boldlast\";b:0;s:25:\"breadcrumbs-archiveprefix\";s:12:\"Archives for\";s:18:\"breadcrumbs-enable\";b:0;s:16:\"breadcrumbs-home\";s:4:\"Home\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:16:\"You searched for\";s:15:\"breadcrumbs-sep\";s:2:\"»\";s:12:\"website_name\";s:0:\"\";s:11:\"person_name\";s:0:\"\";s:22:\"alternate_website_name\";s:0:\"\";s:12:\"company_logo\";s:68:\"https://www.wearedandy.com/wp-content/uploads/2018/10/logo-dandy.png\";s:12:\"company_name\";s:12:\"Dandy Agency\";s:17:\"company_or_person\";s:7:\"company\";s:17:\"stripcategorybase\";b:0;s:10:\"title-post\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"noindex-post\";b:1;s:13:\"showdate-post\";b:0;s:23:\"display-metabox-pt-post\";b:1;s:10:\"title-page\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:13:\"showdate-page\";b:0;s:23:\"display-metabox-pt-page\";b:1;s:16:\"title-attachment\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:19:\"showdate-attachment\";b:0;s:29:\"display-metabox-pt-attachment\";b:1;s:11:\"title-works\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:14:\"metadesc-works\";s:0:\"\";s:13:\"noindex-works\";b:0;s:14:\"showdate-works\";b:0;s:24:\"display-metabox-pt-works\";b:1;s:18:\"title-tax-category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:28:\"display-metabox-tax-category\";b:1;s:20:\"noindex-tax-category\";b:1;s:18:\"title-tax-post_tag\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:28:\"display-metabox-tax-post_tag\";b:1;s:20:\"noindex-tax-post_tag\";b:1;s:21:\"title-tax-post_format\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:31:\"display-metabox-tax-post_format\";b:0;s:23:\"noindex-tax-post_format\";b:1;s:23:\"post_types-post-maintax\";i:0;}","yes");
INSERT INTO `wp_options` VALUES ("38500","wpseo_social","a:18:{s:13:\"facebook_site\";s:36:\"https://www.facebook.com/dandyagency\";s:13:\"instagram_url\";s:32:\"http://instagram.com/dandyagency\";s:12:\"linkedin_url\";s:0:\"\";s:11:\"myspace_url\";s:0:\"\";s:16:\"og_default_image\";s:68:\"https://www.wearedandy.com/wp-content/uploads/2018/10/logo-dandy.png\";s:18:\"og_frontpage_title\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:9:\"opengraph\";b:1;s:13:\"pinterest_url\";s:0:\"\";s:15:\"pinterestverify\";s:0:\"\";s:14:\"plus-publisher\";s:0:\"\";s:7:\"twitter\";b:1;s:12:\"twitter_site\";s:11:\"agencydandy\";s:17:\"twitter_card_type\";s:19:\"summary_large_image\";s:11:\"youtube_url\";s:0:\"\";s:15:\"google_plus_url\";s:0:\"\";s:10:\"fbadminapp\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES ("38501","wpseo_flush_rewrite","1","yes");
INSERT INTO `wp_options` VALUES ("38508","wpseo_onpage","a:2:{s:6:\"status\";i:-1;s:10:\"last_fetch\";i:1538595548;}","yes");
INSERT INTO `wp_options` VALUES ("38517","autoptimize_version","2.4.0","yes");
INSERT INTO `wp_options` VALUES ("38518","autoptimize_service_availablity","a:2:{s:12:\"extra_imgopt\";a:3:{s:6:\"status\";s:2:\"up\";s:5:\"hosts\";a:1:{i:1;s:26:\"https://cdn.shortpixel.ai/\";}s:16:\"launch-threshold\";s:4:\"4096\";}s:7:\"critcss\";a:2:{s:6:\"status\";s:2:\"up\";s:5:\"hosts\";a:1:{i:1;s:24:\"https://criticalcss.com/\";}}}","yes");
INSERT INTO `wp_options` VALUES ("38534","autoptimize_html","on","yes");
INSERT INTO `wp_options` VALUES ("38535","autoptimize_html_keepcomments","","yes");
INSERT INTO `wp_options` VALUES ("38536","autoptimize_js","on","yes");
INSERT INTO `wp_options` VALUES ("38537","autoptimize_js_aggregate","on","yes");
INSERT INTO `wp_options` VALUES ("38538","autoptimize_js_exclude","seal.js, js/jquery/jquery.js","yes");
INSERT INTO `wp_options` VALUES ("38539","autoptimize_js_trycatch","","yes");
INSERT INTO `wp_options` VALUES ("38540","autoptimize_js_justhead","","yes");
INSERT INTO `wp_options` VALUES ("38541","autoptimize_js_forcehead","","yes");
INSERT INTO `wp_options` VALUES ("38542","autoptimize_js_include_inline","","yes");
INSERT INTO `wp_options` VALUES ("38543","autoptimize_css","on","yes");
INSERT INTO `wp_options` VALUES ("38544","autoptimize_css_aggregate","on","yes");
INSERT INTO `wp_options` VALUES ("38545","autoptimize_css_exclude","wp-content/cache/, wp-content/uploads/, admin-bar.min.css, dashicons.min.css","yes");
INSERT INTO `wp_options` VALUES ("38546","autoptimize_css_justhead","","yes");
INSERT INTO `wp_options` VALUES ("38547","autoptimize_css_datauris","","yes");
INSERT INTO `wp_options` VALUES ("38548","autoptimize_css_defer","","yes");
INSERT INTO `wp_options` VALUES ("38549","autoptimize_css_defer_inline","","yes");
INSERT INTO `wp_options` VALUES ("38550","autoptimize_css_inline","","yes");
INSERT INTO `wp_options` VALUES ("38551","autoptimize_css_include_inline","on","yes");
INSERT INTO `wp_options` VALUES ("38552","autoptimize_cdn_url","","yes");
INSERT INTO `wp_options` VALUES ("38553","autoptimize_cache_clean","0","yes");
INSERT INTO `wp_options` VALUES ("38554","autoptimize_cache_nogzip","on","yes");
INSERT INTO `wp_options` VALUES ("38555","autoptimize_show_adv","0","yes");
INSERT INTO `wp_options` VALUES ("38556","autoptimize_optimize_logged","on","yes");
INSERT INTO `wp_options` VALUES ("38557","autoptimize_optimize_checkout","","yes");
INSERT INTO `wp_options` VALUES ("38560","wpseo_sitemap_1_cache_validator","4QeTC","no");
INSERT INTO `wp_options` VALUES ("38561","wpseo_sitemap_nav_menu_item_cache_validator","4OJOg","no");
INSERT INTO `wp_options` VALUES ("38562","wpseo_sitemap_37_cache_validator","5WUfd","no");
INSERT INTO `wp_options` VALUES ("38563","wpseo_sitemap_page_cache_validator","4QeTO","no");
INSERT INTO `wp_options` VALUES ("38564","wpseo_sitemap_post_cache_validator","55cYO","no");
INSERT INTO `wp_options` VALUES ("38565","wpseo_sitemap_category_cache_validator","5X2Na","no");
INSERT INTO `wp_options` VALUES ("38576","wp-smush-last_settings","a:12:{s:11:\"networkwide\";b:0;s:4:\"auto\";i:1;s:5:\"lossy\";b:0;s:8:\"original\";b:0;s:10:\"strip_exif\";i:0;s:6:\"resize\";i:0;s:6:\"backup\";b:0;s:10:\"png_to_jpg\";b:0;s:7:\"nextgen\";b:0;s:2:\"s3\";b:0;s:9:\"detection\";b:0;s:9:\"gutenberg\";i:0;}","no");
INSERT INTO `wp_options` VALUES ("38577","wdev-frash","a:3:{s:7:\"plugins\";a:1:{s:23:\"wp-smushit/wp-smush.php\";i:1537988881;}s:5:\"queue\";a:0:{}s:4:\"done\";a:2:{i:0;a:6:{s:6:\"plugin\";s:23:\"wp-smushit/wp-smush.php\";s:4:\"type\";s:5:\"email\";s:7:\"show_at\";i:1537988881;s:5:\"state\";s:6:\"ignore\";s:4:\"hash\";s:32:\"fc50097023d0d34c5a66f6cddcf77694\";s:10:\"handled_at\";i:1537989376;}i:1;a:6:{s:6:\"plugin\";s:23:\"wp-smushit/wp-smush.php\";s:4:\"type\";s:4:\"rate\";s:7:\"show_at\";i:1538593681;s:5:\"state\";s:6:\"ignore\";s:4:\"hash\";s:32:\"fc50097023d0d34c5a66f6cddcf77694\";s:10:\"handled_at\";i:1539013152;}}}","no");
INSERT INTO `wp_options` VALUES ("38578","wp-smush-skip-redirect","1","no");
INSERT INTO `wp_options` VALUES ("38579","smush_option","a:1:{s:7:\"version\";s:5:\"2.8.1\";}","yes");
INSERT INTO `wp_options` VALUES ("38580","wp-smush-install-type","existing","no");
INSERT INTO `wp_options` VALUES ("38581","wp-smush-version","2.8.1","no");
INSERT INTO `wp_options` VALUES ("38582","smush_global_stats","a:9:{s:11:\"size_before\";i:15550230;s:10:\"size_after\";i:14545069;s:7:\"percent\";d:6.5;s:5:\"human\";s:8:\"981.6 KB\";s:5:\"bytes\";i:1005161;s:12:\"total_images\";i:405;s:12:\"resize_count\";i:0;s:14:\"resize_savings\";i:0;s:18:\"conversion_savings\";i:0;}","no");
INSERT INTO `wp_options` VALUES ("38585","dir_smush_stats","a:2:{s:9:\"dir_smush\";a:2:{s:5:\"total\";s:1:\"0\";s:9:\"optimised\";i:0;}s:14:\"combined_stats\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES ("38586","wp-smush-resize_sizes","a:2:{s:5:\"width\";i:2048;s:6:\"height\";i:2048;}","no");
INSERT INTO `wp_options` VALUES ("38587","skip-smush-setup","1","no");
INSERT INTO `wp_options` VALUES ("38717","wp-smush-hide_upgrade_notice","1","no");
INSERT INTO `wp_options` VALUES ("39271","wpseo_sitemap_cache_validator_global","5873u","no");
INSERT INTO `wp_options` VALUES ("39292","wpseo_sitemap_attachment_cache_validator","4Qcz3","no");
INSERT INTO `wp_options` VALUES ("39297","rewrite_rules","a:108:{s:19:\"sitemap_index\\.xml$\";s:19:\"index.php?sitemap=1\";s:31:\"([^/]+?)-sitemap([0-9]+)?\\.xml$\";s:51:\"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]\";s:24:\"([a-z]+)?-?sitemap\\.xsl$\";s:25:\"index.php?xsl=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:35:\"project/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"project/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"project/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"project/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"project/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"project/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"project/([^/]+)/embed/?$\";s:38:\"index.php?works=$matches[1]&embed=true\";s:28:\"project/([^/]+)/trackback/?$\";s:32:\"index.php?works=$matches[1]&tb=1\";s:36:\"project/([^/]+)/page/?([0-9]{1,})/?$\";s:45:\"index.php?works=$matches[1]&paged=$matches[2]\";s:43:\"project/([^/]+)/comment-page-([0-9]{1,})/?$\";s:45:\"index.php?works=$matches[1]&cpage=$matches[2]\";s:32:\"project/([^/]+)(?:/([0-9]+))?/?$\";s:44:\"index.php?works=$matches[1]&page=$matches[2]\";s:24:\"project/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"project/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"project/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"project/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"project/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"project/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:38:\"index.php?&page_id=5&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}","yes");
INSERT INTO `wp_options` VALUES ("39298","fresh_site","0","yes");
INSERT INTO `wp_options` VALUES ("39306","wpseo_sitemap_works_cache_validator","4OTrW","no");
INSERT INTO `wp_options` VALUES ("40810","updraftplus_dismisseddashnotice","1573219705","yes");
INSERT INTO `wp_options` VALUES ("40830","wpseo_sitemap_160_cache_validator","4E28X","no");
INSERT INTO `wp_options` VALUES ("40831","wpseo_sitemap_168_cache_validator","4E293","no");
INSERT INTO `wp_options` VALUES ("40832","wpseo_sitemap_250_cache_validator","4E298","no");
INSERT INTO `wp_options` VALUES ("40833","wpseo_sitemap_272_cache_validator","3ero","no");
INSERT INTO `wp_options` VALUES ("40834","wpseo_sitemap_316_cache_validator","ndki","no");
INSERT INTO `wp_options` VALUES ("40835","wpseo_sitemap_334_cache_validator","ndko","no");
INSERT INTO `wp_options` VALUES ("43008","auto_core_update_notified","a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:19:\"guille070@gmail.com\";s:7:\"version\";s:6:\"4.9.13\";s:9:\"timestamp\";i:1576234348;}","no");
INSERT INTO `wp_options` VALUES ("59409","_transient_timeout_wpseo_link_table_inaccessible","1601162396","no");
INSERT INTO `wp_options` VALUES ("59410","_transient_wpseo_link_table_inaccessible","0","no");
INSERT INTO `wp_options` VALUES ("59411","_transient_timeout_wpseo_meta_table_inaccessible","1601162397","no");
INSERT INTO `wp_options` VALUES ("59412","_transient_wpseo_meta_table_inaccessible","0","no");
INSERT INTO `wp_options` VALUES ("63553","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:5:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.3.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.3.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.3.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.3.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.3.2\";s:7:\"version\";s:5:\"5.3.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";}i:1;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.3.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.3.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.3.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.3.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.3.2\";s:7:\"version\";s:5:\"5.3.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:2;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.5.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.5.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.2.5-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.2.5-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.2.5\";s:7:\"version\";s:5:\"5.2.5\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:3;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.4.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.4.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.1.4-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.1.4-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.1.4\";s:7:\"version\";s:5:\"5.1.4\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:4;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.8.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.8.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.0.8-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.0.8-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.0.8\";s:7:\"version\";s:5:\"5.0.8\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}}s:12:\"last_checked\";i:1576838106;s:15:\"version_checked\";s:6:\"4.9.13\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES ("63899","_site_transient_timeout_itsec_wp_upload_dir","1576916377","no");
INSERT INTO `wp_options` VALUES ("63900","_site_transient_itsec_wp_upload_dir","a:6:{s:4:\"path\";s:58:\"/home/wearedandy/wearedandy.com/wp-content/uploads/2019/12\";s:3:\"url\";s:53:\"https://www.wearedandy.com/wp-content/uploads/2019/12\";s:6:\"subdir\";s:8:\"/2019/12\";s:7:\"basedir\";s:50:\"/home/wearedandy/wearedandy.com/wp-content/uploads\";s:7:\"baseurl\";s:45:\"https://www.wearedandy.com/wp-content/uploads\";s:5:\"error\";b:0;}","no");
INSERT INTO `wp_options` VALUES ("63909","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1576838108;s:7:\"checked\";a:4:{s:12:\"dandy-agency\";s:3:\"1.0\";s:13:\"twentyfifteen\";s:3:\"2.0\";s:15:\"twentyseventeen\";s:3:\"1.7\";s:13:\"twentysixteen\";s:3:\"1.5\";}s:8:\"response\";a:3:{s:13:\"twentyfifteen\";a:6:{s:5:\"theme\";s:13:\"twentyfifteen\";s:11:\"new_version\";s:3:\"2.5\";s:3:\"url\";s:43:\"https://wordpress.org/themes/twentyfifteen/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/theme/twentyfifteen.2.5.zip\";s:8:\"requires\";s:3:\"4.1\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:15:\"twentyseventeen\";a:6:{s:5:\"theme\";s:15:\"twentyseventeen\";s:11:\"new_version\";s:3:\"2.2\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentyseventeen/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentyseventeen.2.2.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:13:\"twentysixteen\";a:6:{s:5:\"theme\";s:13:\"twentysixteen\";s:11:\"new_version\";s:3:\"2.0\";s:3:\"url\";s:43:\"https://wordpress.org/themes/twentysixteen/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/theme/twentysixteen.2.0.zip\";s:8:\"requires\";s:3:\"4.4\";s:12:\"requires_php\";s:5:\"5.2.4\";}}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES ("63910","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1576838108;s:7:\"checked\";a:13:{s:57:\"acf-content-analysis-for-yoast-seo/yoast-acf-analysis.php\";s:5:\"2.1.0\";s:30:\"advanced-custom-fields/acf.php\";s:5:\"5.7.6\";s:45:\"acf-flexible-content/acf-flexible-content.php\";s:5:\"1.1.1\";s:27:\"autoptimize/autoptimize.php\";s:5:\"2.4.0\";s:32:\"custom-post-type-works/works.php\";s:3:\"1.0\";s:41:\"better-wp-security/better-wp-security.php\";s:5:\"7.1.0\";s:25:\"qtranslate/qtranslate.php\";s:6:\"2.5.39\";s:21:\"raw-html/raw_html.php\";s:5:\"1.5.1\";s:53:\"simple-custom-post-order/simple-custom-post-order.php\";s:5:\"2.3.2\";s:23:\"wp-smushit/wp-smush.php\";s:5:\"2.8.1\";s:51:\"thumbnail-crop-position/thumbnail-crop-position.php\";s:3:\"1.3\";s:27:\"updraftplus/updraftplus.php\";s:6:\"1.15.2\";s:24:\"wordpress-seo/wp-seo.php\";s:3:\"8.3\";}s:8:\"response\";a:8:{s:57:\"acf-content-analysis-for-yoast-seo/yoast-acf-analysis.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:48:\"w.org/plugins/acf-content-analysis-for-yoast-seo\";s:4:\"slug\";s:34:\"acf-content-analysis-for-yoast-seo\";s:6:\"plugin\";s:57:\"acf-content-analysis-for-yoast-seo/yoast-acf-analysis.php\";s:11:\"new_version\";s:5:\"2.3.0\";s:3:\"url\";s:65:\"https://wordpress.org/plugins/acf-content-analysis-for-yoast-seo/\";s:7:\"package\";s:83:\"https://downloads.wordpress.org/plugin/acf-content-analysis-for-yoast-seo.2.3.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:87:\"https://ps.w.org/acf-content-analysis-for-yoast-seo/assets/icon-256x256.png?rev=1717503\";s:2:\"1x\";s:87:\"https://ps.w.org/acf-content-analysis-for-yoast-seo/assets/icon-128x128.png?rev=1717503\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:90:\"https://ps.w.org/acf-content-analysis-for-yoast-seo/assets/banner-1544x500.png?rev=1717503\";s:2:\"1x\";s:89:\"https://ps.w.org/acf-content-analysis-for-yoast-seo/assets/banner-772x250.png?rev=1717503\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.5\";s:12:\"requires_php\";s:5:\"5.2.4\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:30:\"advanced-custom-fields/acf.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:36:\"w.org/plugins/advanced-custom-fields\";s:4:\"slug\";s:22:\"advanced-custom-fields\";s:6:\"plugin\";s:30:\"advanced-custom-fields/acf.php\";s:11:\"new_version\";s:5:\"5.8.7\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/advanced-custom-fields/\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/plugin/advanced-custom-fields.5.8.7.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746\";s:2:\"1x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";s:2:\"1x\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.3.0\";s:12:\"requires_php\";s:3:\"5.4\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:27:\"autoptimize/autoptimize.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:25:\"w.org/plugins/autoptimize\";s:4:\"slug\";s:11:\"autoptimize\";s:6:\"plugin\";s:27:\"autoptimize/autoptimize.php\";s:11:\"new_version\";s:5:\"2.5.1\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/autoptimize/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/autoptimize.2.5.1.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:64:\"https://ps.w.org/autoptimize/assets/icon-128x128.png?rev=1864142\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/autoptimize/assets/banner-772x250.jpg?rev=1315920\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.3.2\";s:12:\"requires_php\";s:3:\"5.6\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:41:\"better-wp-security/better-wp-security.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:32:\"w.org/plugins/better-wp-security\";s:4:\"slug\";s:18:\"better-wp-security\";s:6:\"plugin\";s:41:\"better-wp-security/better-wp-security.php\";s:11:\"new_version\";s:5:\"7.6.1\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/better-wp-security/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/better-wp-security.7.6.1.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:70:\"https://ps.w.org/better-wp-security/assets/icon-256x256.jpg?rev=969999\";s:2:\"1x\";s:62:\"https://ps.w.org/better-wp-security/assets/icon.svg?rev=970042\";s:3:\"svg\";s:62:\"https://ps.w.org/better-wp-security/assets/icon.svg?rev=970042\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:72:\"https://ps.w.org/better-wp-security/assets/banner-772x250.png?rev=881897\";}s:11:\"banners_rtl\";a:0:{}s:14:\"upgrade_notice\";s:90:\"<p>Version 7.6.1 contains new features and bug fixes. It is recommended for all users.</p>\";s:6:\"tested\";s:5:\"5.3.0\";s:12:\"requires_php\";s:3:\"5.5\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:21:\"raw-html/raw_html.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:22:\"w.org/plugins/raw-html\";s:4:\"slug\";s:8:\"raw-html\";s:6:\"plugin\";s:21:\"raw-html/raw_html.php\";s:11:\"new_version\";s:5:\"1.6.1\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/raw-html/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/raw-html.1.6.1.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:52:\"https://s.w.org/plugins/geopattern-icon/raw-html.svg\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.5\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:53:\"simple-custom-post-order/simple-custom-post-order.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:38:\"w.org/plugins/simple-custom-post-order\";s:4:\"slug\";s:24:\"simple-custom-post-order\";s:6:\"plugin\";s:53:\"simple-custom-post-order/simple-custom-post-order.php\";s:11:\"new_version\";s:5:\"2.4.7\";s:3:\"url\";s:55:\"https://wordpress.org/plugins/simple-custom-post-order/\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/plugin/simple-custom-post-order.2.4.7.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:77:\"https://ps.w.org/simple-custom-post-order/assets/icon-256x256.jpg?rev=1859717\";s:2:\"1x\";s:77:\"https://ps.w.org/simple-custom-post-order/assets/icon-256x256.jpg?rev=1859717\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:79:\"https://ps.w.org/simple-custom-post-order/assets/banner-772x250.jpg?rev=1859717\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.5\";s:12:\"requires_php\";s:3:\"5.6\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:23:\"wp-smushit/wp-smush.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:24:\"w.org/plugins/wp-smushit\";s:4:\"slug\";s:10:\"wp-smushit\";s:6:\"plugin\";s:23:\"wp-smushit/wp-smush.php\";s:11:\"new_version\";s:5:\"3.3.2\";s:3:\"url\";s:41:\"https://wordpress.org/plugins/wp-smushit/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/plugin/wp-smushit.3.3.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:63:\"https://ps.w.org/wp-smushit/assets/icon-256x256.jpg?rev=2132251\";s:2:\"1x\";s:63:\"https://ps.w.org/wp-smushit/assets/icon-128x128.jpg?rev=2132250\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/wp-smushit/assets/banner-1544x500.png?rev=1863697\";s:2:\"1x\";s:65:\"https://ps.w.org/wp-smushit/assets/banner-772x250.png?rev=1863697\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.3.0\";s:12:\"requires_php\";s:3:\"5.3\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:27:\"updraftplus/updraftplus.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:25:\"w.org/plugins/updraftplus\";s:4:\"slug\";s:11:\"updraftplus\";s:6:\"plugin\";s:27:\"updraftplus/updraftplus.php\";s:11:\"new_version\";s:7:\"1.16.21\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/updraftplus/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/updraftplus.1.16.21.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/updraftplus/assets/icon-256x256.jpg?rev=1686200\";s:2:\"1x\";s:64:\"https://ps.w.org/updraftplus/assets/icon-128x128.jpg?rev=1686200\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/updraftplus/assets/banner-1544x500.png?rev=1686200\";s:2:\"1x\";s:66:\"https://ps.w.org/updraftplus/assets/banner-772x250.png?rev=1686200\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.3.2\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:2:{s:51:\"thumbnail-crop-position/thumbnail-crop-position.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:37:\"w.org/plugins/thumbnail-crop-position\";s:4:\"slug\";s:23:\"thumbnail-crop-position\";s:6:\"plugin\";s:51:\"thumbnail-crop-position/thumbnail-crop-position.php\";s:11:\"new_version\";s:3:\"1.3\";s:3:\"url\";s:54:\"https://wordpress.org/plugins/thumbnail-crop-position/\";s:7:\"package\";s:70:\"https://downloads.wordpress.org/plugin/thumbnail-crop-position.1.3.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:67:\"https://s.w.org/plugins/geopattern-icon/thumbnail-crop-position.svg\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:6:\"12.7.1\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/wordpress-seo.12.7.1.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=1834347\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=1843435\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=1843435\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=1843435\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=1843435\";}s:6:\"tested\";s:5:\"5.3.2\";s:12:\"requires_php\";s:6:\"5.6.20\";s:13:\"compatibility\";a:0:{}}}}","no");
INSERT INTO `wp_options` VALUES ("63915","_transient_timeout_yst_sm_works_1:5873u_4OTrW","1576931561","no");
INSERT INTO `wp_options` VALUES ("63916","_transient_yst_sm_works_1:5873u_4OTrW","C:24:\"WPSEO_Sitemap_Cache_Data\":16520:{a:2:{s:6:\"status\";s:2:\"ok\";s:3:\"xml\";s:16471:\"<urlset xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:image=\"http://www.google.com/schemas/sitemap-image/1.1\" xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd http://www.google.com/schemas/sitemap-image/1.1 http://www.google.com/schemas/sitemap-image/1.1/sitemap-image.xsd\" xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">
	<url>
		<loc>https://www.wearedandy.com/project/alkhailheights/</loc>
		<lastmod>2015-03-06T18:58:58+00:00</lastmod>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/AK_002.jpg</image:loc>
			<image:title><![CDATA[AK_002]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/AK_001.jpg</image:loc>
			<image:caption><![CDATA[AK_001]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/AK_002.jpg</image:loc>
			<image:caption><![CDATA[AK_002]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/AK_006.jpg</image:loc>
			<image:caption><![CDATA[AK_003]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/AK_010.jpg</image:loc>
			<image:caption><![CDATA[AK_004]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/AK_004.jpg</image:loc>
			<image:caption><![CDATA[AK_005]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/AK_005.jpg</image:loc>
			<image:caption><![CDATA[AK_006]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/AK_001.jpg</image:loc>
			<image:caption><![CDATA[AK_001]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/AK_002.jpg</image:loc>
			<image:caption><![CDATA[AK_002]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/AK_006.jpg</image:loc>
			<image:caption><![CDATA[AK_003]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/AK_010.jpg</image:loc>
			<image:caption><![CDATA[AK_004]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/AK_004.jpg</image:loc>
			<image:caption><![CDATA[AK_005]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/AK_005.jpg</image:loc>
			<image:caption><![CDATA[AK_006]]></image:caption>
		</image:image>
	</url>
	<url>
		<loc>https://www.wearedandy.com/project/the-royal-estates/</loc>
		<lastmod>2015-03-06T19:32:33+00:00</lastmod>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/RE_011.jpg</image:loc>
			<image:title><![CDATA[RE_011]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/RE_010.jpg</image:loc>
			<image:caption><![CDATA[RE_001]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/RE_002.jpg</image:loc>
			<image:caption><![CDATA[RE_002]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/RE_011.jpg</image:loc>
			<image:caption><![CDATA[RE_003]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/RE_008.jpg</image:loc>
			<image:caption><![CDATA[RE_004]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/RE_007.jpg</image:loc>
			<image:caption><![CDATA[RE_005]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/RE_012.jpg</image:loc>
			<image:caption><![CDATA[RE_006]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/RE_004.jpg</image:loc>
			<image:caption><![CDATA[RE_007]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/RE_001.jpg</image:loc>
			<image:caption><![CDATA[RE_008]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/RE_013.jpg</image:loc>
			<image:caption><![CDATA[RE_009]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/RE_010.jpg</image:loc>
			<image:caption><![CDATA[RE_001]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/RE_002.jpg</image:loc>
			<image:caption><![CDATA[RE_002]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/RE_011.jpg</image:loc>
			<image:caption><![CDATA[RE_003]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/RE_008.jpg</image:loc>
			<image:caption><![CDATA[RE_004]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/RE_007.jpg</image:loc>
			<image:caption><![CDATA[RE_005]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/RE_012.jpg</image:loc>
			<image:caption><![CDATA[RE_006]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/RE_004.jpg</image:loc>
			<image:caption><![CDATA[RE_007]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/RE_001.jpg</image:loc>
			<image:caption><![CDATA[RE_008]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/RE_013.jpg</image:loc>
			<image:caption><![CDATA[RE_009]]></image:caption>
		</image:image>
	</url>
	<url>
		<loc>https://www.wearedandy.com/project/iboux/</loc>
		<lastmod>2015-04-15T10:48:58+00:00</lastmod>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/04/IB_0021.jpg</image:loc>
			<image:title><![CDATA[IB_002]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/04/IB_001.jpg</image:loc>
			<image:caption><![CDATA[IB_001]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/04/IB_004.jpg</image:loc>
			<image:caption><![CDATA[IB_004]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/04/IB_003.jpg</image:loc>
			<image:caption><![CDATA[IB_003]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/04/IB_006.jpg</image:loc>
			<image:caption><![CDATA[IB_006]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/04/IB_002.jpg</image:loc>
			<image:caption><![CDATA[IB_002]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/04/IB_001.jpg</image:loc>
			<image:caption><![CDATA[IB_001]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/04/IB_004.jpg</image:loc>
			<image:caption><![CDATA[IB_004]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/04/IB_003.jpg</image:loc>
			<image:caption><![CDATA[IB_003]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/04/IB_006.jpg</image:loc>
			<image:caption><![CDATA[IB_006]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/04/IB_002.jpg</image:loc>
			<image:caption><![CDATA[IB_002]]></image:caption>
		</image:image>
	</url>
	<url>
		<loc>https://www.wearedandy.com/project/texture/</loc>
		<lastmod>2018-11-07T14:01:41+00:00</lastmod>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/TX_004.jpg</image:loc>
			<image:title><![CDATA[TX_004]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/TX_001.jpg</image:loc>
			<image:caption><![CDATA[TX_001]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/TX_002.jpg</image:loc>
			<image:caption><![CDATA[TX_002]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/TX_003.jpg</image:loc>
			<image:caption><![CDATA[TX_003]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/TX_004.jpg</image:loc>
			<image:caption><![CDATA[TX_004]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/TX_005.jpg</image:loc>
			<image:caption><![CDATA[TX_005]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/TX_001.jpg</image:loc>
			<image:caption><![CDATA[TX_001]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/TX_002.jpg</image:loc>
			<image:caption><![CDATA[TX_002]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/TX_003.jpg</image:loc>
			<image:caption><![CDATA[TX_003]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/TX_004.jpg</image:loc>
			<image:caption><![CDATA[TX_004]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/TX_005.jpg</image:loc>
			<image:caption><![CDATA[TX_005]]></image:caption>
		</image:image>
	</url>
	<url>
		<loc>https://www.wearedandy.com/project/revolver/</loc>
		<lastmod>2018-11-07T14:54:10+00:00</lastmod>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2018/11/revolver1.png</image:loc>
			<image:title><![CDATA[revolver1]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2018/11/revolver1.png</image:loc>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2018/11/revolver2.png</image:loc>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2018/11/revolver3.png</image:loc>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2018/11/revolver1.png</image:loc>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2018/11/revolver2.png</image:loc>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2018/11/revolver3.png</image:loc>
		</image:image>
	</url>
	<url>
		<loc>https://www.wearedandy.com/project/andreaanzorena/</loc>
		<lastmod>2018-11-07T14:55:03+00:00</lastmod>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/AA_0001.jpg</image:loc>
			<image:title><![CDATA[AA_000]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/AA_001.jpg</image:loc>
			<image:caption><![CDATA[AA_001]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/AA_000.jpg</image:loc>
			<image:caption><![CDATA[AA_002]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/AA_004.jpg</image:loc>
			<image:caption><![CDATA[AA_003]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/AA_001.jpg</image:loc>
			<image:caption><![CDATA[AA_001]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/03/AA_002.jpg</image:loc>
			<image:caption><![CDATA[AA_002]]></image:caption>
		</image:image>
	</url>
	<url>
		<loc>https://www.wearedandy.com/project/nativetrees/</loc>
		<lastmod>2018-11-08T13:53:43+00:00</lastmod>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/NT_006.jpg</image:loc>
			<image:title><![CDATA[NT_006]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/NT_006.jpg</image:loc>
			<image:caption><![CDATA[NT_001]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/NT_003.jpg</image:loc>
			<image:caption><![CDATA[NT_002]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/NT_004.jpg</image:loc>
			<image:caption><![CDATA[NT_003]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/NT_005.jpg</image:loc>
			<image:caption><![CDATA[NT_004]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/NT_006.jpg</image:loc>
			<image:caption><![CDATA[NT_001]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/NT_003.jpg</image:loc>
			<image:caption><![CDATA[NT_002]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/NT_004.jpg</image:loc>
			<image:caption><![CDATA[NT_003]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/NT_005.jpg</image:loc>
			<image:caption><![CDATA[NT_004]]></image:caption>
		</image:image>
	</url>
	<url>
		<loc>https://www.wearedandy.com/project/pal/</loc>
		<lastmod>2018-11-08T14:39:20+00:00</lastmod>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/PL_001.jpg</image:loc>
			<image:title><![CDATA[PL_001]]></image:title>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/PL_001.jpg</image:loc>
			<image:caption><![CDATA[PL_001]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/PL_005.jpg</image:loc>
			<image:caption><![CDATA[PL_002]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/PL_002.jpg</image:loc>
			<image:caption><![CDATA[PL_003]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/PL_003.jpg</image:loc>
			<image:caption><![CDATA[PL_004]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/PL_004.jpg</image:loc>
			<image:caption><![CDATA[PL_005]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/PL_001.jpg</image:loc>
			<image:caption><![CDATA[PL_001]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/PL_005.jpg</image:loc>
			<image:caption><![CDATA[PL_002]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/PL_002.jpg</image:loc>
			<image:caption><![CDATA[PL_003]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/PL_003.jpg</image:loc>
			<image:caption><![CDATA[PL_004]]></image:caption>
		</image:image>
		<image:image>
			<image:loc>https://www.wearedandy.com/wp-content/uploads/2015/01/PL_004.jpg</image:loc>
			<image:caption><![CDATA[PL_005]]></image:caption>
		</image:image>
	</url>
</urlset>\";}}","no");
INSERT INTO `wp_options` VALUES ("63927","_transient_doing_cron","1576870259.4382390975952148437500","yes");
INSERT INTO `wp_options` VALUES ("63928","itsec-lock-backup","1576870440","no");


CREATE TABLE IF NOT EXISTS `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1721 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_postmeta` VALUES ("4","5","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES ("5","5","_edit_lock","1539013772:2");
INSERT INTO `wp_postmeta` VALUES ("6","5","_wp_page_template","home.php");
INSERT INTO `wp_postmeta` VALUES ("38","16","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES ("39","16","_wp_page_template","page-about.php");
INSERT INTO `wp_postmeta` VALUES ("40","16","_edit_lock","1547740757:2");
INSERT INTO `wp_postmeta` VALUES ("41","18","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES ("42","18","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES ("43","18","_menu_item_object_id","5");
INSERT INTO `wp_postmeta` VALUES ("44","18","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES ("45","18","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES ("46","18","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES ("47","18","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES ("48","18","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES ("50","19","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES ("51","19","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES ("52","19","_menu_item_object_id","16");
INSERT INTO `wp_postmeta` VALUES ("53","19","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES ("54","19","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES ("55","19","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES ("56","19","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES ("57","19","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES ("68","22","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES ("69","22","_edit_lock","1541598221:2");
INSERT INTO `wp_postmeta` VALUES ("73","24","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES ("74","24","field_54ac29a4ce78c","a:14:{s:3:\"key\";s:19:\"field_54ac29a4ce78c\";s:5:\"label\";s:8:\"Español\";s:4:\"name\";s:12:\"subtitle_esp\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";s:1:\"0\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:10:\"formatting\";s:4:\"html\";s:9:\"maxlength\";s:0:\"\";s:17:\"conditional_logic\";a:3:{s:6:\"status\";s:1:\"0\";s:5:\"rules\";a:1:{i:0;a:2:{s:5:\"field\";s:4:\"null\";s:8:\"operator\";s:2:\"==\";}}s:8:\"allorany\";s:3:\"all\";}s:8:\"order_no\";i:0;}");
INSERT INTO `wp_postmeta` VALUES ("75","24","field_54ac29b6ce78d","a:14:{s:3:\"key\";s:19:\"field_54ac29b6ce78d\";s:5:\"label\";s:7:\"English\";s:4:\"name\";s:12:\"subtitle_eng\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";s:1:\"0\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:10:\"formatting\";s:4:\"html\";s:9:\"maxlength\";s:0:\"\";s:17:\"conditional_logic\";a:3:{s:6:\"status\";s:1:\"0\";s:5:\"rules\";a:1:{i:0;a:2:{s:5:\"field\";s:4:\"null\";s:8:\"operator\";s:2:\"==\";}}s:8:\"allorany\";s:3:\"all\";}s:8:\"order_no\";i:1;}");
INSERT INTO `wp_postmeta` VALUES ("76","24","rule","a:5:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:5:\"works\";s:8:\"order_no\";i:0;s:8:\"group_no\";i:0;}");
INSERT INTO `wp_postmeta` VALUES ("77","24","position","normal");
INSERT INTO `wp_postmeta` VALUES ("78","24","layout","default");
INSERT INTO `wp_postmeta` VALUES ("79","24","hide_on_screen","");
INSERT INTO `wp_postmeta` VALUES ("80","24","_edit_lock","1537987282:2");
INSERT INTO `wp_postmeta` VALUES ("81","22","subtitle_esp","Desarrollo de Real Estate");
INSERT INTO `wp_postmeta` VALUES ("82","22","_subtitle_esp","field_54ac29a4ce78c");
INSERT INTO `wp_postmeta` VALUES ("83","22","subtitle_eng","Real Estate Development");
INSERT INTO `wp_postmeta` VALUES ("84","22","_subtitle_eng","field_54ac29b6ce78d");
INSERT INTO `wp_postmeta` VALUES ("85","25","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES ("86","25","_edit_lock","1541599161:2");
INSERT INTO `wp_postmeta` VALUES ("90","25","subtitle_esp","Bienes Raíces & Inversiones");
INSERT INTO `wp_postmeta` VALUES ("91","25","_subtitle_esp","field_54ac29a4ce78c");
INSERT INTO `wp_postmeta` VALUES ("92","25","subtitle_eng","Real Estate & Investments");
INSERT INTO `wp_postmeta` VALUES ("93","25","_subtitle_eng","field_54ac29b6ce78d");
INSERT INTO `wp_postmeta` VALUES ("100","30","_wp_attached_file","2015/01/royal-feat.png");
INSERT INTO `wp_postmeta` VALUES ("101","30","_wp_attachment_metadata","a:5:{s:5:\"width\";i:588;s:6:\"height\";i:320;s:4:\"file\";s:22:\"2015/01/royal-feat.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"royal-feat-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"royal-feat-300x163.png\";s:5:\"width\";i:300;s:6:\"height\";i:163;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("109","31","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES ("110","31","field_54ac3ffdec05f","a:11:{s:3:\"key\";s:19:\"field_54ac3ffdec05f\";s:5:\"label\";s:0:\"\";s:4:\"name\";s:12:\"middle_image\";s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";s:1:\"0\";s:11:\"save_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:17:\"conditional_logic\";a:3:{s:6:\"status\";s:1:\"0\";s:5:\"rules\";a:1:{i:0;a:3:{s:5:\"field\";s:4:\"null\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:0:\"\";}}s:8:\"allorany\";s:3:\"all\";}s:8:\"order_no\";i:0;}");
INSERT INTO `wp_postmeta` VALUES ("112","31","position","normal");
INSERT INTO `wp_postmeta` VALUES ("113","31","layout","default");
INSERT INTO `wp_postmeta` VALUES ("114","31","hide_on_screen","");
INSERT INTO `wp_postmeta` VALUES ("115","31","_edit_lock","1537987287:2");
INSERT INTO `wp_postmeta` VALUES ("118","33","middle_image","32");
INSERT INTO `wp_postmeta` VALUES ("119","33","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("120","5","middle_image","220");
INSERT INTO `wp_postmeta` VALUES ("121","5","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("122","34","middle_image","9");
INSERT INTO `wp_postmeta` VALUES ("123","34","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("124","35","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES ("125","35","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES ("126","35","_edit_lock","1537988541:2");
INSERT INTO `wp_postmeta` VALUES ("136","40","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES ("137","40","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES ("138","40","_edit_lock","1537987240:2");
INSERT INTO `wp_postmeta` VALUES ("139","42","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES ("140","42","_wp_page_template","page-contact.php");
INSERT INTO `wp_postmeta` VALUES ("141","42","_edit_lock","1541690065:2");
INSERT INTO `wp_postmeta` VALUES ("142","44","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES ("143","44","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES ("144","44","_menu_item_object_id","42");
INSERT INTO `wp_postmeta` VALUES ("145","44","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES ("146","44","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES ("147","44","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES ("148","44","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES ("149","44","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES ("160","46","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES ("161","46","_menu_item_menu_item_parent","349");
INSERT INTO `wp_postmeta` VALUES ("162","46","_menu_item_object_id","22");
INSERT INTO `wp_postmeta` VALUES ("163","46","_menu_item_object","works");
INSERT INTO `wp_postmeta` VALUES ("164","46","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES ("165","46","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES ("166","46","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES ("167","46","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES ("169","47","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES ("170","47","_menu_item_menu_item_parent","349");
INSERT INTO `wp_postmeta` VALUES ("171","47","_menu_item_object_id","25");
INSERT INTO `wp_postmeta` VALUES ("172","47","_menu_item_object","works");
INSERT INTO `wp_postmeta` VALUES ("173","47","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES ("174","47","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES ("175","47","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES ("176","47","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES ("187","50","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES ("188","50","field_54aec60b5808b","a:11:{s:3:\"key\";s:19:\"field_54aec60b5808b\";s:5:\"label\";s:0:\"\";s:4:\"name\";s:13:\"descatar_home\";s:4:\"type\";s:8:\"checkbox\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";s:1:\"0\";s:7:\"choices\";a:1:{s:2:\"si\";s:2:\"Si\";}s:13:\"default_value\";s:0:\"\";s:6:\"layout\";s:10:\"horizontal\";s:17:\"conditional_logic\";a:3:{s:6:\"status\";s:1:\"0\";s:5:\"rules\";a:1:{i:0;a:2:{s:5:\"field\";s:4:\"null\";s:8:\"operator\";s:2:\"==\";}}s:8:\"allorany\";s:3:\"all\";}s:8:\"order_no\";i:0;}");
INSERT INTO `wp_postmeta` VALUES ("189","50","rule","a:5:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:5:\"works\";s:8:\"order_no\";i:0;s:8:\"group_no\";i:0;}");
INSERT INTO `wp_postmeta` VALUES ("190","50","position","side");
INSERT INTO `wp_postmeta` VALUES ("191","50","layout","default");
INSERT INTO `wp_postmeta` VALUES ("192","50","hide_on_screen","");
INSERT INTO `wp_postmeta` VALUES ("193","50","_edit_lock","1537987291:2");
INSERT INTO `wp_postmeta` VALUES ("194","22","descatar_home","a:1:{i:0;s:2:\"si\";}");
INSERT INTO `wp_postmeta` VALUES ("195","22","_descatar_home","field_54aec60b5808b");
INSERT INTO `wp_postmeta` VALUES ("196","25","descatar_home","");
INSERT INTO `wp_postmeta` VALUES ("197","25","_descatar_home","field_54aec60b5808b");
INSERT INTO `wp_postmeta` VALUES ("201","51","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES ("202","51","descatar_home","a:1:{i:0;s:2:\"si\";}");
INSERT INTO `wp_postmeta` VALUES ("203","51","_descatar_home","field_54aec60b5808b");
INSERT INTO `wp_postmeta` VALUES ("204","51","subtitle_esp","Real Estate Development");
INSERT INTO `wp_postmeta` VALUES ("205","51","_subtitle_esp","field_54ac29a4ce78c");
INSERT INTO `wp_postmeta` VALUES ("206","51","subtitle_eng","Real Estate Development");
INSERT INTO `wp_postmeta` VALUES ("207","51","_subtitle_eng","field_54ac29b6ce78d");
INSERT INTO `wp_postmeta` VALUES ("208","51","_edit_lock","1541599128:2");
INSERT INTO `wp_postmeta` VALUES ("209","52","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES ("210","52","descatar_home","");
INSERT INTO `wp_postmeta` VALUES ("211","52","_descatar_home","field_54aec60b5808b");
INSERT INTO `wp_postmeta` VALUES ("212","52","subtitle_esp","Desarrollo de Bienes Raíces");
INSERT INTO `wp_postmeta` VALUES ("213","52","_subtitle_esp","field_54ac29a4ce78c");
INSERT INTO `wp_postmeta` VALUES ("214","52","subtitle_eng","Real Estate Development");
INSERT INTO `wp_postmeta` VALUES ("215","52","_subtitle_eng","field_54ac29b6ce78d");
INSERT INTO `wp_postmeta` VALUES ("216","52","_edit_lock","1541687848:2");
INSERT INTO `wp_postmeta` VALUES ("218","53","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES ("219","53","field_54aedcf0bf3de","a:11:{s:3:\"key\";s:19:\"field_54aedcf0bf3de\";s:5:\"label\";s:0:\"\";s:4:\"name\";s:13:\"imagen_header\";s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";s:1:\"0\";s:11:\"save_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:10:\"uploadedTo\";s:17:\"conditional_logic\";a:3:{s:6:\"status\";s:1:\"0\";s:5:\"rules\";a:1:{i:0;a:3:{s:5:\"field\";s:4:\"null\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:0:\"\";}}s:8:\"allorany\";s:3:\"all\";}s:8:\"order_no\";i:0;}");
INSERT INTO `wp_postmeta` VALUES ("221","53","position","normal");
INSERT INTO `wp_postmeta` VALUES ("222","53","layout","default");
INSERT INTO `wp_postmeta` VALUES ("223","53","hide_on_screen","");
INSERT INTO `wp_postmeta` VALUES ("224","53","_edit_lock","1537987275:2");
INSERT INTO `wp_postmeta` VALUES ("225","22","imagen_header","133");
INSERT INTO `wp_postmeta` VALUES ("226","22","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("231","52","imagen_header","159");
INSERT INTO `wp_postmeta` VALUES ("232","52","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("234","55","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES ("235","55","descatar_home","");
INSERT INTO `wp_postmeta` VALUES ("236","55","_descatar_home","field_54aec60b5808b");
INSERT INTO `wp_postmeta` VALUES ("237","55","subtitle_esp","Desarrollos & Negocio");
INSERT INTO `wp_postmeta` VALUES ("238","55","_subtitle_esp","field_54ac29a4ce78c");
INSERT INTO `wp_postmeta` VALUES ("239","55","subtitle_eng","Business & Developments");
INSERT INTO `wp_postmeta` VALUES ("240","55","_subtitle_eng","field_54ac29b6ce78d");
INSERT INTO `wp_postmeta` VALUES ("241","55","imagen_header","112");
INSERT INTO `wp_postmeta` VALUES ("242","55","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("243","55","_edit_lock","1541685375:2");
INSERT INTO `wp_postmeta` VALUES ("246","22","middle_image","142");
INSERT INTO `wp_postmeta` VALUES ("247","22","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("248","55","middle_image","113");
INSERT INTO `wp_postmeta` VALUES ("249","55","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("258","60","middle_image","9");
INSERT INTO `wp_postmeta` VALUES ("259","60","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("260","5","_rawhtml_settings","0,0,0,0");
INSERT INTO `wp_postmeta` VALUES ("261","64","middle_image","9");
INSERT INTO `wp_postmeta` VALUES ("262","64","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("263","16","_rawhtml_settings","0,0,0,0");
INSERT INTO `wp_postmeta` VALUES ("268","66","imagen_header","65");
INSERT INTO `wp_postmeta` VALUES ("269","66","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("270","16","imagen_header","254");
INSERT INTO `wp_postmeta` VALUES ("271","16","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("272","68","imagen_header","65");
INSERT INTO `wp_postmeta` VALUES ("273","68","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("274","69","imagen_header","65");
INSERT INTO `wp_postmeta` VALUES ("275","69","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("283","71","imagen_header","65");
INSERT INTO `wp_postmeta` VALUES ("284","71","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("285","71","the_boyz_0_the_boyz_item_img","");
INSERT INTO `wp_postmeta` VALUES ("286","71","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("287","71","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
SOCIO / DIRECTOR INTERACTIVE

Position as Creative Director of a Global Enterprise where my experience in Graphic Design, Product Design, Packaging, Management and Real Estate can be optimized.");
INSERT INTO `wp_postmeta` VALUES ("288","71","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("289","71","the_boyz","a:1:{i:0;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("290","71","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("291","16","the_boyz_0_the_boyz_item_img","211");
INSERT INTO `wp_postmeta` VALUES ("292","16","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("293","16","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming, Guillermo has a strong experience and knowhow of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("294","16","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("295","16","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("296","16","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("297","72","_wp_attached_file","2014/12/diego.jpg");
INSERT INTO `wp_postmeta` VALUES ("298","72","_wp_attachment_metadata","a:5:{s:5:\"width\";i:720;s:6:\"height\";i:680;s:4:\"file\";s:17:\"2014/12/diego.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"diego-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"diego-300x283.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:283;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("301","74","imagen_header","65");
INSERT INTO `wp_postmeta` VALUES ("302","74","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("303","74","the_boyz_0_the_boyz_item_img","73");
INSERT INTO `wp_postmeta` VALUES ("304","74","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("305","74","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
SOCIO / DIRECTOR INTERACTIVE

Position as Creative Director of a Global Enterprise where my experience in Graphic Design, Product Design, Packaging, Management and Real Estate can be optimized.");
INSERT INTO `wp_postmeta` VALUES ("306","74","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("307","74","the_boyz","a:1:{i:0;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("308","74","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("309","75","imagen_header","65");
INSERT INTO `wp_postmeta` VALUES ("310","75","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("311","75","the_boyz_0_the_boyz_item_img","73");
INSERT INTO `wp_postmeta` VALUES ("312","75","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("313","75","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
SOCIO / DIRECTOR INTERACTIVE

Position as Creative Director of a Global Enterprise where my experience in Graphic Design, Product Design, Packaging, Management and Real Estate can be optimized.");
INSERT INTO `wp_postmeta` VALUES ("314","75","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("315","75","the_boyz_1_the_boyz_item_img","72");
INSERT INTO `wp_postmeta` VALUES ("316","75","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("317","75","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
SOCIO / DIRECTOR CREATIVO

Position as Creative Director of a Global Enterprise where my experience in Graphic Design, Product Design, Packaging, Management and Real Estate can be optimized.");
INSERT INTO `wp_postmeta` VALUES ("318","75","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("319","75","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("320","75","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("321","16","the_boyz_1_the_boyz_item_img","");
INSERT INTO `wp_postmeta` VALUES ("322","16","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("323","16","the_boyz_1_the_boyz_item_txt","");
INSERT INTO `wp_postmeta` VALUES ("324","16","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("325","76","_wp_attached_file","2014/12/guille.jpg");
INSERT INTO `wp_postmeta` VALUES ("326","76","_wp_attachment_metadata","a:5:{s:5:\"width\";i:720;s:6:\"height\";i:680;s:4:\"file\";s:18:\"2014/12/guille.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"guille-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"guille-300x283.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:283;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("327","77","imagen_header","65");
INSERT INTO `wp_postmeta` VALUES ("328","77","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("329","77","the_boyz_0_the_boyz_item_img","76");
INSERT INTO `wp_postmeta` VALUES ("330","77","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("331","77","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
SOCIO / DIRECTOR INTERACTIVE

Position as Creative Director of a Global Enterprise where my experience in Graphic Design, Product Design, Packaging, Management and Real Estate can be optimized.");
INSERT INTO `wp_postmeta` VALUES ("332","77","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("333","77","the_boyz_1_the_boyz_item_img","72");
INSERT INTO `wp_postmeta` VALUES ("334","77","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("335","77","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
SOCIO / DIRECTOR CREATIVO

Position as Creative Director of a Global Enterprise where my experience in Graphic Design, Product Design, Packaging, Management and Real Estate can be optimized.");
INSERT INTO `wp_postmeta` VALUES ("336","77","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("337","77","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("338","77","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("339","42","_rawhtml_settings","0,0,0,0");
INSERT INTO `wp_postmeta` VALUES ("340","53","rule","a:5:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:5:\"works\";s:8:\"order_no\";i:0;s:8:\"group_no\";i:0;}");
INSERT INTO `wp_postmeta` VALUES ("341","53","rule","a:5:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:14:\"page-about.php\";s:8:\"order_no\";i:0;s:8:\"group_no\";i:1;}");
INSERT INTO `wp_postmeta` VALUES ("342","53","rule","a:5:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:16:\"page-contact.php\";s:8:\"order_no\";i:0;s:8:\"group_no\";i:2;}");
INSERT INTO `wp_postmeta` VALUES ("345","79","imagen_header","78");
INSERT INTO `wp_postmeta` VALUES ("346","79","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("347","42","imagen_header","380");
INSERT INTO `wp_postmeta` VALUES ("348","42","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("349","80","imagen_header","78");
INSERT INTO `wp_postmeta` VALUES ("350","80","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("351","81","imagen_header","78");
INSERT INTO `wp_postmeta` VALUES ("352","81","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("353","31","rule","a:5:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:8:\"home.php\";s:8:\"order_no\";i:0;s:8:\"group_no\";i:0;}");
INSERT INTO `wp_postmeta` VALUES ("354","31","rule","a:5:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:5:\"works\";s:8:\"order_no\";i:0;s:8:\"group_no\";i:1;}");
INSERT INTO `wp_postmeta` VALUES ("355","31","rule","a:5:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:16:\"page-contact.php\";s:8:\"order_no\";i:0;s:8:\"group_no\";i:2;}");
INSERT INTO `wp_postmeta` VALUES ("358","83","middle_image","82");
INSERT INTO `wp_postmeta` VALUES ("359","83","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("360","83","imagen_header","78");
INSERT INTO `wp_postmeta` VALUES ("361","83","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("362","42","middle_image","263");
INSERT INTO `wp_postmeta` VALUES ("363","42","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("378","92","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES ("379","92","_edit_lock","1541599107:2");
INSERT INTO `wp_postmeta` VALUES ("380","94","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES ("381","94","_edit_lock","1541602375:2");
INSERT INTO `wp_postmeta` VALUES ("382","94","descatar_home","");
INSERT INTO `wp_postmeta` VALUES ("383","94","_descatar_home","field_54aec60b5808b");
INSERT INTO `wp_postmeta` VALUES ("384","94","subtitle_esp","Branding, diseño y programación");
INSERT INTO `wp_postmeta` VALUES ("385","94","_subtitle_esp","field_54ac29a4ce78c");
INSERT INTO `wp_postmeta` VALUES ("386","94","subtitle_eng","Branding, design & programming");
INSERT INTO `wp_postmeta` VALUES ("387","94","_subtitle_eng","field_54ac29b6ce78d");
INSERT INTO `wp_postmeta` VALUES ("388","94","imagen_header","98");
INSERT INTO `wp_postmeta` VALUES ("389","94","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("390","94","middle_image","239");
INSERT INTO `wp_postmeta` VALUES ("391","94","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("394","97","_wp_attached_file","2015/03/AA_0021.jpg");
INSERT INTO `wp_postmeta` VALUES ("395","97","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:19:\"2015/03/AA_0021.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"AA_0021-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"AA_0021-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"AA_0021-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("397","98","_wp_attached_file","2015/03/AA_header.jpg");
INSERT INTO `wp_postmeta` VALUES ("398","98","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1080;s:4:\"file\";s:21:\"2015/03/AA_header.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"AA_header-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"AA_header-300x168.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:168;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"AA_header-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("411","105","_wp_attached_file","2015/03/AA_002.jpg");
INSERT INTO `wp_postmeta` VALUES ("412","105","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/AA_002.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AA_002-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AA_002-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"AA_002-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("415","107","_wp_attached_file","2015/03/AA_001.jpg");
INSERT INTO `wp_postmeta` VALUES ("416","107","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/AA_001.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AA_001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AA_001-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"AA_001-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("417","110","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES ("418","110","_menu_item_menu_item_parent","349");
INSERT INTO `wp_postmeta` VALUES ("419","110","_menu_item_object_id","94");
INSERT INTO `wp_postmeta` VALUES ("420","110","_menu_item_object","works");
INSERT INTO `wp_postmeta` VALUES ("421","110","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES ("422","110","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES ("423","110","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES ("424","110","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES ("426","112","_wp_attached_file","2015/01/NT_002.jpg");
INSERT INTO `wp_postmeta` VALUES ("427","112","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1213;s:4:\"file\";s:18:\"2015/01/NT_002.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"NT_002-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"NT_002-300x187.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:187;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"NT_002-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("428","113","_wp_attached_file","2015/01/NT_001.jpg");
INSERT INTO `wp_postmeta` VALUES ("429","113","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1213;s:4:\"file\";s:18:\"2015/01/NT_001.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"NT_001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"NT_001-300x187.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:187;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"NT_001-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("430","114","_wp_attached_file","2015/01/NT_006.jpg");
INSERT INTO `wp_postmeta` VALUES ("431","114","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/NT_006.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"NT_006-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"NT_006-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"NT_006-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("432","115","_wp_attached_file","2015/01/NT_005.jpg");
INSERT INTO `wp_postmeta` VALUES ("433","115","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/NT_005.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"NT_005-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"NT_005-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"NT_005-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("434","116","_wp_attached_file","2015/01/NT_004.jpg");
INSERT INTO `wp_postmeta` VALUES ("435","116","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/NT_004.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"NT_004-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"NT_004-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"NT_004-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("436","117","_wp_attached_file","2015/01/NT_003.jpg");
INSERT INTO `wp_postmeta` VALUES ("437","117","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/NT_003.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"NT_003-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"NT_003-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"NT_003-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("438","55","_thumbnail_id","114");
INSERT INTO `wp_postmeta` VALUES ("439","118","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES ("440","118","_menu_item_menu_item_parent","349");
INSERT INTO `wp_postmeta` VALUES ("441","118","_menu_item_object_id","55");
INSERT INTO `wp_postmeta` VALUES ("442","118","_menu_item_object","works");
INSERT INTO `wp_postmeta` VALUES ("443","118","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES ("444","118","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES ("445","118","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES ("446","118","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES ("448","92","descatar_home","a:1:{i:0;s:2:\"si\";}");
INSERT INTO `wp_postmeta` VALUES ("449","92","_descatar_home","field_54aec60b5808b");
INSERT INTO `wp_postmeta` VALUES ("450","92","subtitle_esp","Digital & Gourmet");
INSERT INTO `wp_postmeta` VALUES ("451","92","_subtitle_esp","field_54ac29a4ce78c");
INSERT INTO `wp_postmeta` VALUES ("452","92","subtitle_eng","Digital & Gourmet");
INSERT INTO `wp_postmeta` VALUES ("453","92","_subtitle_eng","field_54ac29b6ce78d");
INSERT INTO `wp_postmeta` VALUES ("454","92","imagen_header","128");
INSERT INTO `wp_postmeta` VALUES ("455","92","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("456","92","middle_image","129");
INSERT INTO `wp_postmeta` VALUES ("457","92","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("470","125","_wp_attached_file","2015/03/PR_001.jpg");
INSERT INTO `wp_postmeta` VALUES ("471","125","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/PR_001.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"PR_001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"PR_001-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"PR_001-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("472","126","_wp_attached_file","2015/03/PR_002.jpg");
INSERT INTO `wp_postmeta` VALUES ("473","126","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/PR_002.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"PR_002-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"PR_002-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"PR_002-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("474","127","_wp_attached_file","2015/03/PR_003.jpg");
INSERT INTO `wp_postmeta` VALUES ("475","127","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/PR_003.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"PR_003-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"PR_003-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"PR_003-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("476","128","_wp_attached_file","2015/03/PR_004.jpg");
INSERT INTO `wp_postmeta` VALUES ("477","128","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/PR_004.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"PR_004-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"PR_004-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"PR_004-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("478","129","_wp_attached_file","2015/03/PR_005.jpg");
INSERT INTO `wp_postmeta` VALUES ("479","129","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/PR_005.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"PR_005-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"PR_005-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"PR_005-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("480","92","_thumbnail_id","127");
INSERT INTO `wp_postmeta` VALUES ("499","130","descatar_home","a:1:{i:0;s:2:\"si\";}");
INSERT INTO `wp_postmeta` VALUES ("500","130","_descatar_home","field_54aec60b5808b");
INSERT INTO `wp_postmeta` VALUES ("501","130","subtitle_esp","Digital & Gourmet");
INSERT INTO `wp_postmeta` VALUES ("502","130","_subtitle_esp","field_54ac29a4ce78c");
INSERT INTO `wp_postmeta` VALUES ("503","130","subtitle_eng","Digital & Gourmet");
INSERT INTO `wp_postmeta` VALUES ("504","130","_subtitle_eng","field_54ac29b6ce78d");
INSERT INTO `wp_postmeta` VALUES ("505","130","imagen_header","128");
INSERT INTO `wp_postmeta` VALUES ("506","130","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("507","130","middle_image","129");
INSERT INTO `wp_postmeta` VALUES ("508","130","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("509","133","_wp_attached_file","2015/01/AK_008.jpg");
INSERT INTO `wp_postmeta` VALUES ("510","133","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/AK_008.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AK_008-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AK_008-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"AK_008-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("513","135","_wp_attached_file","2015/01/AK_006.jpg");
INSERT INTO `wp_postmeta` VALUES ("514","135","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/AK_006.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AK_006-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AK_006-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"AK_006-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("515","136","_wp_attached_file","2015/01/AK_005.jpg");
INSERT INTO `wp_postmeta` VALUES ("516","136","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/AK_005.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AK_005-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AK_005-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"AK_005-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("517","137","_wp_attached_file","2015/01/AK_004.jpg");
INSERT INTO `wp_postmeta` VALUES ("518","137","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/AK_004.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AK_004-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AK_004-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"AK_004-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("521","139","_wp_attached_file","2015/01/AK_002.jpg");
INSERT INTO `wp_postmeta` VALUES ("522","139","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/AK_002.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AK_002-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AK_002-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"AK_002-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("523","140","_wp_attached_file","2015/01/AK_001.jpg");
INSERT INTO `wp_postmeta` VALUES ("524","140","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/AK_001.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AK_001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AK_001-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"AK_001-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("525","22","_thumbnail_id","139");
INSERT INTO `wp_postmeta` VALUES ("529","142","_wp_attached_file","2015/01/AK_007.jpg");
INSERT INTO `wp_postmeta` VALUES ("530","142","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/AK_007.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AK_007-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AK_007-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"AK_007-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("531","25","imagen_header","150");
INSERT INTO `wp_postmeta` VALUES ("532","25","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("533","25","middle_image","149");
INSERT INTO `wp_postmeta` VALUES ("534","25","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("535","144","_wp_attached_file","2015/01/TX_001.jpg");
INSERT INTO `wp_postmeta` VALUES ("536","144","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/TX_001.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"TX_001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"TX_001-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"TX_001-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("537","145","_wp_attached_file","2015/01/TX_002.jpg");
INSERT INTO `wp_postmeta` VALUES ("538","145","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/TX_002.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"TX_002-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"TX_002-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"TX_002-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("539","146","_wp_attached_file","2015/01/TX_003.jpg");
INSERT INTO `wp_postmeta` VALUES ("540","146","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/TX_003.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"TX_003-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"TX_003-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"TX_003-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("541","147","_wp_attached_file","2015/01/TX_004.jpg");
INSERT INTO `wp_postmeta` VALUES ("542","147","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/TX_004.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"TX_004-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"TX_004-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"TX_004-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("543","148","_wp_attached_file","2015/01/TX_005.jpg");
INSERT INTO `wp_postmeta` VALUES ("544","148","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/TX_005.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"TX_005-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"TX_005-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"TX_005-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("545","149","_wp_attached_file","2015/01/TX_006.jpg");
INSERT INTO `wp_postmeta` VALUES ("546","149","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1440;s:6:\"height\";i:900;s:4:\"file\";s:18:\"2015/01/TX_006.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"TX_006-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"TX_006-300x187.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:187;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"TX_006-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("547","150","_wp_attached_file","2015/01/TX_008.jpg");
INSERT INTO `wp_postmeta` VALUES ("548","150","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/TX_008.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"TX_008-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"TX_008-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"TX_008-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("549","25","_thumbnail_id","147");
INSERT INTO `wp_postmeta` VALUES ("552","152","_wp_attached_file","2015/01/PL_001.jpg");
INSERT INTO `wp_postmeta` VALUES ("553","152","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/PL_001.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"PL_001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"PL_001-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"PL_001-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("554","153","_wp_attached_file","2015/01/PL_002.jpg");
INSERT INTO `wp_postmeta` VALUES ("555","153","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/PL_002.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"PL_002-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"PL_002-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"PL_002-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("556","154","_wp_attached_file","2015/01/PL_003.jpg");
INSERT INTO `wp_postmeta` VALUES ("557","154","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/PL_003.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"PL_003-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"PL_003-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"PL_003-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("558","155","_wp_attached_file","2015/01/PL_004.jpg");
INSERT INTO `wp_postmeta` VALUES ("559","155","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/PL_004.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"PL_004-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"PL_004-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"PL_004-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("560","156","_wp_attached_file","2015/01/PL_005.jpg");
INSERT INTO `wp_postmeta` VALUES ("561","156","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/PL_005.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"PL_005-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"PL_005-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"PL_005-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("564","158","_wp_attached_file","2015/01/PL_007.jpg");
INSERT INTO `wp_postmeta` VALUES ("565","158","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/PL_007.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"PL_007-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"PL_007-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"PL_007-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("566","52","_thumbnail_id","152");
INSERT INTO `wp_postmeta` VALUES ("567","159","_wp_attached_file","2015/01/PL_006.jpg");
INSERT INTO `wp_postmeta` VALUES ("568","159","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/PL_006.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"PL_006-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"PL_006-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"PL_006-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("569","52","middle_image","158");
INSERT INTO `wp_postmeta` VALUES ("570","52","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("580","161","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES ("581","161","_menu_item_menu_item_parent","349");
INSERT INTO `wp_postmeta` VALUES ("582","161","_menu_item_object_id","52");
INSERT INTO `wp_postmeta` VALUES ("583","161","_menu_item_object","works");
INSERT INTO `wp_postmeta` VALUES ("584","161","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES ("585","161","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES ("586","161","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES ("587","161","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES ("589","51","imagen_header","170");
INSERT INTO `wp_postmeta` VALUES ("590","51","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("591","51","middle_image","167");
INSERT INTO `wp_postmeta` VALUES ("592","51","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("593","163","_wp_attached_file","2015/01/ZN_001.jpg");
INSERT INTO `wp_postmeta` VALUES ("594","163","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/ZN_001.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"ZN_001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"ZN_001-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"ZN_001-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("595","164","_wp_attached_file","2015/01/ZN_002.jpg");
INSERT INTO `wp_postmeta` VALUES ("596","164","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/ZN_002.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"ZN_002-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"ZN_002-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"ZN_002-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("597","165","_wp_attached_file","2015/01/ZN_003.jpg");
INSERT INTO `wp_postmeta` VALUES ("598","165","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/ZN_003.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"ZN_003-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"ZN_003-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"ZN_003-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("601","167","_wp_attached_file","2015/01/ZN_005.jpg");
INSERT INTO `wp_postmeta` VALUES ("602","167","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/ZN_005.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"ZN_005-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"ZN_005-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"ZN_005-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("603","51","_thumbnail_id","164");
INSERT INTO `wp_postmeta` VALUES ("615","170","_wp_attached_file","2015/01/ZN_006.jpg");
INSERT INTO `wp_postmeta` VALUES ("616","170","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/ZN_006.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"ZN_006-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"ZN_006-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"ZN_006-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("617","94","_wp_old_slug","andrea-anzorena-sculptures");
INSERT INTO `wp_postmeta` VALUES ("618","55","_wp_old_slug","native-trees");
INSERT INTO `wp_postmeta` VALUES ("619","22","_wp_old_slug","al-khail-heights");
INSERT INTO `wp_postmeta` VALUES ("620","51","_wp_old_slug","zaya-nurai-island");
INSERT INTO `wp_postmeta` VALUES ("621","172","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES ("622","172","_edit_lock","1426258789:1");
INSERT INTO `wp_postmeta` VALUES ("623","173","_wp_attached_file","2015/03/RE_009.jpg");
INSERT INTO `wp_postmeta` VALUES ("624","173","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/RE_009.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"RE_009-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"RE_009-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"RE_009-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("625","174","_wp_attached_file","2015/03/RE_008.jpg");
INSERT INTO `wp_postmeta` VALUES ("626","174","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/RE_008.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"RE_008-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"RE_008-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"RE_008-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("629","176","_wp_attached_file","2015/03/RE_007.jpg");
INSERT INTO `wp_postmeta` VALUES ("630","176","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/RE_007.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"RE_007-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"RE_007-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"RE_007-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:22:\"Copyright: Jason Leiva\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("631","177","_wp_attached_file","2015/03/RE_000.jpg");
INSERT INTO `wp_postmeta` VALUES ("632","177","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/RE_000.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"RE_000-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"RE_000-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"RE_000-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("637","180","_wp_attached_file","2015/03/RE_004.jpg");
INSERT INTO `wp_postmeta` VALUES ("638","180","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/RE_004.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"RE_004-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"RE_004-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"RE_004-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("639","181","_wp_attached_file","2015/03/RE_002.jpg");
INSERT INTO `wp_postmeta` VALUES ("640","181","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/RE_002.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"RE_002-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"RE_002-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"RE_002-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("641","182","_wp_attached_file","2015/03/RE_001.jpg");
INSERT INTO `wp_postmeta` VALUES ("642","182","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/RE_001.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"RE_001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"RE_001-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"RE_001-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("643","172","descatar_home","a:1:{i:0;s:2:\"si\";}");
INSERT INTO `wp_postmeta` VALUES ("644","172","_descatar_home","field_54aec60b5808b");
INSERT INTO `wp_postmeta` VALUES ("645","172","subtitle_esp","Branding e Identidad");
INSERT INTO `wp_postmeta` VALUES ("646","172","_subtitle_esp","field_54ac29a4ce78c");
INSERT INTO `wp_postmeta` VALUES ("647","172","subtitle_eng","Branding & Identity");
INSERT INTO `wp_postmeta` VALUES ("648","172","_subtitle_eng","field_54ac29b6ce78d");
INSERT INTO `wp_postmeta` VALUES ("649","172","imagen_header","188");
INSERT INTO `wp_postmeta` VALUES ("650","172","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("651","172","middle_image","173");
INSERT INTO `wp_postmeta` VALUES ("652","172","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("653","183","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES ("654","183","_menu_item_menu_item_parent","349");
INSERT INTO `wp_postmeta` VALUES ("655","183","_menu_item_object_id","172");
INSERT INTO `wp_postmeta` VALUES ("656","183","_menu_item_object","works");
INSERT INTO `wp_postmeta` VALUES ("657","183","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES ("658","183","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES ("659","183","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES ("660","183","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES ("662","184","_wp_attached_file","2015/03/RE_010.jpg");
INSERT INTO `wp_postmeta` VALUES ("663","184","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/RE_010.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"RE_010-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"RE_010-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"RE_010-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("664","185","_wp_attached_file","2015/03/RE_012.jpg");
INSERT INTO `wp_postmeta` VALUES ("665","185","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/RE_012.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"RE_012-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"RE_012-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"RE_012-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("666","186","_wp_attached_file","2015/03/RE_011.jpg");
INSERT INTO `wp_postmeta` VALUES ("667","186","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/RE_011.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"RE_011-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"RE_011-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"RE_011-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:22:\"Copyright: Jason Leiva\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("668","172","_thumbnail_id","186");
INSERT INTO `wp_postmeta` VALUES ("669","188","_wp_attached_file","2015/03/RE_014.jpg");
INSERT INTO `wp_postmeta` VALUES ("670","188","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/RE_014.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"RE_014-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"RE_014-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"RE_014-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("671","189","_wp_attached_file","2015/03/RE_013.jpg");
INSERT INTO `wp_postmeta` VALUES ("672","189","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/RE_013.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"RE_013-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"RE_013-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"RE_013-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("673","190","imagen_header","65");
INSERT INTO `wp_postmeta` VALUES ("674","190","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("675","190","the_boyz_0_the_boyz_item_img","76");
INSERT INTO `wp_postmeta` VALUES ("676","190","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("677","190","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming, Guillermo has a strong experience and know how of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("678","190","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("679","190","the_boyz_1_the_boyz_item_img","72");
INSERT INTO `wp_postmeta` VALUES ("680","190","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("681","190","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience in Branding, Identity, Graphic Design, Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("682","190","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("683","190","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("684","190","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("685","191","imagen_header","65");
INSERT INTO `wp_postmeta` VALUES ("686","191","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("687","191","the_boyz_0_the_boyz_item_img","76");
INSERT INTO `wp_postmeta` VALUES ("688","191","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("689","191","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming,
Guillermo has a strong experience and know how
of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("690","191","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("691","191","the_boyz_1_the_boyz_item_img","72");
INSERT INTO `wp_postmeta` VALUES ("692","191","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("693","191","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience
in Branding, Identity, Graphic Design,
Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("694","191","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("695","191","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("696","191","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("697","192","imagen_header","65");
INSERT INTO `wp_postmeta` VALUES ("698","192","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("699","192","the_boyz_0_the_boyz_item_img","76");
INSERT INTO `wp_postmeta` VALUES ("700","192","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("701","192","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming,
Guillermo has a strong experience and know how
of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("702","192","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("703","192","the_boyz_1_the_boyz_item_img","72");
INSERT INTO `wp_postmeta` VALUES ("704","192","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("705","192","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience
in Branding, Identity, Graphic Design,
Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("706","192","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("707","192","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("708","192","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("709","193","imagen_header","65");
INSERT INTO `wp_postmeta` VALUES ("710","193","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("711","193","the_boyz_0_the_boyz_item_img","76");
INSERT INTO `wp_postmeta` VALUES ("712","193","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("713","193","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming,
Guillermo has a strong experience and know how
of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("714","193","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("715","193","the_boyz_1_the_boyz_item_img","72");
INSERT INTO `wp_postmeta` VALUES ("716","193","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("717","193","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience
in Branding, Identity, Graphic Design,
Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("718","193","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("719","193","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("720","193","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("721","194","imagen_header","65");
INSERT INTO `wp_postmeta` VALUES ("722","194","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("723","194","the_boyz_0_the_boyz_item_img","76");
INSERT INTO `wp_postmeta` VALUES ("724","194","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("725","194","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming,
Guillermo has a strong experience and know how
of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("726","194","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("727","194","the_boyz_1_the_boyz_item_img","72");
INSERT INTO `wp_postmeta` VALUES ("728","194","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("729","194","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience
in Branding, Identity, Graphic Design,
Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("730","194","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("731","194","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("732","194","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("733","195","imagen_header","65");
INSERT INTO `wp_postmeta` VALUES ("734","195","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("735","195","the_boyz_0_the_boyz_item_img","76");
INSERT INTO `wp_postmeta` VALUES ("736","195","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("737","195","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming,
Guillermo has a strong experience and know how
of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("738","195","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("739","195","the_boyz_1_the_boyz_item_img","72");
INSERT INTO `wp_postmeta` VALUES ("740","195","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("741","195","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience
in Branding, Identity, Graphic Design,
Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("742","195","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("743","195","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("744","195","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("745","196","imagen_header","65");
INSERT INTO `wp_postmeta` VALUES ("746","196","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("747","196","the_boyz_0_the_boyz_item_img","76");
INSERT INTO `wp_postmeta` VALUES ("748","196","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("749","196","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming,
Guillermo has a strong experience and know how
of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("750","196","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("751","196","the_boyz_1_the_boyz_item_img","72");
INSERT INTO `wp_postmeta` VALUES ("752","196","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("753","196","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience
in Branding, Identity, Graphic Design,
Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("754","196","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("755","196","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("756","196","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("757","197","imagen_header","65");
INSERT INTO `wp_postmeta` VALUES ("758","197","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("759","197","the_boyz_0_the_boyz_item_img","76");
INSERT INTO `wp_postmeta` VALUES ("760","197","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("761","197","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming,
Guillermo has a strong experience and know how
of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("762","197","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("763","197","the_boyz_1_the_boyz_item_img","72");
INSERT INTO `wp_postmeta` VALUES ("764","197","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("765","197","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience
in Branding, Identity, Graphic Design,
Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("766","197","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("767","197","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("768","197","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("769","198","_wp_attached_file","2014/12/AU_003.jpg");
INSERT INTO `wp_postmeta` VALUES ("770","198","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2014/12/AU_003.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AU_003-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AU_003-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"AU_003-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("771","199","imagen_header","198");
INSERT INTO `wp_postmeta` VALUES ("772","199","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("773","199","the_boyz_0_the_boyz_item_img","76");
INSERT INTO `wp_postmeta` VALUES ("774","199","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("775","199","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming,
Guillermo has a strong experience and know how
of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("776","199","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("777","199","the_boyz_1_the_boyz_item_img","72");
INSERT INTO `wp_postmeta` VALUES ("778","199","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("779","199","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience
in Branding, Identity, Graphic Design,
Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("780","199","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("781","199","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("782","199","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("783","201","middle_image","82");
INSERT INTO `wp_postmeta` VALUES ("784","201","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("785","201","imagen_header","78");
INSERT INTO `wp_postmeta` VALUES ("786","201","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("791","204","middle_image","203");
INSERT INTO `wp_postmeta` VALUES ("792","204","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("793","204","imagen_header","78");
INSERT INTO `wp_postmeta` VALUES ("794","204","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("795","206","imagen_header","198");
INSERT INTO `wp_postmeta` VALUES ("796","206","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("797","206","the_boyz_0_the_boyz_item_img","76");
INSERT INTO `wp_postmeta` VALUES ("798","206","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("799","206","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming,
Guillermo has a strong experience and know how
of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("800","206","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("801","206","the_boyz_1_the_boyz_item_img","72");
INSERT INTO `wp_postmeta` VALUES ("802","206","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("803","206","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience
in Branding, Identity, Graphic Design,
Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("804","206","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("805","206","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("806","206","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("807","207","imagen_header","198");
INSERT INTO `wp_postmeta` VALUES ("808","207","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("809","207","the_boyz_0_the_boyz_item_img","76");
INSERT INTO `wp_postmeta` VALUES ("810","207","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("811","207","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming,
Guillermo has a strong experience and know how
of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("812","207","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("813","207","the_boyz_1_the_boyz_item_img","72");
INSERT INTO `wp_postmeta` VALUES ("814","207","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("815","207","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience
in Branding, Identity, Graphic Design,
Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("816","207","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("817","207","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("818","207","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("819","208","imagen_header","198");
INSERT INTO `wp_postmeta` VALUES ("820","208","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("821","208","the_boyz_0_the_boyz_item_img","76");
INSERT INTO `wp_postmeta` VALUES ("822","208","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("823","208","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming,
Guillermo has a strong experience and know how
of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("824","208","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("825","208","the_boyz_1_the_boyz_item_img","72");
INSERT INTO `wp_postmeta` VALUES ("826","208","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("827","208","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience
in Branding, Identity, Graphic Design,
Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("828","208","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("829","208","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("830","208","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("831","209","imagen_header","198");
INSERT INTO `wp_postmeta` VALUES ("832","209","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("833","209","the_boyz_0_the_boyz_item_img","76");
INSERT INTO `wp_postmeta` VALUES ("834","209","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("835","209","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming,
Guillermo has a strong experience and know how
of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("836","209","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("837","209","the_boyz_1_the_boyz_item_img","72");
INSERT INTO `wp_postmeta` VALUES ("838","209","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("839","209","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience
in Branding, Identity, Graphic Design,
Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("840","209","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("841","209","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("842","209","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("843","210","imagen_header","198");
INSERT INTO `wp_postmeta` VALUES ("844","210","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("845","210","the_boyz_0_the_boyz_item_img","76");
INSERT INTO `wp_postmeta` VALUES ("846","210","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("847","210","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming,
Guillermo has a strong experience and know how
of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("848","210","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("849","210","the_boyz_1_the_boyz_item_img","72");
INSERT INTO `wp_postmeta` VALUES ("850","210","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("851","210","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience
in Branding, Identity, Graphic Design,
Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("852","210","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("853","210","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("854","210","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("855","211","_wp_attached_file","2014/12/AU_004.jpg");
INSERT INTO `wp_postmeta` VALUES ("856","211","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1080;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2014/12/AU_004.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AU_004-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AU_004-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"AU_004-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("857","212","_wp_attached_file","2014/12/AU_005.jpg");
INSERT INTO `wp_postmeta` VALUES ("858","212","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1080;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2014/12/AU_005.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AU_005-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AU_005-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"AU_005-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("859","213","imagen_header","198");
INSERT INTO `wp_postmeta` VALUES ("860","213","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("861","213","the_boyz_0_the_boyz_item_img","211");
INSERT INTO `wp_postmeta` VALUES ("862","213","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("863","213","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming,
Guillermo has a strong experience and know how
of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("864","213","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("865","213","the_boyz_1_the_boyz_item_img","212");
INSERT INTO `wp_postmeta` VALUES ("866","213","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("867","213","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience
in Branding, Identity, Graphic Design,
Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("868","213","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("869","213","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("870","213","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("871","214","imagen_header","198");
INSERT INTO `wp_postmeta` VALUES ("872","214","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("873","214","the_boyz_0_the_boyz_item_img","211");
INSERT INTO `wp_postmeta` VALUES ("874","214","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("875","214","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming,
Guillermo has a strong experience and know how
of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("876","214","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("877","214","the_boyz_1_the_boyz_item_img","212");
INSERT INTO `wp_postmeta` VALUES ("878","214","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("879","214","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience
in Branding, Identity, Graphic Design,
Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("880","214","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("881","214","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("882","214","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("883","215","_wp_attached_file","2015/01/CT000.jpg");
INSERT INTO `wp_postmeta` VALUES ("884","215","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:17:\"2015/01/CT000.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"CT000-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"CT000-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:18:\"CT000-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("885","216","middle_image","203");
INSERT INTO `wp_postmeta` VALUES ("886","216","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("887","216","imagen_header","215");
INSERT INTO `wp_postmeta` VALUES ("888","216","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("889","217","middle_image","9");
INSERT INTO `wp_postmeta` VALUES ("890","217","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("893","219","_wp_attached_file","2014/11/AK_007.jpg");
INSERT INTO `wp_postmeta` VALUES ("894","219","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2014/11/AK_007.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AK_007-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AK_007-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"AK_007-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("895","220","_wp_attached_file","2014/11/NT_001.jpg");
INSERT INTO `wp_postmeta` VALUES ("896","220","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2014/11/NT_001.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"NT_001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"NT_001-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"NT_001-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("897","221","_wp_attached_file","2014/11/PL_002.jpg");
INSERT INTO `wp_postmeta` VALUES ("898","221","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2014/11/PL_002.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"PL_002-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"PL_002-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"PL_002-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("899","222","_wp_attached_file","2014/11/PR_005.jpg");
INSERT INTO `wp_postmeta` VALUES ("900","222","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2014/11/PR_005.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"PR_005-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"PR_005-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"PR_005-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("905","225","_wp_attached_file","2014/11/RE_007.jpg");
INSERT INTO `wp_postmeta` VALUES ("906","225","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2014/11/RE_007.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"RE_007-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"RE_007-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"RE_007-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:22:\"Copyright: Jason Leiva\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("907","226","middle_image","225");
INSERT INTO `wp_postmeta` VALUES ("908","226","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("909","227","_wp_attached_file","2014/11/RE_004.jpg");
INSERT INTO `wp_postmeta` VALUES ("910","227","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2014/11/RE_004.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"RE_004-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"RE_004-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"RE_004-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("911","229","imagen_header","198");
INSERT INTO `wp_postmeta` VALUES ("912","229","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("913","229","the_boyz_0_the_boyz_item_img","211");
INSERT INTO `wp_postmeta` VALUES ("914","229","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("915","229","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming,
Guillermo has a strong experience and know how
of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("916","229","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("917","229","the_boyz_1_the_boyz_item_img","212");
INSERT INTO `wp_postmeta` VALUES ("918","229","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("919","229","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience
in Branding, Identity, Graphic Design,
Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("920","229","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("921","229","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("922","229","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("923","230","imagen_header","198");
INSERT INTO `wp_postmeta` VALUES ("924","230","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("925","230","the_boyz_0_the_boyz_item_img","211");
INSERT INTO `wp_postmeta` VALUES ("926","230","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("927","230","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming,
Guillermo has a strong experience and know how
of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("928","230","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("929","230","the_boyz_1_the_boyz_item_img","212");
INSERT INTO `wp_postmeta` VALUES ("930","230","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("931","230","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience
in Branding, Identity, Graphic Design,
Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("932","230","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("933","230","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("934","230","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("935","231","imagen_header","198");
INSERT INTO `wp_postmeta` VALUES ("936","231","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("937","231","the_boyz_0_the_boyz_item_img","211");
INSERT INTO `wp_postmeta` VALUES ("938","231","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("939","231","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming,
Guillermo has a strong experience and know how
of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("940","231","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("941","231","the_boyz_1_the_boyz_item_img","212");
INSERT INTO `wp_postmeta` VALUES ("942","231","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("943","231","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience
in Branding, Identity, Graphic Design,
Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("944","231","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("945","231","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("946","231","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("947","232","imagen_header","198");
INSERT INTO `wp_postmeta` VALUES ("948","232","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("949","232","the_boyz_0_the_boyz_item_img","211");
INSERT INTO `wp_postmeta` VALUES ("950","232","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("951","232","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming, Guillermo has a strong experience and know how of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("952","232","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("953","232","the_boyz_1_the_boyz_item_img","212");
INSERT INTO `wp_postmeta` VALUES ("954","232","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("955","232","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience in Branding, Identity, Graphic Design, Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("956","232","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("957","232","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("958","232","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("959","233","imagen_header","198");
INSERT INTO `wp_postmeta` VALUES ("960","233","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("961","233","the_boyz_0_the_boyz_item_img","211");
INSERT INTO `wp_postmeta` VALUES ("962","233","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("963","233","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming, Guillermo has a strong experience and knowhow of 10 years in Project Management and Digital Services.
—
Posicionado como Director de Interactive, con un Master en Programación, Guillermo tiene una sólida experiencia y knowhow de 10 años en Gestión de Proyectos y Servicios Digitales.");
INSERT INTO `wp_postmeta` VALUES ("964","233","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("965","233","the_boyz_1_the_boyz_item_img","212");
INSERT INTO `wp_postmeta` VALUES ("966","233","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("967","233","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience in Branding, Identity, Graphic Design, Product Design, Management and Real Estate Developments.
—
Director Creativo de la Agencia Dandy con 12 años de experiencia en Branding, Identidad, Diseño Gráfico, Diseño de Producto, Gestión y Desarrollos Inmobiliarios.");
INSERT INTO `wp_postmeta` VALUES ("968","233","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("969","233","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("970","233","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("971","234","_wp_attached_file","2015/03/AA_000.jpg");
INSERT INTO `wp_postmeta` VALUES ("972","234","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/AA_000.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AA_000-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AA_000-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"AA_000-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("973","235","_wp_attached_file","2015/03/AA_003.jpg");
INSERT INTO `wp_postmeta` VALUES ("974","235","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/AA_003.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AA_003-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AA_003-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"AA_003-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("975","236","_wp_attached_file","2015/03/AA_0001.jpg");
INSERT INTO `wp_postmeta` VALUES ("976","236","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:19:\"2015/03/AA_0001.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"AA_0001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"AA_0001-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"AA_0001-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("977","94","_thumbnail_id","236");
INSERT INTO `wp_postmeta` VALUES ("980","238","_wp_attached_file","2015/03/AA_004.jpg");
INSERT INTO `wp_postmeta` VALUES ("981","238","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/AA_004.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AA_004-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AA_004-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"AA_004-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("982","239","_wp_attached_file","2015/03/AA_005.jpg");
INSERT INTO `wp_postmeta` VALUES ("983","239","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/AA_005.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AA_005-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AA_005-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"AA_005-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("984","240","_wp_attached_file","2015/01/AK_010.jpg");
INSERT INTO `wp_postmeta` VALUES ("985","240","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/AK_010.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AK_010-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AK_010-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"AK_010-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("987","241","imagen_header","198");
INSERT INTO `wp_postmeta` VALUES ("988","241","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("989","241","the_boyz_0_the_boyz_item_img","211");
INSERT INTO `wp_postmeta` VALUES ("990","241","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("991","241","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming, Guillermo has a strong experience and knowhow of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("992","241","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("993","241","the_boyz_0_the_boyz_item_txt_esp","GUILLERMO LÓPEZ CHIESINO
Socio | Director Interactivo

Posicionado como Director de Interactive, con un Master en Programación, Guillermo tiene una sólida experiencia y knowhow de 10 años en Gestión de Proyectos y Servicios Digitales.");
INSERT INTO `wp_postmeta` VALUES ("994","241","_the_boyz_0_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("995","241","the_boyz_1_the_boyz_item_img","212");
INSERT INTO `wp_postmeta` VALUES ("996","241","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("997","241","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience in Branding, Identity, Graphic Design, Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("998","241","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("999","241","the_boyz_1_the_boyz_item_txt_esp","DIEGO SANDOVAL
Socio | Director Creativo

Director Creativo de la Agencia Dandy con 12 años de experiencia en Branding, Identidad, Diseño Gráfico, Diseño de Producto, Gestión y Desarrollos Inmobiliarios.");
INSERT INTO `wp_postmeta` VALUES ("1000","241","_the_boyz_1_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1001","241","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("1002","241","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("1003","16","the_boyz_0_the_boyz_item_txt_esp","GUILLERMO LÓPEZ CHIESINO
Socio | Director Interactivo

Posicionado como Director de Interactive, con un Master en Programación, Guillermo tiene una sólida experiencia y knowhow de 10 años en Gestión de Proyectos y Servicios Digitales.");
INSERT INTO `wp_postmeta` VALUES ("1004","16","_the_boyz_0_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1005","16","the_boyz_1_the_boyz_item_txt_esp","");
INSERT INTO `wp_postmeta` VALUES ("1006","16","_the_boyz_1_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1008","94","_wp_old_slug","andrea-anzorena");
INSERT INTO `wp_postmeta` VALUES ("1009","25","_wp_old_slug","texture-holding");
INSERT INTO `wp_postmeta` VALUES ("1010","242","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES ("1011","242","_edit_lock","1541599099:2");
INSERT INTO `wp_postmeta` VALUES ("1012","243","_wp_attached_file","2015/03/MT_006.jpg");
INSERT INTO `wp_postmeta` VALUES ("1013","243","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/MT_006.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"MT_006-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"MT_006-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"MT_006-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1014","244","_wp_attached_file","2015/03/MT_000.jpg");
INSERT INTO `wp_postmeta` VALUES ("1015","244","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/MT_000.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"MT_000-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"MT_000-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"MT_000-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1016","245","_wp_attached_file","2015/03/MT_005.jpg");
INSERT INTO `wp_postmeta` VALUES ("1017","245","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/MT_005.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"MT_005-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"MT_005-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"MT_005-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1018","246","_wp_attached_file","2015/03/MT_004.jpg");
INSERT INTO `wp_postmeta` VALUES ("1019","246","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/MT_004.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"MT_004-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"MT_004-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"MT_004-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1020","247","_wp_attached_file","2015/03/MT_003.jpg");
INSERT INTO `wp_postmeta` VALUES ("1021","247","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/MT_003.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"MT_003-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"MT_003-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"MT_003-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1022","248","_wp_attached_file","2015/03/MT_002.jpg");
INSERT INTO `wp_postmeta` VALUES ("1023","248","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/MT_002.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"MT_002-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"MT_002-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"MT_002-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1024","249","_wp_attached_file","2015/03/MT_001.jpg");
INSERT INTO `wp_postmeta` VALUES ("1025","249","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/MT_001.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"MT_001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"MT_001-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"MT_001-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1026","242","_thumbnail_id","249");
INSERT INTO `wp_postmeta` VALUES ("1027","242","descatar_home","");
INSERT INTO `wp_postmeta` VALUES ("1028","242","_descatar_home","field_54aec60b5808b");
INSERT INTO `wp_postmeta` VALUES ("1029","242","subtitle_esp","Desarrollo de Arquitectura");
INSERT INTO `wp_postmeta` VALUES ("1030","242","_subtitle_esp","field_54ac29a4ce78c");
INSERT INTO `wp_postmeta` VALUES ("1031","242","subtitle_eng","Architecture Development");
INSERT INTO `wp_postmeta` VALUES ("1032","242","_subtitle_eng","field_54ac29b6ce78d");
INSERT INTO `wp_postmeta` VALUES ("1033","242","imagen_header","244");
INSERT INTO `wp_postmeta` VALUES ("1034","242","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1035","242","middle_image","243");
INSERT INTO `wp_postmeta` VALUES ("1036","242","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("1046","251","_wp_attached_file","2015/03/MT_008.jpg");
INSERT INTO `wp_postmeta` VALUES ("1047","251","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/MT_008.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"MT_008-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"MT_008-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"MT_008-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1048","252","_wp_attached_file","2015/03/MT_007.jpg");
INSERT INTO `wp_postmeta` VALUES ("1049","252","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/MT_007.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"MT_007-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"MT_007-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"MT_007-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1050","254","_wp_attached_file","2014/12/AU_006.jpg");
INSERT INTO `wp_postmeta` VALUES ("1051","254","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2014/12/AU_006.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AU_006-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AU_006-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"AU_006-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1052","255","imagen_header","254");
INSERT INTO `wp_postmeta` VALUES ("1053","255","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1054","255","the_boyz_0_the_boyz_item_img","211");
INSERT INTO `wp_postmeta` VALUES ("1055","255","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("1056","255","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming, Guillermo has a strong experience and knowhow of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("1057","255","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("1058","255","the_boyz_0_the_boyz_item_txt_esp","GUILLERMO LÓPEZ CHIESINO
Socio | Director Interactivo

Posicionado como Director de Interactive, con un Master en Programación, Guillermo tiene una sólida experiencia y knowhow de 10 años en Gestión de Proyectos y Servicios Digitales.");
INSERT INTO `wp_postmeta` VALUES ("1059","255","_the_boyz_0_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1060","255","the_boyz_1_the_boyz_item_img","212");
INSERT INTO `wp_postmeta` VALUES ("1061","255","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("1062","255","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience in Branding, Identity, Graphic Design, Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("1063","255","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("1064","255","the_boyz_1_the_boyz_item_txt_esp","DIEGO SANDOVAL
Socio | Director Creativo

Director Creativo de la Agencia Dandy con 12 años de experiencia en Branding, Identidad, Diseño Gráfico, Diseño de Producto, Gestión y Desarrollos Inmobiliarios.");
INSERT INTO `wp_postmeta` VALUES ("1065","255","_the_boyz_1_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1066","255","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("1067","255","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("1070","257","middle_image","256");
INSERT INTO `wp_postmeta` VALUES ("1071","257","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("1072","258","middle_image","220");
INSERT INTO `wp_postmeta` VALUES ("1073","258","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("1078","261","middle_image","260");
INSERT INTO `wp_postmeta` VALUES ("1079","261","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("1080","261","imagen_header","215");
INSERT INTO `wp_postmeta` VALUES ("1081","261","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1082","263","_wp_attached_file","2015/01/AU_008.jpg");
INSERT INTO `wp_postmeta` VALUES ("1083","263","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/01/AU_008.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"AU_008-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"AU_008-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"AU_008-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1084","264","middle_image","263");
INSERT INTO `wp_postmeta` VALUES ("1085","264","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("1086","264","imagen_header","215");
INSERT INTO `wp_postmeta` VALUES ("1087","264","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1088","266","_wp_attached_file","2015/03/ZH_002.jpg");
INSERT INTO `wp_postmeta` VALUES ("1089","265","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES ("1090","265","_edit_lock","1541599123:2");
INSERT INTO `wp_postmeta` VALUES ("1091","266","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/ZH_002.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"ZH_002-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"ZH_002-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"ZH_002-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1092","267","_wp_attached_file","2015/03/ZH_003.jpg");
INSERT INTO `wp_postmeta` VALUES ("1093","267","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/ZH_003.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"ZH_003-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"ZH_003-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"ZH_003-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1094","268","_wp_attached_file","2015/03/ZH_004.jpg");
INSERT INTO `wp_postmeta` VALUES ("1095","268","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/ZH_004.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"ZH_004-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"ZH_004-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"ZH_004-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1096","269","_wp_attached_file","2015/03/ZH_001.jpg");
INSERT INTO `wp_postmeta` VALUES ("1097","269","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/ZH_001.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"ZH_001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"ZH_001-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"ZH_001-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1098","265","descatar_home","a:1:{i:0;s:2:\"si\";}");
INSERT INTO `wp_postmeta` VALUES ("1099","265","_descatar_home","field_54aec60b5808b");
INSERT INTO `wp_postmeta` VALUES ("1100","265","subtitle_esp","Desarrollo de Bienes Raíces");
INSERT INTO `wp_postmeta` VALUES ("1101","265","_subtitle_esp","field_54ac29a4ce78c");
INSERT INTO `wp_postmeta` VALUES ("1102","265","subtitle_eng","Real Estate Development");
INSERT INTO `wp_postmeta` VALUES ("1103","265","_subtitle_eng","field_54ac29b6ce78d");
INSERT INTO `wp_postmeta` VALUES ("1104","265","imagen_header","270");
INSERT INTO `wp_postmeta` VALUES ("1105","265","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1106","265","middle_image","271");
INSERT INTO `wp_postmeta` VALUES ("1107","265","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("1108","270","_wp_attached_file","2015/03/ZH_000.jpg");
INSERT INTO `wp_postmeta` VALUES ("1109","270","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/ZH_000.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"ZH_000-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"ZH_000-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"ZH_000-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1110","271","_wp_attached_file","2015/03/ZH_005.jpg");
INSERT INTO `wp_postmeta` VALUES ("1111","271","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/03/ZH_005.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"ZH_005-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"ZH_005-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"ZH_005-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1112","265","_thumbnail_id","268");
INSERT INTO `wp_postmeta` VALUES ("1122","275","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES ("1123","275","_edit_lock","1537987153:2");
INSERT INTO `wp_postmeta` VALUES ("1126","277","_wp_attached_file","2015/04/IB_000.jpg");
INSERT INTO `wp_postmeta` VALUES ("1127","277","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/04/IB_000.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"IB_000-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"IB_000-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"IB_000-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1128","278","_wp_attached_file","2015/04/IB_001.jpg");
INSERT INTO `wp_postmeta` VALUES ("1129","278","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/04/IB_001.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"IB_001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"IB_001-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"IB_001-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1130","279","_wp_attached_file","2015/04/IB_002.jpg");
INSERT INTO `wp_postmeta` VALUES ("1131","279","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/04/IB_002.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"IB_002-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"IB_002-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"IB_002-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1132","280","_wp_attached_file","2015/04/IB_003.jpg");
INSERT INTO `wp_postmeta` VALUES ("1133","280","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/04/IB_003.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"IB_003-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"IB_003-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"IB_003-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1134","281","_wp_attached_file","2015/04/IB_004.jpg");
INSERT INTO `wp_postmeta` VALUES ("1135","281","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/04/IB_004.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"IB_004-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"IB_004-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"IB_004-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:51:\"Copyright 2014 Vox Media, Inc. All rights reserved.\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1136","282","_wp_attached_file","2015/04/IB_006.jpg");
INSERT INTO `wp_postmeta` VALUES ("1137","282","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:800;s:4:\"file\";s:18:\"2015/04/IB_006.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"IB_006-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"IB_006-300x150.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"IB_006-1024x512.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1138","283","_wp_attached_file","2015/04/IB_0021.jpg");
INSERT INTO `wp_postmeta` VALUES ("1139","283","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:19:\"2015/04/IB_0021.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"IB_0021-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"IB_0021-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"IB_0021-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1140","275","_thumbnail_id","283");
INSERT INTO `wp_postmeta` VALUES ("1141","275","descatar_home","a:1:{i:0;s:2:\"si\";}");
INSERT INTO `wp_postmeta` VALUES ("1142","275","_descatar_home","field_54aec60b5808b");
INSERT INTO `wp_postmeta` VALUES ("1143","275","subtitle_esp","Desarrollo de E-learning e E-commerce");
INSERT INTO `wp_postmeta` VALUES ("1144","275","_subtitle_esp","field_54ac29a4ce78c");
INSERT INTO `wp_postmeta` VALUES ("1145","275","subtitle_eng","E-learning & E-commerce Development");
INSERT INTO `wp_postmeta` VALUES ("1146","275","_subtitle_eng","field_54ac29b6ce78d");
INSERT INTO `wp_postmeta` VALUES ("1147","275","imagen_header","287");
INSERT INTO `wp_postmeta` VALUES ("1148","275","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1149","275","middle_image","277");
INSERT INTO `wp_postmeta` VALUES ("1150","275","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("1151","284","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES ("1152","284","_menu_item_menu_item_parent","349");
INSERT INTO `wp_postmeta` VALUES ("1153","284","_menu_item_object_id","275");
INSERT INTO `wp_postmeta` VALUES ("1154","284","_menu_item_object","works");
INSERT INTO `wp_postmeta` VALUES ("1155","284","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES ("1156","284","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES ("1157","284","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES ("1158","284","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES ("1164","287","_wp_attached_file","2015/04/IB_008.jpg");
INSERT INTO `wp_postmeta` VALUES ("1165","287","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/04/IB_008.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"IB_008-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"IB_008-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"IB_008-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1166","288","imagen_header","254");
INSERT INTO `wp_postmeta` VALUES ("1167","288","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1168","288","the_boyz_0_the_boyz_item_img","211");
INSERT INTO `wp_postmeta` VALUES ("1169","288","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("1170","288","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming, Guillermo has a strong experience and knowhow of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("1171","288","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("1172","288","the_boyz_0_the_boyz_item_txt_esp","GUILLERMO LÓPEZ CHIESINO
Socio | Director Interactivo

Posicionado como Director de Interactive, con un Master en Programación, Guillermo tiene una sólida experiencia y knowhow de 10 años en Gestión de Proyectos y Servicios Digitales.");
INSERT INTO `wp_postmeta` VALUES ("1173","288","_the_boyz_0_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1174","288","the_boyz_1_the_boyz_item_img","212");
INSERT INTO `wp_postmeta` VALUES ("1175","288","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("1176","288","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience in Branding, Identity, Graphic Design, Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("1177","288","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("1178","288","the_boyz_1_the_boyz_item_txt_esp","DIEGO SANDOVAL
Socio | Director Creativo

Director Creativo de la Agencia Dandy con 12 años de experiencia en Branding, Identidad, Diseño Gráfico, Diseño de Producto, Gestión y Desarrollos Inmobiliarios.");
INSERT INTO `wp_postmeta` VALUES ("1179","288","_the_boyz_1_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1180","288","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("1181","288","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("1182","289","imagen_header","254");
INSERT INTO `wp_postmeta` VALUES ("1183","289","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1184","289","the_boyz_0_the_boyz_item_img","211");
INSERT INTO `wp_postmeta` VALUES ("1185","289","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("1186","289","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming, Guillermo has a strong experience and knowhow of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("1187","289","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("1188","289","the_boyz_0_the_boyz_item_txt_esp","GUILLERMO LÓPEZ CHIESINO
Socio | Director Interactivo

Posicionado como Director de Interactive, con un Master en Programación, Guillermo tiene una sólida experiencia y knowhow de 10 años en Gestión de Proyectos y Servicios Digitales.");
INSERT INTO `wp_postmeta` VALUES ("1189","289","_the_boyz_0_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1190","289","the_boyz_1_the_boyz_item_img","212");
INSERT INTO `wp_postmeta` VALUES ("1191","289","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("1192","289","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience in Branding, Identity, Graphic Design, Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("1193","289","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("1194","289","the_boyz_1_the_boyz_item_txt_esp","DIEGO SANDOVAL
Socio | Director Creativo

Director Creativo de la Agencia Dandy con 12 años de experiencia en Branding, Identidad, Diseño Gráfico, Diseño de Producto, Gestión y Desarrollos Inmobiliarios.");
INSERT INTO `wp_postmeta` VALUES ("1195","289","_the_boyz_1_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1196","289","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("1197","289","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("1198","290","imagen_header","254");
INSERT INTO `wp_postmeta` VALUES ("1199","290","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1200","290","the_boyz_0_the_boyz_item_img","211");
INSERT INTO `wp_postmeta` VALUES ("1201","290","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("1202","290","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming, Guillermo has a strong experience and knowhow of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("1203","290","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("1204","290","the_boyz_0_the_boyz_item_txt_esp","GUILLERMO LÓPEZ CHIESINO
Socio | Director Interactivo

Posicionado como Director de Interactive, con un Master en Programación, Guillermo tiene una sólida experiencia y knowhow de 10 años en Gestión de Proyectos y Servicios Digitales.");
INSERT INTO `wp_postmeta` VALUES ("1205","290","_the_boyz_0_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1206","290","the_boyz_1_the_boyz_item_img","212");
INSERT INTO `wp_postmeta` VALUES ("1207","290","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("1208","290","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience in Branding, Identity, Graphic Design, Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("1209","290","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("1210","290","the_boyz_1_the_boyz_item_txt_esp","DIEGO SANDOVAL
Socio | Director Creativo

Director Creativo de la Agencia Dandy con 12 años de experiencia en Branding, Identidad, Diseño Gráfico, Diseño de Producto, Gestión y Desarrollos Inmobiliarios.");
INSERT INTO `wp_postmeta` VALUES ("1211","290","_the_boyz_1_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1212","290","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("1213","290","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("1214","291","imagen_header","254");
INSERT INTO `wp_postmeta` VALUES ("1215","291","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1216","291","the_boyz_0_the_boyz_item_img","211");
INSERT INTO `wp_postmeta` VALUES ("1217","291","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("1218","291","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming, Guillermo has a strong experience and knowhow of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("1219","291","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("1220","291","the_boyz_0_the_boyz_item_txt_esp","GUILLERMO LÓPEZ CHIESINO
Socio | Director Interactivo

Posicionado como Director de Interactive, con un Master en Programación, Guillermo tiene una sólida experiencia y knowhow de 10 años en Gestión de Proyectos y Servicios Digitales.");
INSERT INTO `wp_postmeta` VALUES ("1221","291","_the_boyz_0_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1222","291","the_boyz_1_the_boyz_item_img","212");
INSERT INTO `wp_postmeta` VALUES ("1223","291","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("1224","291","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience in Branding, Identity, Graphic Design, Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("1225","291","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("1226","291","the_boyz_1_the_boyz_item_txt_esp","DIEGO SANDOVAL
Socio | Director Creativo

Director Creativo de la Agencia Dandy con 12 años de experiencia en Branding, Identidad, Diseño Gráfico, Diseño de Producto, Gestión y Desarrollos Inmobiliarios.");
INSERT INTO `wp_postmeta` VALUES ("1227","291","_the_boyz_1_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1228","291","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("1229","291","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("1230","292","imagen_header","254");
INSERT INTO `wp_postmeta` VALUES ("1231","292","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1232","292","the_boyz_0_the_boyz_item_img","211");
INSERT INTO `wp_postmeta` VALUES ("1233","292","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("1234","292","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming, Guillermo has a strong experience and knowhow of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("1235","292","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("1236","292","the_boyz_0_the_boyz_item_txt_esp","GUILLERMO LÓPEZ CHIESINO
Socio | Director Interactivo

Posicionado como Director de Interactive, con un Master en Programación, Guillermo tiene una sólida experiencia y knowhow de 10 años en Gestión de Proyectos y Servicios Digitales.");
INSERT INTO `wp_postmeta` VALUES ("1237","292","_the_boyz_0_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1238","292","the_boyz_1_the_boyz_item_img","212");
INSERT INTO `wp_postmeta` VALUES ("1239","292","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("1240","292","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience in Branding, Identity, Graphic Design, Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("1241","292","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("1242","292","the_boyz_1_the_boyz_item_txt_esp","DIEGO SANDOVAL
Socio | Director Creativo

Director Creativo de la Agencia Dandy con 12 años de experiencia en Branding, Identidad, Diseño Gráfico, Diseño de Producto, Gestión y Desarrollos Inmobiliarios.");
INSERT INTO `wp_postmeta` VALUES ("1243","292","_the_boyz_1_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1244","292","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("1245","292","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("1246","293","imagen_header","254");
INSERT INTO `wp_postmeta` VALUES ("1247","293","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1248","293","the_boyz_0_the_boyz_item_img","211");
INSERT INTO `wp_postmeta` VALUES ("1249","293","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("1250","293","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming, Guillermo has a strong experience and knowhow of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("1251","293","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("1252","293","the_boyz_0_the_boyz_item_txt_esp","GUILLERMO LÓPEZ CHIESINO
Socio | Director Interactivo

Posicionado como Director de Interactive, con un Master en Programación, Guillermo tiene una sólida experiencia y knowhow de 10 años en Gestión de Proyectos y Servicios Digitales.");
INSERT INTO `wp_postmeta` VALUES ("1253","293","_the_boyz_0_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1254","293","the_boyz_1_the_boyz_item_img","212");
INSERT INTO `wp_postmeta` VALUES ("1255","293","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("1256","293","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience in Branding, Identity, Graphic Design, Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("1257","293","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("1258","293","the_boyz_1_the_boyz_item_txt_esp","DIEGO SANDOVAL
Socio | Director Creativo

Director Creativo de la Agencia Dandy con 12 años de experiencia en Branding, Identidad, Diseño Gráfico, Diseño de Producto, Gestión y Desarrollos Inmobiliarios.");
INSERT INTO `wp_postmeta` VALUES ("1259","293","_the_boyz_1_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1260","293","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("1261","293","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("1262","294","imagen_header","254");
INSERT INTO `wp_postmeta` VALUES ("1263","294","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1264","294","the_boyz_0_the_boyz_item_img","211");
INSERT INTO `wp_postmeta` VALUES ("1265","294","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("1266","294","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming, Guillermo has a strong experience and knowhow of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("1267","294","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("1268","294","the_boyz_0_the_boyz_item_txt_esp","GUILLERMO LÓPEZ CHIESINO
Socio | Director Interactivo

Posicionado como Director de Interactive, con un Master en Programación, Guillermo tiene una sólida experiencia y knowhow de 10 años en Gestión de Proyectos y Servicios Digitales.");
INSERT INTO `wp_postmeta` VALUES ("1269","294","_the_boyz_0_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1270","294","the_boyz_1_the_boyz_item_img","212");
INSERT INTO `wp_postmeta` VALUES ("1271","294","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("1272","294","the_boyz_1_the_boyz_item_txt","DIEGO SANDOVAL
Partner | Creative Director 

Creative Director at Dandy Agency with 12 years of experience in Branding, Identity, Graphic Design, Product Design, Management and Real Estate Developments.");
INSERT INTO `wp_postmeta` VALUES ("1273","294","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("1274","294","the_boyz_1_the_boyz_item_txt_esp","DIEGO SANDOVAL
Socio | Director Creativo

Director Creativo de la Agencia Dandy con 12 años de experiencia en Branding, Identidad, Diseño Gráfico, Diseño de Producto, Gestión y Desarrollos Inmobiliarios.");
INSERT INTO `wp_postmeta` VALUES ("1275","294","_the_boyz_1_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1276","294","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("1277","294","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("1278","296","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES ("1279","296","_edit_lock","1541599092:2");
INSERT INTO `wp_postmeta` VALUES ("1280","297","_wp_attached_file","2015/07/mba_12.jpg");
INSERT INTO `wp_postmeta` VALUES ("1281","297","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/07/mba_12.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mba_12-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mba_12-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"mba_12-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1282","298","_wp_attached_file","2015/07/mba_10.jpg");
INSERT INTO `wp_postmeta` VALUES ("1283","298","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/07/mba_10.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mba_10-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mba_10-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"mba_10-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1284","299","_wp_attached_file","2015/07/mba_00.jpg");
INSERT INTO `wp_postmeta` VALUES ("1285","299","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/07/mba_00.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mba_00-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mba_00-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"mba_00-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1287","300","_wp_attached_file","2015/07/mba_001.jpg");
INSERT INTO `wp_postmeta` VALUES ("1288","300","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:19:\"2015/07/mba_001.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"mba_001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"mba_001-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"mba_001-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1289","301","_wp_attached_file","2015/07/mba_01.jpg");
INSERT INTO `wp_postmeta` VALUES ("1290","301","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/07/mba_01.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mba_01-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mba_01-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"mba_01-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1291","302","_wp_attached_file","2015/07/mba_02.jpg");
INSERT INTO `wp_postmeta` VALUES ("1292","302","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/07/mba_02.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mba_02-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mba_02-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"mba_02-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1293","303","_wp_attached_file","2015/07/mba_03.jpg");
INSERT INTO `wp_postmeta` VALUES ("1294","303","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/07/mba_03.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mba_03-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mba_03-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"mba_03-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1295","304","_wp_attached_file","2015/07/mba_04.jpg");
INSERT INTO `wp_postmeta` VALUES ("1296","304","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/07/mba_04.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mba_04-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mba_04-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"mba_04-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1297","305","_wp_attached_file","2015/07/mba_05.jpg");
INSERT INTO `wp_postmeta` VALUES ("1298","305","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/07/mba_05.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mba_05-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mba_05-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"mba_05-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1299","306","_wp_attached_file","2015/07/mba_06.jpg");
INSERT INTO `wp_postmeta` VALUES ("1300","306","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/07/mba_06.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mba_06-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mba_06-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"mba_06-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1301","307","_wp_attached_file","2015/07/mba_07.jpg");
INSERT INTO `wp_postmeta` VALUES ("1302","307","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/07/mba_07.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mba_07-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mba_07-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"mba_07-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1303","308","_wp_attached_file","2015/07/mba_08.jpg");
INSERT INTO `wp_postmeta` VALUES ("1304","308","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/07/mba_08.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mba_08-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mba_08-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"mba_08-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1305","309","_wp_attached_file","2015/07/mba_09.jpg");
INSERT INTO `wp_postmeta` VALUES ("1306","309","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/07/mba_09.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mba_09-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mba_09-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"mba_09-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1307","310","_wp_attached_file","2015/07/mba_101.jpg");
INSERT INTO `wp_postmeta` VALUES ("1308","310","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:19:\"2015/07/mba_101.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"mba_101-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"mba_101-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"mba_101-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1309","311","_wp_attached_file","2015/07/mba_11.jpg");
INSERT INTO `wp_postmeta` VALUES ("1310","311","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/07/mba_11.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mba_11-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mba_11-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"mba_11-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1311","312","_wp_attached_file","2015/07/mba_121.jpg");
INSERT INTO `wp_postmeta` VALUES ("1312","312","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:19:\"2015/07/mba_121.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"mba_121-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"mba_121-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"mba_121-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1313","313","_wp_attached_file","2015/07/mba_13.jpg");
INSERT INTO `wp_postmeta` VALUES ("1314","313","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/07/mba_13.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mba_13-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mba_13-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"mba_13-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1315","314","_wp_attached_file","2015/07/mba_14.jpg");
INSERT INTO `wp_postmeta` VALUES ("1316","314","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/07/mba_14.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mba_14-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mba_14-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"mba_14-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1317","296","descatar_home","a:1:{i:0;s:2:\"si\";}");
INSERT INTO `wp_postmeta` VALUES ("1318","296","_descatar_home","field_54aec60b5808b");
INSERT INTO `wp_postmeta` VALUES ("1319","296","subtitle_esp","Branding & Moda");
INSERT INTO `wp_postmeta` VALUES ("1320","296","_subtitle_esp","field_54ac29a4ce78c");
INSERT INTO `wp_postmeta` VALUES ("1321","296","subtitle_eng","Branding & Fashion");
INSERT INTO `wp_postmeta` VALUES ("1322","296","_subtitle_eng","field_54ac29b6ce78d");
INSERT INTO `wp_postmeta` VALUES ("1323","296","imagen_header","297");
INSERT INTO `wp_postmeta` VALUES ("1324","296","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1325","296","middle_image","298");
INSERT INTO `wp_postmeta` VALUES ("1326","296","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("1327","311","_edit_lock","1436383001:1");
INSERT INTO `wp_postmeta` VALUES ("1350","322","_wp_attached_file","2015/07/mba_16.jpg");
INSERT INTO `wp_postmeta` VALUES ("1351","322","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/07/mba_16.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mba_16-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mba_16-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"mba_16-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1352","323","_wp_attached_file","2015/07/mba_17.jpg");
INSERT INTO `wp_postmeta` VALUES ("1353","323","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/07/mba_17.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mba_17-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mba_17-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"mba_17-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1354","322","_edit_lock","1436386531:1");
INSERT INTO `wp_postmeta` VALUES ("1355","296","_thumbnail_id","323");
INSERT INTO `wp_postmeta` VALUES ("1356","324","_wp_attached_file","2015/07/mba_15.jpg");
INSERT INTO `wp_postmeta` VALUES ("1357","324","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/07/mba_15.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mba_15-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mba_15-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"mba_15-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1358","324","_edit_lock","1436388024:1");
INSERT INTO `wp_postmeta` VALUES ("1359","327","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES ("1360","327","_edit_lock","1541599116:2");
INSERT INTO `wp_postmeta` VALUES ("1361","328","_wp_attached_file","2015/08/RM_003.jpg");
INSERT INTO `wp_postmeta` VALUES ("1362","328","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/08/RM_003.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"RM_003-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"RM_003-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"RM_003-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1363","329","_wp_attached_file","2015/08/RM_000.jpg");
INSERT INTO `wp_postmeta` VALUES ("1364","329","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/08/RM_000.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"RM_000-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"RM_000-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"RM_000-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1365","330","_wp_attached_file","2015/08/RM_001.jpg");
INSERT INTO `wp_postmeta` VALUES ("1366","330","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/08/RM_001.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"RM_001-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"RM_001-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"RM_001-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1367","331","_wp_attached_file","2015/08/RM_004.jpg");
INSERT INTO `wp_postmeta` VALUES ("1368","330","_edit_lock","1438399919:1");
INSERT INTO `wp_postmeta` VALUES ("1369","331","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/08/RM_004.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"RM_004-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"RM_004-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"RM_004-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1370","332","_wp_attached_file","2015/08/RM_002.jpg");
INSERT INTO `wp_postmeta` VALUES ("1371","332","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2015/08/RM_002.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"RM_002-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"RM_002-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"RM_002-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1372","333","_wp_attached_file","2015/08/RM_0041.jpg");
INSERT INTO `wp_postmeta` VALUES ("1373","333","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:19:\"2015/08/RM_0041.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"RM_0041-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"RM_0041-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"RM_0041-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";i:0;s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";i:0;s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";i:0;s:3:\"iso\";i:0;s:13:\"shutter_speed\";i:0;s:5:\"title\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES ("1374","327","_thumbnail_id","333");
INSERT INTO `wp_postmeta` VALUES ("1375","327","descatar_home","a:1:{i:0;s:2:\"si\";}");
INSERT INTO `wp_postmeta` VALUES ("1376","327","_descatar_home","field_54aec60b5808b");
INSERT INTO `wp_postmeta` VALUES ("1377","327","subtitle_esp","Sitio Web Corporativo");
INSERT INTO `wp_postmeta` VALUES ("1378","327","_subtitle_esp","field_54ac29a4ce78c");
INSERT INTO `wp_postmeta` VALUES ("1379","327","subtitle_eng","Corporate Website Development");
INSERT INTO `wp_postmeta` VALUES ("1380","327","_subtitle_eng","field_54ac29b6ce78d");
INSERT INTO `wp_postmeta` VALUES ("1381","327","imagen_header","329");
INSERT INTO `wp_postmeta` VALUES ("1382","327","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1383","327","middle_image","328");
INSERT INTO `wp_postmeta` VALUES ("1384","327","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("1395","336","imagen_header","254");
INSERT INTO `wp_postmeta` VALUES ("1396","336","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1397","337","imagen_header","254");
INSERT INTO `wp_postmeta` VALUES ("1398","337","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1399","338","imagen_header","254");
INSERT INTO `wp_postmeta` VALUES ("1400","338","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1401","338","the_boyz_0_the_boyz_item_img","211");
INSERT INTO `wp_postmeta` VALUES ("1402","338","_the_boyz_0_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("1403","338","the_boyz_0_the_boyz_item_txt","GUILLERMO LÓPEZ CHIESINO
Partner | Director Interactive

Positioned as Director of Interactive, with a Master Degree in Programming, Guillermo has a strong experience and knowhow of 10 years in Project Management and Digital Services.");
INSERT INTO `wp_postmeta` VALUES ("1404","338","_the_boyz_0_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("1405","338","the_boyz_0_the_boyz_item_txt_esp","GUILLERMO LÓPEZ CHIESINO
Socio | Director Interactivo

Posicionado como Director de Interactive, con un Master en Programación, Guillermo tiene una sólida experiencia y knowhow de 10 años en Gestión de Proyectos y Servicios Digitales.");
INSERT INTO `wp_postmeta` VALUES ("1406","338","_the_boyz_0_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1407","338","the_boyz_1_the_boyz_item_img","");
INSERT INTO `wp_postmeta` VALUES ("1408","338","_the_boyz_1_the_boyz_item_img","field_54bd251a4cc1e");
INSERT INTO `wp_postmeta` VALUES ("1409","338","the_boyz_1_the_boyz_item_txt","");
INSERT INTO `wp_postmeta` VALUES ("1410","338","_the_boyz_1_the_boyz_item_txt","field_54bd2c934cc1f");
INSERT INTO `wp_postmeta` VALUES ("1411","338","the_boyz_1_the_boyz_item_txt_esp","");
INSERT INTO `wp_postmeta` VALUES ("1412","338","_the_boyz_1_the_boyz_item_txt_esp","field_54fdbbca8b231");
INSERT INTO `wp_postmeta` VALUES ("1413","338","the_boyz","a:2:{i:0;s:13:\"the_boyz_item\";i:1;s:13:\"the_boyz_item\";}");
INSERT INTO `wp_postmeta` VALUES ("1414","338","_the_boyz","field_54bd22104cc1d");
INSERT INTO `wp_postmeta` VALUES ("1415","40","_rawhtml_settings","0,0,0,0");
INSERT INTO `wp_postmeta` VALUES ("1416","349","_menu_item_type","custom");
INSERT INTO `wp_postmeta` VALUES ("1417","349","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES ("1418","349","_menu_item_object_id","349");
INSERT INTO `wp_postmeta` VALUES ("1419","349","_menu_item_object","custom");
INSERT INTO `wp_postmeta` VALUES ("1420","349","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES ("1421","349","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES ("1422","349","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES ("1423","349","_menu_item_url","#");
INSERT INTO `wp_postmeta` VALUES ("1429","333","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:11.751598091293779;s:5:\"bytes\";i:10442;s:11:\"size_before\";i:88856;s:10:\"size_after\";i:78414;s:4:\"time\";d:0.050000000000000003;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.3800000000000008;s:5:\"bytes\";i:667;s:11:\"size_before\";i:7964;s:10:\"size_after\";i:7297;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.8699999999999992;s:5:\"bytes\";i:1148;s:11:\"size_before\";i:11637;s:10:\"size_after\";i:10489;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:12.460000000000001;s:5:\"bytes\";i:8627;s:11:\"size_before\";i:69255;s:10:\"size_after\";i:60628;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1430","332","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:13.428841309823678;s:5:\"bytes\";i:8530;s:11:\"size_before\";i:63520;s:10:\"size_after\";i:54990;s:4:\"time\";d:0.070000000000000007;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.75;s:5:\"bytes\";i:670;s:11:\"size_before\";i:6874;s:10:\"size_after\";i:6204;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.77;s:5:\"bytes\";i:941;s:11:\"size_before\";i:8736;s:10:\"size_after\";i:7795;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:14.44;s:5:\"bytes\";i:6919;s:11:\"size_before\";i:47910;s:10:\"size_after\";i:40991;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1431","331","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:11.751598091293779;s:5:\"bytes\";i:10442;s:11:\"size_before\";i:88856;s:10:\"size_after\";i:78414;s:4:\"time\";d:0.040000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.3800000000000008;s:5:\"bytes\";i:667;s:11:\"size_before\";i:7964;s:10:\"size_after\";i:7297;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.8699999999999992;s:5:\"bytes\";i:1148;s:11:\"size_before\";i:11637;s:10:\"size_after\";i:10489;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:12.460000000000001;s:5:\"bytes\";i:8627;s:11:\"size_before\";i:69255;s:10:\"size_after\";i:60628;s:4:\"time\";d:0.02;}}}");
INSERT INTO `wp_postmeta` VALUES ("1432","330","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:12.015476935196126;s:5:\"bytes\";i:10372;s:11:\"size_before\";i:86322;s:10:\"size_after\";i:75950;s:4:\"time\";d:0.050000000000000003;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.7599999999999998;s:5:\"bytes\";i:673;s:11:\"size_before\";i:7679;s:10:\"size_after\";i:7006;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.4499999999999993;s:5:\"bytes\";i:1028;s:11:\"size_before\";i:10881;s:10:\"size_after\";i:9853;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:12.800000000000001;s:5:\"bytes\";i:8671;s:11:\"size_before\";i:67762;s:10:\"size_after\";i:59091;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1433","329","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:3.3527829005048826;s:5:\"bytes\";i:3327;s:11:\"size_before\";i:99231;s:10:\"size_after\";i:95904;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.5800000000000001;s:5:\"bytes\";i:326;s:11:\"size_before\";i:7117;s:10:\"size_after\";i:6791;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.9500000000000002;s:5:\"bytes\";i:661;s:11:\"size_before\";i:13365;s:10:\"size_after\";i:12704;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.9700000000000002;s:5:\"bytes\";i:2340;s:11:\"size_before\";i:78749;s:10:\"size_after\";i:76409;s:4:\"time\";d:0.050000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1434","328","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:7.7455372392859587;s:5:\"bytes\";i:7936;s:11:\"size_before\";i:102459;s:10:\"size_after\";i:94523;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.9800000000000004;s:5:\"bytes\";i:410;s:11:\"size_before\";i:6858;s:10:\"size_after\";i:6448;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.1500000000000004;s:5:\"bytes\";i:521;s:11:\"size_before\";i:10123;s:10:\"size_after\";i:9602;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.1999999999999993;s:5:\"bytes\";i:7005;s:11:\"size_before\";i:85478;s:10:\"size_after\";i:78473;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1435","324","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:11.080155114641768;s:5:\"bytes\";i:20601;s:11:\"size_before\";i:185927;s:10:\"size_after\";i:165326;s:4:\"time\";d:0.070000000000000007;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.76;s:5:\"bytes\";i:1641;s:11:\"size_before\";i:13960;s:10:\"size_after\";i:12319;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:12.07;s:5:\"bytes\";i:3396;s:11:\"size_before\";i:28142;s:10:\"size_after\";i:24746;s:4:\"time\";d:0.029999999999999999;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.82;s:5:\"bytes\";i:15564;s:11:\"size_before\";i:143825;s:10:\"size_after\";i:128261;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1436","323","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:25.509056354962574;s:5:\"bytes\";i:6577;s:11:\"size_before\";i:25783;s:10:\"size_after\";i:19206;s:4:\"time\";d:0.050000000000000003;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.369999999999999;s:5:\"bytes\";i:269;s:11:\"size_before\";i:2365;s:10:\"size_after\";i:2096;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:14.109999999999999;s:5:\"bytes\";i:491;s:11:\"size_before\";i:3479;s:10:\"size_after\";i:2988;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:29.170000000000002;s:5:\"bytes\";i:5817;s:11:\"size_before\";i:19939;s:10:\"size_after\";i:14122;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1437","322","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:21.360566098423931;s:5:\"bytes\";i:6641;s:11:\"size_before\";i:31090;s:10:\"size_after\";i:24449;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.1;s:5:\"bytes\";i:339;s:11:\"size_before\";i:3355;s:10:\"size_after\";i:3016;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.880000000000001;s:5:\"bytes\";i:485;s:11:\"size_before\";i:4456;s:10:\"size_after\";i:3971;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:24.989999999999998;s:5:\"bytes\";i:5817;s:11:\"size_before\";i:23279;s:10:\"size_after\";i:17462;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1438","314","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.365052552552552;s:5:\"bytes\";i:22090;s:11:\"size_before\";i:213120;s:10:\"size_after\";i:191030;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.65;s:5:\"bytes\";i:1597;s:11:\"size_before\";i:13713;s:10:\"size_after\";i:12116;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:12.08;s:5:\"bytes\";i:3363;s:11:\"size_before\";i:27841;s:10:\"size_after\";i:24478;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.9800000000000004;s:5:\"bytes\";i:17130;s:11:\"size_before\";i:171566;s:10:\"size_after\";i:154436;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1439","313","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:6.6210520478052297;s:5:\"bytes\";i:9551;s:11:\"size_before\";i:144252;s:10:\"size_after\";i:134701;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.4299999999999997;s:5:\"bytes\";i:652;s:11:\"size_before\";i:10133;s:10:\"size_after\";i:9481;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.5199999999999996;s:5:\"bytes\";i:764;s:11:\"size_before\";i:13836;s:10:\"size_after\";i:13072;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.7599999999999998;s:5:\"bytes\";i:8135;s:11:\"size_before\";i:120283;s:10:\"size_after\";i:112148;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1440","312","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:7.643227687530767;s:5:\"bytes\";i:8074;s:11:\"size_before\";i:105636;s:10:\"size_after\";i:97562;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.4300000000000002;s:5:\"bytes\";i:190;s:11:\"size_before\";i:5537;s:10:\"size_after\";i:5347;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.25;s:5:\"bytes\";i:272;s:11:\"size_before\";i:8361;s:10:\"size_after\";i:8089;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.3000000000000007;s:5:\"bytes\";i:7612;s:11:\"size_before\";i:91738;s:10:\"size_after\";i:84126;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1441","311","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:8.5195530726256976;s:5:\"bytes\";i:5795;s:11:\"size_before\";i:68020;s:10:\"size_after\";i:62225;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.6699999999999999;s:5:\"bytes\";i:344;s:11:\"size_before\";i:6072;s:10:\"size_after\";i:5728;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:6;s:5:\"bytes\";i:448;s:11:\"size_before\";i:7462;s:10:\"size_after\";i:7014;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.1799999999999997;s:5:\"bytes\";i:5003;s:11:\"size_before\";i:54486;s:10:\"size_after\";i:49483;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1442","310","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:3.8202661831834481;s:5:\"bytes\";i:4762;s:11:\"size_before\";i:124651;s:10:\"size_after\";i:119889;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.6200000000000001;s:5:\"bytes\";i:584;s:11:\"size_before\";i:8819;s:10:\"size_after\";i:8235;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.54;s:5:\"bytes\";i:606;s:11:\"size_before\";i:13360;s:10:\"size_after\";i:12754;s:4:\"time\";d:0.029999999999999999;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.4900000000000002;s:5:\"bytes\";i:3572;s:11:\"size_before\";i:102472;s:10:\"size_after\";i:98900;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1443","309","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:23.127922395142715;s:5:\"bytes\";i:6628;s:11:\"size_before\";i:28658;s:10:\"size_after\";i:22030;s:4:\"time\";d:0.070000000000000007;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:12.220000000000001;s:5:\"bytes\";i:283;s:11:\"size_before\";i:2315;s:10:\"size_after\";i:2032;s:4:\"time\";d:0.040000000000000001;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:16.379999999999999;s:5:\"bytes\";i:475;s:11:\"size_before\";i:2900;s:10:\"size_after\";i:2425;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:25.039999999999999;s:5:\"bytes\";i:5870;s:11:\"size_before\";i:23443;s:10:\"size_after\";i:17573;s:4:\"time\";d:0.02;}}}");
INSERT INTO `wp_postmeta` VALUES ("1444","308","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:19.073794958181871;s:5:\"bytes\";i:6454;s:11:\"size_before\";i:33837;s:10:\"size_after\";i:27383;s:4:\"time\";d:0.070000000000000007;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.1899999999999995;s:5:\"bytes\";i:291;s:11:\"size_before\";i:3165;s:10:\"size_after\";i:2874;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:12.970000000000001;s:5:\"bytes\";i:499;s:11:\"size_before\";i:3847;s:10:\"size_after\";i:3348;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:21.109999999999999;s:5:\"bytes\";i:5664;s:11:\"size_before\";i:26825;s:10:\"size_after\";i:21161;s:4:\"time\";d:0.050000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1445","307","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:12.613733245747669;s:5:\"bytes\";i:9025;s:11:\"size_before\";i:71549;s:10:\"size_after\";i:62524;s:4:\"time\";d:0.040000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.98;s:5:\"bytes\";i:724;s:11:\"size_before\";i:6595;s:10:\"size_after\";i:5871;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.970000000000001;s:5:\"bytes\";i:1033;s:11:\"size_before\";i:9418;s:10:\"size_after\";i:8385;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:13.09;s:5:\"bytes\";i:7268;s:11:\"size_before\";i:55536;s:10:\"size_after\";i:48268;s:4:\"time\";d:0.02;}}}");
INSERT INTO `wp_postmeta` VALUES ("1446","306","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:15.675309597523221;s:5:\"bytes\";i:8101;s:11:\"size_before\";i:51680;s:10:\"size_after\";i:43579;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.81;s:5:\"bytes\";i:560;s:11:\"size_before\";i:5182;s:10:\"size_after\";i:4622;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.68;s:5:\"bytes\";i:784;s:11:\"size_before\";i:6713;s:10:\"size_after\";i:5929;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:16.98;s:5:\"bytes\";i:6757;s:11:\"size_before\";i:39785;s:10:\"size_after\";i:33028;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1447","305","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:14.075529648772273;s:5:\"bytes\";i:8524;s:11:\"size_before\";i:60559;s:10:\"size_after\";i:52035;s:4:\"time\";d:0.070000000000000007;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.460000000000001;s:5:\"bytes\";i:629;s:11:\"size_before\";i:6013;s:10:\"size_after\";i:5384;s:4:\"time\";d:0.029999999999999999;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.779999999999999;s:5:\"bytes\";i:807;s:11:\"size_before\";i:7489;s:10:\"size_after\";i:6682;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:15.06;s:5:\"bytes\";i:7088;s:11:\"size_before\";i:47057;s:10:\"size_after\";i:39969;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1448","304","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:12.503702506933786;s:5:\"bytes\";i:9287;s:11:\"size_before\";i:74274;s:10:\"size_after\";i:64987;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.5099999999999998;s:5:\"bytes\";i:352;s:11:\"size_before\";i:5406;s:10:\"size_after\";i:5054;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.5500000000000007;s:5:\"bytes\";i:667;s:11:\"size_before\";i:7801;s:10:\"size_after\";i:7134;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:13.539999999999999;s:5:\"bytes\";i:8268;s:11:\"size_before\";i:61067;s:10:\"size_after\";i:52799;s:4:\"time\";d:0.050000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1449","303","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:12.958579052795249;s:5:\"bytes\";i:9251;s:11:\"size_before\";i:71389;s:10:\"size_after\";i:62138;s:4:\"time\";d:0.050000000000000003;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.3899999999999997;s:5:\"bytes\";i:388;s:11:\"size_before\";i:5253;s:10:\"size_after\";i:4865;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.8699999999999992;s:5:\"bytes\";i:772;s:11:\"size_before\";i:7818;s:10:\"size_after\";i:7046;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:13.869999999999999;s:5:\"bytes\";i:8091;s:11:\"size_before\";i:58318;s:10:\"size_after\";i:50227;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1450","302","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:6.1675075070532266;s:5:\"bytes\";i:8154;s:11:\"size_before\";i:132209;s:10:\"size_after\";i:124055;s:4:\"time\";d:0.089999999999999997;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.04;s:5:\"bytes\";i:370;s:11:\"size_before\";i:7338;s:10:\"size_after\";i:6968;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.6699999999999999;s:5:\"bytes\";i:575;s:11:\"size_before\";i:12312;s:10:\"size_after\";i:11737;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.4000000000000004;s:5:\"bytes\";i:7209;s:11:\"size_before\";i:112559;s:10:\"size_after\";i:105350;s:4:\"time\";d:0.059999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1451","301","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:3.5210665023787522;s:5:\"bytes\";i:4115;s:11:\"size_before\";i:116868;s:10:\"size_after\";i:112753;s:4:\"time\";d:0.050000000000000003;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.0300000000000002;s:5:\"bytes\";i:345;s:11:\"size_before\";i:6853;s:10:\"size_after\";i:6508;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.0199999999999996;s:5:\"bytes\";i:477;s:11:\"size_before\";i:11872;s:10:\"size_after\";i:11395;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.3599999999999999;s:5:\"bytes\";i:3293;s:11:\"size_before\";i:98143;s:10:\"size_after\";i:94850;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1452","300","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:20.45160411416116;s:5:\"bytes\";i:6005;s:11:\"size_before\";i:29362;s:10:\"size_after\";i:23357;s:4:\"time\";d:0.050000000000000003;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.619999999999999;s:5:\"bytes\";i:265;s:11:\"size_before\";i:2496;s:10:\"size_after\";i:2231;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:13.699999999999999;s:5:\"bytes\";i:486;s:11:\"size_before\";i:3547;s:10:\"size_after\";i:3061;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:22.530000000000001;s:5:\"bytes\";i:5254;s:11:\"size_before\";i:23319;s:10:\"size_after\";i:18065;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1453","299","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:20.45160411416116;s:5:\"bytes\";i:6005;s:11:\"size_before\";i:29362;s:10:\"size_after\";i:23357;s:4:\"time\";d:0.040000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.619999999999999;s:5:\"bytes\";i:265;s:11:\"size_before\";i:2496;s:10:\"size_after\";i:2231;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:13.699999999999999;s:5:\"bytes\";i:486;s:11:\"size_before\";i:3547;s:10:\"size_after\";i:3061;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:22.530000000000001;s:5:\"bytes\";i:5254;s:11:\"size_before\";i:23319;s:10:\"size_after\";i:18065;s:4:\"time\";d:0.02;}}}");
INSERT INTO `wp_postmeta` VALUES ("1454","298","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:3.8202661831834481;s:5:\"bytes\";i:4762;s:11:\"size_before\";i:124651;s:10:\"size_after\";i:119889;s:4:\"time\";d:0.10000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.6200000000000001;s:5:\"bytes\";i:584;s:11:\"size_before\";i:8819;s:10:\"size_after\";i:8235;s:4:\"time\";d:0.040000000000000001;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.54;s:5:\"bytes\";i:606;s:11:\"size_before\";i:13360;s:10:\"size_after\";i:12754;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.4900000000000002;s:5:\"bytes\";i:3572;s:11:\"size_before\";i:102472;s:10:\"size_after\";i:98900;s:4:\"time\";d:0.050000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1455","297","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:7.643227687530767;s:5:\"bytes\";i:8074;s:11:\"size_before\";i:105636;s:10:\"size_after\";i:97562;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.4300000000000002;s:5:\"bytes\";i:190;s:11:\"size_before\";i:5537;s:10:\"size_after\";i:5347;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.25;s:5:\"bytes\";i:272;s:11:\"size_before\";i:8361;s:10:\"size_after\";i:8089;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.3000000000000007;s:5:\"bytes\";i:7612;s:11:\"size_before\";i:91738;s:10:\"size_after\";i:84126;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1456","287","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:2.451248540043466;s:5:\"bytes\";i:1658;s:11:\"size_before\";i:67639;s:10:\"size_after\";i:65981;s:4:\"time\";d:0.089999999999999997;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.8300000000000001;s:5:\"bytes\";i:133;s:11:\"size_before\";i:4707;s:10:\"size_after\";i:4574;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.4199999999999999;s:5:\"bytes\";i:217;s:11:\"size_before\";i:8980;s:10:\"size_after\";i:8763;s:4:\"time\";d:0.029999999999999999;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.4199999999999999;s:5:\"bytes\";i:1308;s:11:\"size_before\";i:53952;s:10:\"size_after\";i:52644;s:4:\"time\";d:0.050000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1457","283","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.598407382933686;s:5:\"bytes\";i:9463;s:11:\"size_before\";i:89287;s:10:\"size_after\";i:79824;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.8200000000000003;s:5:\"bytes\";i:687;s:11:\"size_before\";i:7786;s:10:\"size_after\";i:7099;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.4199999999999999;s:5:\"bytes\";i:1036;s:11:\"size_before\";i:11003;s:10:\"size_after\";i:9967;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.98;s:5:\"bytes\";i:7740;s:11:\"size_before\";i:70498;s:10:\"size_after\";i:62758;s:4:\"time\";d:0.059999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1458","282","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:3.4374906913705283;s:5:\"bytes\";i:3462;s:11:\"size_before\";i:100713;s:10:\"size_after\";i:97251;s:4:\"time\";d:0.10000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.1900000000000004;s:5:\"bytes\";i:555;s:11:\"size_before\";i:8971;s:10:\"size_after\";i:8416;s:4:\"time\";d:0.040000000000000001;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.5599999999999996;s:5:\"bytes\";i:611;s:11:\"size_before\";i:13391;s:10:\"size_after\";i:12780;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.9300000000000002;s:5:\"bytes\";i:2296;s:11:\"size_before\";i:78351;s:10:\"size_after\";i:76055;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1459","281","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:3.5999798883805121;s:5:\"bytes\";i:2864;s:11:\"size_before\";i:79556;s:10:\"size_after\";i:76692;s:4:\"time\";d:0.10000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.3700000000000001;s:5:\"bytes\";i:328;s:11:\"size_before\";i:6113;s:10:\"size_after\";i:5785;s:4:\"time\";d:0.029999999999999999;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.3700000000000001;s:5:\"bytes\";i:451;s:11:\"size_before\";i:10331;s:10:\"size_after\";i:9880;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.2999999999999998;s:5:\"bytes\";i:2085;s:11:\"size_before\";i:63112;s:10:\"size_after\";i:61027;s:4:\"time\";d:0.050000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1460","280","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:8.8497378358553611;s:5:\"bytes\";i:6515;s:11:\"size_before\";i:73618;s:10:\"size_after\";i:67103;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.4100000000000001;s:5:\"bytes\";i:362;s:11:\"size_before\";i:6695;s:10:\"size_after\";i:6333;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.7000000000000002;s:5:\"bytes\";i:500;s:11:\"size_before\";i:8777;s:10:\"size_after\";i:8277;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.7200000000000006;s:5:\"bytes\";i:5653;s:11:\"size_before\";i:58146;s:10:\"size_after\";i:52493;s:4:\"time\";d:0.050000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1461","279","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.598407382933686;s:5:\"bytes\";i:9463;s:11:\"size_before\";i:89287;s:10:\"size_after\";i:79824;s:4:\"time\";d:0.040000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.8200000000000003;s:5:\"bytes\";i:687;s:11:\"size_before\";i:7786;s:10:\"size_after\";i:7099;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.4199999999999999;s:5:\"bytes\";i:1036;s:11:\"size_before\";i:11003;s:10:\"size_after\";i:9967;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.98;s:5:\"bytes\";i:7740;s:11:\"size_before\";i:70498;s:10:\"size_after\";i:62758;s:4:\"time\";d:0.02;}}}");
INSERT INTO `wp_postmeta` VALUES ("1462","278","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:11.099152106578648;s:5:\"bytes\";i:9281;s:11:\"size_before\";i:83619;s:10:\"size_after\";i:74338;s:4:\"time\";d:0.089999999999999997;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.8800000000000008;s:5:\"bytes\";i:618;s:11:\"size_before\";i:6961;s:10:\"size_after\";i:6343;s:4:\"time\";d:0.029999999999999999;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.1899999999999995;s:5:\"bytes\";i:924;s:11:\"size_before\";i:10059;s:10:\"size_after\";i:9135;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.619999999999999;s:5:\"bytes\";i:7739;s:11:\"size_before\";i:66599;s:10:\"size_after\";i:58860;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1463","277","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.0322221231838844;s:5:\"bytes\";i:3619;s:11:\"size_before\";i:89752;s:10:\"size_after\";i:86133;s:4:\"time\";d:0.050000000000000003;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.6200000000000001;s:5:\"bytes\";i:282;s:11:\"size_before\";i:6110;s:10:\"size_after\";i:5828;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.4400000000000004;s:5:\"bytes\";i:480;s:11:\"size_before\";i:10822;s:10:\"size_after\";i:10342;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.9199999999999999;s:5:\"bytes\";i:2857;s:11:\"size_before\";i:72820;s:10:\"size_after\";i:69963;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1464","271","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.4013121924548937;s:5:\"bytes\";i:5635;s:11:\"size_before\";i:128030;s:10:\"size_after\";i:122395;s:4:\"time\";d:0.070000000000000007;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.0099999999999998;s:5:\"bytes\";i:363;s:11:\"size_before\";i:7239;s:10:\"size_after\";i:6876;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.6600000000000001;s:5:\"bytes\";i:647;s:11:\"size_before\";i:13899;s:10:\"size_after\";i:13252;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.3300000000000001;s:5:\"bytes\";i:4625;s:11:\"size_before\";i:106892;s:10:\"size_after\";i:102267;s:4:\"time\";d:0.050000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1465","270","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:5.1599301091560879;s:5:\"bytes\";i:8003;s:11:\"size_before\";i:155099;s:10:\"size_after\";i:147096;s:4:\"time\";d:0.13;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.5599999999999996;s:5:\"bytes\";i:314;s:11:\"size_before\";i:6887;s:10:\"size_after\";i:6573;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.6299999999999999;s:5:\"bytes\";i:636;s:11:\"size_before\";i:13726;s:10:\"size_after\";i:13090;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.2400000000000002;s:5:\"bytes\";i:7053;s:11:\"size_before\";i:134486;s:10:\"size_after\";i:127433;s:4:\"time\";d:0.089999999999999997;}}}");
INSERT INTO `wp_postmeta` VALUES ("1466","269","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:11.609057241244884;s:5:\"bytes\";i:7147;s:11:\"size_before\";i:61564;s:10:\"size_after\";i:54417;s:4:\"time\";d:0.090000000000000011;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.75;s:5:\"bytes\";i:516;s:11:\"size_before\";i:5896;s:10:\"size_after\";i:5380;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.2300000000000004;s:5:\"bytes\";i:688;s:11:\"size_before\";i:7456;s:10:\"size_after\";i:6768;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:12.33;s:5:\"bytes\";i:5943;s:11:\"size_before\";i:48212;s:10:\"size_after\";i:42269;s:4:\"time\";d:0.070000000000000007;}}}");
INSERT INTO `wp_postmeta` VALUES ("1467","268","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.412837380284415;s:5:\"bytes\";i:8611;s:11:\"size_before\";i:82696;s:10:\"size_after\";i:74085;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.8200000000000003;s:5:\"bytes\";i:609;s:11:\"size_before\";i:6904;s:10:\"size_after\";i:6295;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.4199999999999999;s:5:\"bytes\";i:827;s:11:\"size_before\";i:8778;s:10:\"size_after\";i:7951;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.710000000000001;s:5:\"bytes\";i:7175;s:11:\"size_before\";i:67014;s:10:\"size_after\";i:59839;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1468","267","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:8.7078378325775123;s:5:\"bytes\";i:8948;s:11:\"size_before\";i:102758;s:10:\"size_after\";i:93810;s:4:\"time\";d:0.11;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.3800000000000008;s:5:\"bytes\";i:730;s:11:\"size_before\";i:8714;s:10:\"size_after\";i:7984;s:4:\"time\";d:0.029999999999999999;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.8300000000000001;s:5:\"bytes\";i:779;s:11:\"size_before\";i:11401;s:10:\"size_after\";i:10622;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:9;s:5:\"bytes\";i:7439;s:11:\"size_before\";i:82643;s:10:\"size_after\";i:75204;s:4:\"time\";d:0.059999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1469","266","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:9.0132532059880877;s:5:\"bytes\";i:8399;s:11:\"size_before\";i:93185;s:10:\"size_after\";i:84786;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.8700000000000001;s:5:\"bytes\";i:534;s:11:\"size_before\";i:6785;s:10:\"size_after\";i:6251;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.1900000000000004;s:5:\"bytes\";i:749;s:11:\"size_before\";i:10422;s:10:\"size_after\";i:9673;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.3699999999999992;s:5:\"bytes\";i:7116;s:11:\"size_before\";i:75978;s:10:\"size_after\";i:68862;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1470","263","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:5.2854084909026042;s:5:\"bytes\";i:5926;s:11:\"size_before\";i:112120;s:10:\"size_after\";i:106194;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.0499999999999998;s:5:\"bytes\";i:516;s:11:\"size_before\";i:8531;s:10:\"size_after\";i:8015;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.1699999999999999;s:5:\"bytes\";i:726;s:11:\"size_before\";i:14039;s:10:\"size_after\";i:13313;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.2300000000000004;s:5:\"bytes\";i:4684;s:11:\"size_before\";i:89550;s:10:\"size_after\";i:84866;s:4:\"time\";d:0.050000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1471","254","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:6.2773306027210998;s:5:\"bytes\";i:7479;s:11:\"size_before\";i:119143;s:10:\"size_after\";i:111664;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.5;s:5:\"bytes\";i:644;s:11:\"size_before\";i:8581;s:10:\"size_after\";i:7937;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.1500000000000004;s:5:\"bytes\";i:1016;s:11:\"size_before\";i:14215;s:10:\"size_after\";i:13199;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.04;s:5:\"bytes\";i:5819;s:11:\"size_before\";i:96347;s:10:\"size_after\";i:90528;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1472","252","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:12.918643472149007;s:5:\"bytes\";i:7352;s:11:\"size_before\";i:56910;s:10:\"size_after\";i:49558;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.3900000000000006;s:5:\"bytes\";i:536;s:11:\"size_before\";i:5707;s:10:\"size_after\";i:5171;s:4:\"time\";d:0.029999999999999999;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.199999999999999;s:5:\"bytes\";i:740;s:11:\"size_before\";i:7253;s:10:\"size_after\";i:6513;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:13.82;s:5:\"bytes\";i:6076;s:11:\"size_before\";i:43950;s:10:\"size_after\";i:37874;s:4:\"time\";d:0.02;}}}");
INSERT INTO `wp_postmeta` VALUES ("1473","251","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:11.025338833235121;s:5:\"bytes\";i:9355;s:11:\"size_before\";i:84850;s:10:\"size_after\";i:75495;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.3800000000000008;s:5:\"bytes\";i:680;s:11:\"size_before\";i:7249;s:10:\"size_after\";i:6569;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.6999999999999993;s:5:\"bytes\";i:879;s:11:\"size_before\";i:9063;s:10:\"size_after\";i:8184;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.369999999999999;s:5:\"bytes\";i:7796;s:11:\"size_before\";i:68538;s:10:\"size_after\";i:60742;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1474","249","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.614582689494613;s:5:\"bytes\";i:10304;s:11:\"size_before\";i:97074;s:10:\"size_after\";i:86770;s:4:\"time\";d:0.10000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.5;s:5:\"bytes\";i:668;s:11:\"size_before\";i:7860;s:10:\"size_after\";i:7192;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.5;s:5:\"bytes\";i:958;s:11:\"size_before\";i:10080;s:10:\"size_after\";i:9122;s:4:\"time\";d:0.029999999999999999;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.970000000000001;s:5:\"bytes\";i:8678;s:11:\"size_before\";i:79134;s:10:\"size_after\";i:70456;s:4:\"time\";d:0.050000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1475","248","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:11.726724647896187;s:5:\"bytes\";i:9317;s:11:\"size_before\";i:79451;s:10:\"size_after\";i:70134;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.3200000000000003;s:5:\"bytes\";i:585;s:11:\"size_before\";i:7029;s:10:\"size_after\";i:6444;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.02;s:5:\"bytes\";i:914;s:11:\"size_before\";i:9126;s:10:\"size_after\";i:8212;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:12.35;s:5:\"bytes\";i:7818;s:11:\"size_before\";i:63296;s:10:\"size_after\";i:55478;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1476","247","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.813718601791674;s:5:\"bytes\";i:9850;s:11:\"size_before\";i:91088;s:10:\"size_after\";i:81238;s:4:\"time\";d:0.14000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.2699999999999996;s:5:\"bytes\";i:603;s:11:\"size_before\";i:7289;s:10:\"size_after\";i:6686;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.4800000000000004;s:5:\"bytes\";i:896;s:11:\"size_before\";i:9448;s:10:\"size_after\";i:8552;s:4:\"time\";d:0.029999999999999999;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.23;s:5:\"bytes\";i:8351;s:11:\"size_before\";i:74351;s:10:\"size_after\";i:66000;s:4:\"time\";d:0.10000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1477","246","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.200242862925307;s:5:\"bytes\";i:8568;s:11:\"size_before\";i:83998;s:10:\"size_after\";i:75430;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.1899999999999995;s:5:\"bytes\";i:578;s:11:\"size_before\";i:7055;s:10:\"size_after\";i:6477;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.8399999999999999;s:5:\"bytes\";i:908;s:11:\"size_before\";i:9228;s:10:\"size_after\";i:8320;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.460000000000001;s:5:\"bytes\";i:7082;s:11:\"size_before\";i:67715;s:10:\"size_after\";i:60633;s:4:\"time\";d:0.059999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1478","245","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:12.586949320967209;s:5:\"bytes\";i:7980;s:11:\"size_before\";i:63399;s:10:\"size_after\";i:55419;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.6799999999999997;s:5:\"bytes\";i:520;s:11:\"size_before\";i:5993;s:10:\"size_after\";i:5473;s:4:\"time\";d:0.029999999999999999;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.27;s:5:\"bytes\";i:800;s:11:\"size_before\";i:7791;s:10:\"size_after\";i:6991;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:13.42;s:5:\"bytes\";i:6660;s:11:\"size_before\";i:49615;s:10:\"size_after\";i:42955;s:4:\"time\";d:0.02;}}}");
INSERT INTO `wp_postmeta` VALUES ("1479","244","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.7811809077903504;s:5:\"bytes\";i:5882;s:11:\"size_before\";i:123024;s:10:\"size_after\";i:117142;s:4:\"time\";d:0.12000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.79;s:5:\"bytes\";i:267;s:11:\"size_before\";i:7052;s:10:\"size_after\";i:6785;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.0800000000000001;s:5:\"bytes\";i:534;s:11:\"size_before\";i:13085;s:10:\"size_after\";i:12551;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.9400000000000004;s:5:\"bytes\";i:5081;s:11:\"size_before\";i:102887;s:10:\"size_after\";i:97806;s:4:\"time\";d:0.10000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1480","243","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:5.8970292842795224;s:5:\"bytes\";i:8367;s:11:\"size_before\";i:141885;s:10:\"size_after\";i:133518;s:4:\"time\";d:0.10000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.54;s:5:\"bytes\";i:542;s:11:\"size_before\";i:8283;s:10:\"size_after\";i:7741;s:4:\"time\";d:0.029999999999999999;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.3399999999999999;s:5:\"bytes\";i:1224;s:11:\"size_before\";i:16683;s:10:\"size_after\";i:15459;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.6500000000000004;s:5:\"bytes\";i:6601;s:11:\"size_before\";i:116919;s:10:\"size_after\";i:110318;s:4:\"time\";d:0.059999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1481","240","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:9.6116291941227452;s:5:\"bytes\";i:9204;s:11:\"size_before\";i:95759;s:10:\"size_after\";i:86555;s:4:\"time\";d:0.050000000000000003;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.3499999999999996;s:5:\"bytes\";i:609;s:11:\"size_before\";i:8288;s:10:\"size_after\";i:7679;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.7300000000000004;s:5:\"bytes\";i:807;s:11:\"size_before\";i:10446;s:10:\"size_after\";i:9639;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.109999999999999;s:5:\"bytes\";i:7788;s:11:\"size_before\";i:77025;s:10:\"size_after\";i:69237;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1482","239","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:3.4193442801811145;s:5:\"bytes\";i:3134;s:11:\"size_before\";i:91655;s:10:\"size_after\";i:88521;s:4:\"time\";d:0.070000000000000007;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.3200000000000003;s:5:\"bytes\";i:372;s:11:\"size_before\";i:6995;s:10:\"size_after\";i:6623;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.9800000000000004;s:5:\"bytes\";i:623;s:11:\"size_before\";i:12503;s:10:\"size_after\";i:11880;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.96;s:5:\"bytes\";i:2139;s:11:\"size_before\";i:72157;s:10:\"size_after\";i:70018;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1483","238","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:13.569254724325855;s:5:\"bytes\";i:9586;s:11:\"size_before\";i:70645;s:10:\"size_after\";i:61059;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.43;s:5:\"bytes\";i:639;s:11:\"size_before\";i:6124;s:10:\"size_after\";i:5485;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.83;s:5:\"bytes\";i:1024;s:11:\"size_before\";i:9457;s:10:\"size_after\";i:8433;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:14.390000000000001;s:5:\"bytes\";i:7923;s:11:\"size_before\";i:55064;s:10:\"size_after\";i:47141;s:4:\"time\";d:0.059999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1484","236","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:9.7151786767307478;s:5:\"bytes\";i:6590;s:11:\"size_before\";i:67832;s:10:\"size_after\";i:61242;s:4:\"time\";d:0.070000000000000007;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.1900000000000004;s:5:\"bytes\";i:448;s:11:\"size_before\";i:6228;s:10:\"size_after\";i:5780;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.5199999999999996;s:5:\"bytes\";i:775;s:11:\"size_before\";i:9100;s:10:\"size_after\";i:8325;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.220000000000001;s:5:\"bytes\";i:5367;s:11:\"size_before\";i:52504;s:10:\"size_after\";i:47137;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1485","235","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:6.2661717732293578;s:5:\"bytes\";i:7023;s:11:\"size_before\";i:112078;s:10:\"size_after\";i:105055;s:4:\"time\";d:0.070000000000000007;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.3099999999999996;s:5:\"bytes\";i:475;s:11:\"size_before\";i:7533;s:10:\"size_after\";i:7058;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.6500000000000004;s:5:\"bytes\";i:541;s:11:\"size_before\";i:11628;s:10:\"size_after\";i:11087;s:4:\"time\";d:0.029999999999999999;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.46;s:5:\"bytes\";i:6007;s:11:\"size_before\";i:92917;s:10:\"size_after\";i:86910;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1486","234","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:9.7608121467884494;s:5:\"bytes\";i:6615;s:11:\"size_before\";i:67771;s:10:\"size_after\";i:61156;s:4:\"time\";d:0.13999999999999999;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.3600000000000003;s:5:\"bytes\";i:465;s:11:\"size_before\";i:6317;s:10:\"size_after\";i:5852;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.0600000000000005;s:5:\"bytes\";i:736;s:11:\"size_before\";i:9130;s:10:\"size_after\";i:8394;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.35;s:5:\"bytes\";i:5414;s:11:\"size_before\";i:52324;s:10:\"size_after\";i:46910;s:4:\"time\";d:0.12;}}}");
INSERT INTO `wp_postmeta` VALUES ("1487","227","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:7.2988250942141439;s:5:\"bytes\";i:11853;s:11:\"size_before\";i:162396;s:10:\"size_after\";i:150543;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.8799999999999999;s:5:\"bytes\";i:341;s:11:\"size_before\";i:4959;s:10:\"size_after\";i:4618;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.0800000000000001;s:5:\"bytes\";i:681;s:11:\"size_before\";i:9616;s:10:\"size_after\";i:8935;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.3300000000000001;s:5:\"bytes\";i:10831;s:11:\"size_before\";i:147821;s:10:\"size_after\";i:136990;s:4:\"time\";d:0.059999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1488","225","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:5.786347594043213;s:5:\"bytes\";i:6722;s:11:\"size_before\";i:116170;s:10:\"size_after\";i:109448;s:4:\"time\";d:0.11000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.3600000000000003;s:5:\"bytes\";i:396;s:11:\"size_before\";i:7393;s:10:\"size_after\";i:6997;s:4:\"time\";d:0.029999999999999999;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.1799999999999997;s:5:\"bytes\";i:688;s:11:\"size_before\";i:13274;s:10:\"size_after\";i:12586;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.9000000000000004;s:5:\"bytes\";i:5638;s:11:\"size_before\";i:95503;s:10:\"size_after\";i:89865;s:4:\"time\";d:0.070000000000000007;}}}");
INSERT INTO `wp_postmeta` VALUES ("1489","222","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.995944952733355;s:5:\"bytes\";i:7885;s:11:\"size_before\";i:157828;s:10:\"size_after\";i:149943;s:4:\"time\";d:0.089999999999999997;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.9900000000000002;s:5:\"bytes\";i:683;s:11:\"size_before\";i:9773;s:10:\"size_after\";i:9090;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.8499999999999996;s:5:\"bytes\";i:1294;s:11:\"size_before\";i:18904;s:10:\"size_after\";i:17610;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.5700000000000003;s:5:\"bytes\";i:5908;s:11:\"size_before\";i:129151;s:10:\"size_after\";i:123243;s:4:\"time\";d:0.059999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1490","221","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.944741071360566;s:5:\"bytes\";i:6492;s:11:\"size_before\";i:131291;s:10:\"size_after\";i:124799;s:4:\"time\";d:0.050000000000000003;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.4500000000000002;s:5:\"bytes\";i:690;s:11:\"size_before\";i:9257;s:10:\"size_after\";i:8567;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.5300000000000002;s:5:\"bytes\";i:1084;s:11:\"size_before\";i:16595;s:10:\"size_after\";i:15511;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.4699999999999998;s:5:\"bytes\";i:4718;s:11:\"size_before\";i:105439;s:10:\"size_after\";i:100721;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1491","220","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:5.1926473931825736;s:5:\"bytes\";i:5938;s:11:\"size_before\";i:114354;s:10:\"size_after\";i:108416;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.5599999999999996;s:5:\"bytes\";i:426;s:11:\"size_before\";i:7668;s:10:\"size_after\";i:7242;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.2599999999999998;s:5:\"bytes\";i:656;s:11:\"size_before\";i:12479;s:10:\"size_after\";i:11823;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.1500000000000004;s:5:\"bytes\";i:4856;s:11:\"size_before\";i:94207;s:10:\"size_after\";i:89351;s:4:\"time\";d:0.059999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1492","219","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.4543190959586285;s:5:\"bytes\";i:5814;s:11:\"size_before\";i:130525;s:10:\"size_after\";i:124711;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.4500000000000002;s:5:\"bytes\";i:544;s:11:\"size_before\";i:8430;s:10:\"size_after\";i:7886;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.75;s:5:\"bytes\";i:1071;s:11:\"size_before\";i:15855;s:10:\"size_after\";i:14784;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.9500000000000002;s:5:\"bytes\";i:4199;s:11:\"size_before\";i:106240;s:10:\"size_after\";i:102041;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1493","215","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:3.4977090232726944;s:5:\"bytes\";i:1542;s:11:\"size_before\";i:44086;s:10:\"size_after\";i:42544;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:1.8899999999999999;s:5:\"bytes\";i:67;s:11:\"size_before\";i:3536;s:10:\"size_after\";i:3469;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.02;s:5:\"bytes\";i:118;s:11:\"size_before\";i:5835;s:10:\"size_after\";i:5717;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.9100000000000001;s:5:\"bytes\";i:1357;s:11:\"size_before\";i:34715;s:10:\"size_after\";i:33358;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1494","212","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.2976449839194935;s:5:\"bytes\";i:3314;s:11:\"size_before\";i:77112;s:10:\"size_after\";i:73798;s:4:\"time\";d:0.089999999999999997;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.2200000000000002;s:5:\"bytes\";i:129;s:11:\"size_before\";i:4005;s:10:\"size_after\";i:3876;s:4:\"time\";d:0.029999999999999999;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.6400000000000001;s:5:\"bytes\";i:282;s:11:\"size_before\";i:10665;s:10:\"size_after\";i:10383;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.6500000000000004;s:5:\"bytes\";i:2903;s:11:\"size_before\";i:62442;s:10:\"size_after\";i:59539;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1495","211","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:6.3370522844744741;s:5:\"bytes\";i:6265;s:11:\"size_before\";i:98863;s:10:\"size_after\";i:92598;s:4:\"time\";d:0.10000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.21;s:5:\"bytes\";i:129;s:11:\"size_before\";i:4020;s:10:\"size_after\";i:3891;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.6699999999999999;s:5:\"bytes\";i:373;s:11:\"size_before\";i:10166;s:10:\"size_after\";i:9793;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.8099999999999996;s:5:\"bytes\";i:5763;s:11:\"size_before\";i:84677;s:10:\"size_after\";i:78914;s:4:\"time\";d:0.080000000000000002;}}}");
INSERT INTO `wp_postmeta` VALUES ("1496","198","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.3634270363618919;s:5:\"bytes\";i:4548;s:11:\"size_before\";i:104230;s:10:\"size_after\";i:99682;s:4:\"time\";d:0.089999999999999997;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.5599999999999996;s:5:\"bytes\";i:530;s:11:\"size_before\";i:8079;s:10:\"size_after\";i:7549;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.3899999999999997;s:5:\"bytes\";i:871;s:11:\"size_before\";i:13626;s:10:\"size_after\";i:12755;s:4:\"time\";d:0.029999999999999999;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.8100000000000001;s:5:\"bytes\";i:3147;s:11:\"size_before\";i:82525;s:10:\"size_after\";i:79378;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1497","189","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:13.340652666495362;s:5:\"bytes\";i:5711;s:11:\"size_before\";i:42809;s:10:\"size_after\";i:37098;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.4900000000000002;s:5:\"bytes\";i:171;s:11:\"size_before\";i:3114;s:10:\"size_after\";i:2943;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.2200000000000006;s:5:\"bytes\";i:332;s:11:\"size_before\";i:4038;s:10:\"size_after\";i:3706;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:14.609999999999999;s:5:\"bytes\";i:5208;s:11:\"size_before\";i:35657;s:10:\"size_after\";i:30449;s:4:\"time\";d:0.059999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1498","188","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:5.7428718994583576;s:5:\"bytes\";i:8673;s:11:\"size_before\";i:151022;s:10:\"size_after\";i:142349;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.2599999999999998;s:5:\"bytes\";i:666;s:11:\"size_before\";i:9175;s:10:\"size_after\";i:8509;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.1699999999999999;s:5:\"bytes\";i:1265;s:11:\"size_before\";i:17648;s:10:\"size_after\";i:16383;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.4299999999999997;s:5:\"bytes\";i:6742;s:11:\"size_before\";i:124199;s:10:\"size_after\";i:117457;s:4:\"time\";d:0.059999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1499","186","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:8.3435519248372216;s:5:\"bytes\";i:4831;s:11:\"size_before\";i:57901;s:10:\"size_after\";i:53070;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.7000000000000002;s:5:\"bytes\";i:342;s:11:\"size_before\";i:6002;s:10:\"size_after\";i:5660;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.04;s:5:\"bytes\";i:523;s:11:\"size_before\";i:7430;s:10:\"size_after\";i:6907;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.9199999999999999;s:5:\"bytes\";i:3966;s:11:\"size_before\";i:44469;s:10:\"size_after\";i:40503;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1500","185","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:12.60798157114519;s:5:\"bytes\";i:5911;s:11:\"size_before\";i:46883;s:10:\"size_after\";i:40972;s:4:\"time\";d:0.050000000000000003;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.9699999999999998;s:5:\"bytes\";i:265;s:11:\"size_before\";i:4440;s:10:\"size_after\";i:4175;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.2200000000000006;s:5:\"bytes\";i:466;s:11:\"size_before\";i:5672;s:10:\"size_after\";i:5206;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:14.09;s:5:\"bytes\";i:5180;s:11:\"size_before\";i:36771;s:10:\"size_after\";i:31591;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1501","184","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:22.054233715698594;s:5:\"bytes\";i:5441;s:11:\"size_before\";i:24671;s:10:\"size_after\";i:19230;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.9100000000000001;s:5:\"bytes\";i:182;s:11:\"size_before\";i:2042;s:10:\"size_after\";i:1860;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:12.27;s:5:\"bytes\";i:372;s:11:\"size_before\";i:3033;s:10:\"size_after\";i:2661;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:24.940000000000001;s:5:\"bytes\";i:4887;s:11:\"size_before\";i:19596;s:10:\"size_after\";i:14709;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1502","182","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.495178333957111;s:5:\"bytes\";i:5645;s:11:\"size_before\";i:125579;s:10:\"size_after\";i:119934;s:4:\"time\";d:0.089999999999999997;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.8499999999999996;s:5:\"bytes\";i:482;s:11:\"size_before\";i:8235;s:10:\"size_after\";i:7753;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.75;s:5:\"bytes\";i:865;s:11:\"size_before\";i:15054;s:10:\"size_after\";i:14189;s:4:\"time\";d:0.029999999999999999;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.2000000000000002;s:5:\"bytes\";i:4298;s:11:\"size_before\";i:102290;s:10:\"size_after\";i:97992;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1503","181","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.2029211903460126;s:5:\"bytes\";i:5381;s:11:\"size_before\";i:128030;s:10:\"size_after\";i:122649;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.6399999999999997;s:5:\"bytes\";i:445;s:11:\"size_before\";i:7892;s:10:\"size_after\";i:7447;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.8300000000000001;s:5:\"bytes\";i:892;s:11:\"size_before\";i:15306;s:10:\"size_after\";i:14414;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.8599999999999999;s:5:\"bytes\";i:4044;s:11:\"size_before\";i:104832;s:10:\"size_after\";i:100788;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1504","180","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:7.2988250942141439;s:5:\"bytes\";i:11853;s:11:\"size_before\";i:162396;s:10:\"size_after\";i:150543;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.8799999999999999;s:5:\"bytes\";i:341;s:11:\"size_before\";i:4959;s:10:\"size_after\";i:4618;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.0800000000000001;s:5:\"bytes\";i:681;s:11:\"size_before\";i:9616;s:10:\"size_after\";i:8935;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.3300000000000001;s:5:\"bytes\";i:10831;s:11:\"size_before\";i:147821;s:10:\"size_after\";i:136990;s:4:\"time\";d:0.050000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1505","177","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:8.2002361222489544;s:5:\"bytes\";i:14725;s:11:\"size_before\";i:179568;s:10:\"size_after\";i:164843;s:4:\"time\";d:0.11;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.7300000000000004;s:5:\"bytes\";i:333;s:11:\"size_before\";i:4948;s:10:\"size_after\";i:4615;s:4:\"time\";d:0.040000000000000001;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.4699999999999998;s:5:\"bytes\";i:724;s:11:\"size_before\";i:9688;s:10:\"size_after\";i:8964;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.2899999999999991;s:5:\"bytes\";i:13668;s:11:\"size_before\";i:164932;s:10:\"size_after\";i:151264;s:4:\"time\";d:0.059999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1506","176","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:5.786347594043213;s:5:\"bytes\";i:6722;s:11:\"size_before\";i:116170;s:10:\"size_after\";i:109448;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.3600000000000003;s:5:\"bytes\";i:396;s:11:\"size_before\";i:7393;s:10:\"size_after\";i:6997;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.1799999999999997;s:5:\"bytes\";i:688;s:11:\"size_before\";i:13274;s:10:\"size_after\";i:12586;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.9000000000000004;s:5:\"bytes\";i:5638;s:11:\"size_before\";i:95503;s:10:\"size_after\";i:89865;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1507","174","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.215602889561552;s:5:\"bytes\";i:5501;s:11:\"size_before\";i:53849;s:10:\"size_after\";i:48348;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.21;s:5:\"bytes\";i:70;s:11:\"size_before\";i:3162;s:10:\"size_after\";i:3092;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.7999999999999998;s:5:\"bytes\";i:187;s:11:\"size_before\";i:4927;s:10:\"size_after\";i:4740;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.460000000000001;s:5:\"bytes\";i:5244;s:11:\"size_before\";i:45760;s:10:\"size_after\";i:40516;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1508","173","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:5.3512308431676185;s:5:\"bytes\";i:8017;s:11:\"size_before\";i:149816;s:10:\"size_after\";i:141799;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.5899999999999999;s:5:\"bytes\";i:747;s:11:\"size_before\";i:9837;s:10:\"size_after\";i:9090;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.5800000000000001;s:5:\"bytes\";i:1427;s:11:\"size_before\";i:18820;s:10:\"size_after\";i:17393;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.8200000000000003;s:5:\"bytes\";i:5843;s:11:\"size_before\";i:121159;s:10:\"size_after\";i:115316;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1509","170","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.1615634247297892;s:5:\"bytes\";i:4655;s:11:\"size_before\";i:111857;s:10:\"size_after\";i:107202;s:4:\"time\";d:0.14000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.0700000000000003;s:5:\"bytes\";i:222;s:11:\"size_before\";i:5461;s:10:\"size_after\";i:5239;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.8799999999999999;s:5:\"bytes\";i:415;s:11:\"size_before\";i:10708;s:10:\"size_after\";i:10293;s:4:\"time\";d:0.040000000000000001;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.2000000000000002;s:5:\"bytes\";i:4018;s:11:\"size_before\";i:95688;s:10:\"size_after\";i:91670;s:4:\"time\";d:0.089999999999999997;}}}");
INSERT INTO `wp_postmeta` VALUES ("1510","167","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.3601190476190474;s:5:\"bytes\";i:2930;s:11:\"size_before\";i:67200;s:10:\"size_after\";i:64270;s:4:\"time\";d:0.11000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.29;s:5:\"bytes\";i:125;s:11:\"size_before\";i:3797;s:10:\"size_after\";i:3672;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.1400000000000001;s:5:\"bytes\";i:212;s:11:\"size_before\";i:6747;s:10:\"size_after\";i:6535;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.5800000000000001;s:5:\"bytes\";i:2593;s:11:\"size_before\";i:56656;s:10:\"size_after\";i:54063;s:4:\"time\";d:0.070000000000000007;}}}");
INSERT INTO `wp_postmeta` VALUES ("1511","165","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:9.8819992314126175;s:5:\"bytes\";i:8743;s:11:\"size_before\";i:88474;s:10:\"size_after\";i:79731;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.75;s:5:\"bytes\";i:643;s:11:\"size_before\";i:7350;s:10:\"size_after\";i:6707;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.5899999999999999;s:5:\"bytes\";i:904;s:11:\"size_before\";i:10528;s:10:\"size_after\";i:9624;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.19;s:5:\"bytes\";i:7196;s:11:\"size_before\";i:70596;s:10:\"size_after\";i:63400;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1512","164","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.736490337288224;s:5:\"bytes\";i:8289;s:11:\"size_before\";i:77204;s:10:\"size_after\";i:68915;s:4:\"time\";d:0.040000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.3200000000000003;s:5:\"bytes\";i:428;s:11:\"size_before\";i:5845;s:10:\"size_after\";i:5417;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.1999999999999993;s:5:\"bytes\";i:791;s:11:\"size_before\";i:9652;s:10:\"size_after\";i:8861;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.460000000000001;s:5:\"bytes\";i:7070;s:11:\"size_before\";i:61707;s:10:\"size_after\";i:54637;s:4:\"time\";d:0.02;}}}");
INSERT INTO `wp_postmeta` VALUES ("1513","163","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:8.6609616450163145;s:5:\"bytes\";i:7034;s:11:\"size_before\";i:81215;s:10:\"size_after\";i:74181;s:4:\"time\";d:0.089999999999999997;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.5899999999999999;s:5:\"bytes\";i:633;s:11:\"size_before\";i:7372;s:10:\"size_after\";i:6739;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.1100000000000003;s:5:\"bytes\";i:687;s:11:\"size_before\";i:9665;s:10:\"size_after\";i:8978;s:4:\"time\";d:0.040000000000000001;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.9000000000000004;s:5:\"bytes\";i:5714;s:11:\"size_before\";i:64178;s:10:\"size_after\";i:58464;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1514","159","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:7.7091777367321423;s:5:\"bytes\";i:17822;s:11:\"size_before\";i:231179;s:10:\"size_after\";i:213357;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.5800000000000001;s:5:\"bytes\";i:939;s:11:\"size_before\";i:10948;s:10:\"size_after\";i:10009;s:4:\"time\";d:0.029999999999999999;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:8;s:5:\"bytes\";i:1632;s:11:\"size_before\";i:20410;s:10:\"size_after\";i:18778;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.6299999999999999;s:5:\"bytes\";i:15251;s:11:\"size_before\";i:199821;s:10:\"size_after\";i:184570;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1515","158","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:6.0432539587761829;s:5:\"bytes\";i:10121;s:11:\"size_before\";i:167476;s:10:\"size_after\";i:157355;s:4:\"time\";d:0.10000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.4199999999999999;s:5:\"bytes\";i:498;s:11:\"size_before\";i:9182;s:10:\"size_after\";i:8684;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.9699999999999998;s:5:\"bytes\";i:827;s:11:\"size_before\";i:16644;s:10:\"size_after\";i:15817;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.21;s:5:\"bytes\";i:8796;s:11:\"size_before\";i:141650;s:10:\"size_after\";i:132854;s:4:\"time\";d:0.080000000000000002;}}}");
INSERT INTO `wp_postmeta` VALUES ("1516","156","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:11.673904992761674;s:5:\"bytes\";i:6935;s:11:\"size_before\";i:59406;s:10:\"size_after\";i:52471;s:4:\"time\";d:0.040000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.1500000000000004;s:5:\"bytes\";i:443;s:11:\"size_before\";i:5436;s:10:\"size_after\";i:4993;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.0299999999999994;s:5:\"bytes\";i:635;s:11:\"size_before\";i:7033;s:10:\"size_after\";i:6398;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:12.48;s:5:\"bytes\";i:5857;s:11:\"size_before\";i:46937;s:10:\"size_after\";i:41080;s:4:\"time\";d:0.02;}}}");
INSERT INTO `wp_postmeta` VALUES ("1517","155","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.146666511340735;s:5:\"bytes\";i:8710;s:11:\"size_before\";i:85841;s:10:\"size_after\";i:77131;s:4:\"time\";d:0.089999999999999997;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.3100000000000005;s:5:\"bytes\";i:600;s:11:\"size_before\";i:7221;s:10:\"size_after\";i:6621;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.1099999999999994;s:5:\"bytes\";i:863;s:11:\"size_before\";i:9476;s:10:\"size_after\";i:8613;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.48;s:5:\"bytes\";i:7247;s:11:\"size_before\";i:69144;s:10:\"size_after\";i:61897;s:4:\"time\";d:0.059999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1518","154","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.401152737752161;s:5:\"bytes\";i:9023;s:11:\"size_before\";i:86750;s:10:\"size_after\";i:77727;s:4:\"time\";d:0.050000000000000003;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.8900000000000006;s:5:\"bytes\";i:678;s:11:\"size_before\";i:7628;s:10:\"size_after\";i:6950;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.8900000000000006;s:5:\"bytes\";i:963;s:11:\"size_before\";i:9741;s:10:\"size_after\";i:8778;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.640000000000001;s:5:\"bytes\";i:7382;s:11:\"size_before\";i:69381;s:10:\"size_after\";i:61999;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1519","153","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.9219238929678077;s:5:\"bytes\";i:6449;s:11:\"size_before\";i:131026;s:10:\"size_after\";i:124577;s:4:\"time\";d:0.090000000000000011;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.4000000000000004;s:5:\"bytes\";i:685;s:11:\"size_before\";i:9259;s:10:\"size_after\";i:8574;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.6100000000000003;s:5:\"bytes\";i:1097;s:11:\"size_before\";i:16605;s:10:\"size_after\";i:15508;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.4400000000000004;s:5:\"bytes\";i:4667;s:11:\"size_before\";i:105162;s:10:\"size_after\";i:100495;s:4:\"time\";d:0.070000000000000007;}}}");
INSERT INTO `wp_postmeta` VALUES ("1520","152","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.262413754100216;s:5:\"bytes\";i:9073;s:11:\"size_before\";i:88410;s:10:\"size_after\";i:79337;s:4:\"time\";d:0.070000000000000007;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.96;s:5:\"bytes\";i:433;s:11:\"size_before\";i:6221;s:10:\"size_after\";i:5788;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.96;s:5:\"bytes\";i:701;s:11:\"size_before\";i:10074;s:10:\"size_after\";i:9373;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.01;s:5:\"bytes\";i:7939;s:11:\"size_before\";i:72115;s:10:\"size_after\";i:64176;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1521","150","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:5.6448525215456522;s:5:\"bytes\";i:7814;s:11:\"size_before\";i:138427;s:10:\"size_after\";i:130613;s:4:\"time\";d:0.10000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.5499999999999998;s:5:\"bytes\";i:285;s:11:\"size_before\";i:6261;s:10:\"size_after\";i:5976;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.8700000000000001;s:5:\"bytes\";i:432;s:11:\"size_before\";i:11169;s:10:\"size_after\";i:10737;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.8700000000000001;s:5:\"bytes\";i:7097;s:11:\"size_before\";i:120997;s:10:\"size_after\";i:113900;s:4:\"time\";d:0.059999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1522","149","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:5.0013782647646607;s:5:\"bytes\";i:5806;s:11:\"size_before\";i:116088;s:10:\"size_after\";i:110282;s:4:\"time\";d:0.12000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.4400000000000004;s:5:\"bytes\";i:607;s:11:\"size_before\";i:8161;s:10:\"size_after\";i:7554;s:4:\"time\";d:0.029999999999999999;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.7400000000000002;s:5:\"bytes\";i:1099;s:11:\"size_before\";i:16311;s:10:\"size_after\";i:15212;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.4800000000000004;s:5:\"bytes\";i:4100;s:11:\"size_before\";i:91616;s:10:\"size_after\";i:87516;s:4:\"time\";d:0.070000000000000007;}}}");
INSERT INTO `wp_postmeta` VALUES ("1523","148","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:9.9180640243902438;s:5:\"bytes\";i:8328;s:11:\"size_before\";i:83968;s:10:\"size_after\";i:75640;s:4:\"time\";d:0.070000000000000007;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.75;s:5:\"bytes\";i:554;s:11:\"size_before\";i:6332;s:10:\"size_after\";i:5778;s:4:\"time\";d:0.029999999999999999;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.4700000000000006;s:5:\"bytes\";i:845;s:11:\"size_before\";i:9978;s:10:\"size_after\";i:9133;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.24;s:5:\"bytes\";i:6929;s:11:\"size_before\";i:67658;s:10:\"size_after\";i:60729;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1524","147","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:12.342258229678041;s:5:\"bytes\";i:8196;s:11:\"size_before\";i:66406;s:10:\"size_after\";i:58210;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.029999999999999;s:5:\"bytes\";i:618;s:11:\"size_before\";i:6164;s:10:\"size_after\";i:5546;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.130000000000001;s:5:\"bytes\";i:897;s:11:\"size_before\";i:8060;s:10:\"size_after\";i:7163;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:12.800000000000001;s:5:\"bytes\";i:6681;s:11:\"size_before\";i:52182;s:10:\"size_after\";i:45501;s:4:\"time\";d:0.02;}}}");
INSERT INTO `wp_postmeta` VALUES ("1525","146","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:15.633518144226668;s:5:\"bytes\";i:8431;s:11:\"size_before\";i:53929;s:10:\"size_after\";i:45498;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.26;s:5:\"bytes\";i:616;s:11:\"size_before\";i:5469;s:10:\"size_after\";i:4853;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:13.289999999999999;s:5:\"bytes\";i:942;s:11:\"size_before\";i:7086;s:10:\"size_after\";i:6144;s:4:\"time\";d:0.029999999999999999;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:16.609999999999999;s:5:\"bytes\";i:6873;s:11:\"size_before\";i:41374;s:10:\"size_after\";i:34501;s:4:\"time\";d:0.02;}}}");
INSERT INTO `wp_postmeta` VALUES ("1526","145","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.848710180850087;s:5:\"bytes\";i:9454;s:11:\"size_before\";i:87144;s:10:\"size_after\";i:77690;s:4:\"time\";d:0.11000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.8499999999999996;s:5:\"bytes\";i:752;s:11:\"size_before\";i:7636;s:10:\"size_after\";i:6884;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.56;s:5:\"bytes\";i:1054;s:11:\"size_before\";i:9985;s:10:\"size_after\";i:8931;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:11;s:5:\"bytes\";i:7648;s:11:\"size_before\";i:69523;s:10:\"size_after\";i:61875;s:4:\"time\";d:0.070000000000000007;}}}");
INSERT INTO `wp_postmeta` VALUES ("1527","144","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.788865871371765;s:5:\"bytes\";i:9062;s:11:\"size_before\";i:83994;s:10:\"size_after\";i:74932;s:4:\"time\";d:0.050000000000000003;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.8000000000000007;s:5:\"bytes\";i:547;s:11:\"size_before\";i:6218;s:10:\"size_after\";i:5671;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.2400000000000002;s:5:\"bytes\";i:914;s:11:\"size_before\";i:9890;s:10:\"size_after\";i:8976;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.199999999999999;s:5:\"bytes\";i:7601;s:11:\"size_before\";i:67886;s:10:\"size_after\";i:60285;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1528","142","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.4543190959586285;s:5:\"bytes\";i:5814;s:11:\"size_before\";i:130525;s:10:\"size_after\";i:124711;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.4500000000000002;s:5:\"bytes\";i:544;s:11:\"size_before\";i:8430;s:10:\"size_after\";i:7886;s:4:\"time\";d:0.029999999999999999;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.75;s:5:\"bytes\";i:1071;s:11:\"size_before\";i:15855;s:10:\"size_after\";i:14784;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.9500000000000002;s:5:\"bytes\";i:4199;s:11:\"size_before\";i:106240;s:10:\"size_after\";i:102041;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1529","140","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.204648812531582;s:5:\"bytes\";i:12117;s:11:\"size_before\";i:118740;s:10:\"size_after\";i:106623;s:4:\"time\";d:0.089999999999999997;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.7599999999999998;s:5:\"bytes\";i:720;s:11:\"size_before\";i:8221;s:10:\"size_after\";i:7501;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.2400000000000002;s:5:\"bytes\";i:1175;s:11:\"size_before\";i:12717;s:10:\"size_after\";i:11542;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.449999999999999;s:5:\"bytes\";i:10222;s:11:\"size_before\";i:97802;s:10:\"size_after\";i:87580;s:4:\"time\";d:0.050000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1530","139","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:9.6598515273214076;s:5:\"bytes\";i:9525;s:11:\"size_before\";i:98604;s:10:\"size_after\";i:89079;s:4:\"time\";d:0.070000000000000007;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.8399999999999999;s:5:\"bytes\";i:723;s:11:\"size_before\";i:8181;s:10:\"size_after\";i:7458;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.4100000000000001;s:5:\"bytes\";i:966;s:11:\"size_before\";i:11492;s:10:\"size_after\";i:10526;s:4:\"time\";d:0.040000000000000001;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.9299999999999997;s:5:\"bytes\";i:7836;s:11:\"size_before\";i:78931;s:10:\"size_after\";i:71095;s:4:\"time\";d:0.02;}}}");
INSERT INTO `wp_postmeta` VALUES ("1531","137","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.777827565302196;s:5:\"bytes\";i:8178;s:11:\"size_before\";i:75878;s:10:\"size_after\";i:67700;s:4:\"time\";d:0.089999999999999997;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.5099999999999998;s:5:\"bytes\";i:501;s:11:\"size_before\";i:6675;s:10:\"size_after\";i:6174;s:4:\"time\";d:0.029999999999999999;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.5500000000000007;s:5:\"bytes\";i:837;s:11:\"size_before\";i:8762;s:10:\"size_after\";i:7925;s:4:\"time\";d:0.029999999999999999;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.32;s:5:\"bytes\";i:6840;s:11:\"size_before\";i:60441;s:10:\"size_after\";i:53601;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1532","136","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.577627425648949;s:5:\"bytes\";i:7942;s:11:\"size_before\";i:75083;s:10:\"size_after\";i:67141;s:4:\"time\";d:0.070000000000000007;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.0199999999999996;s:5:\"bytes\";i:558;s:11:\"size_before\";i:6955;s:10:\"size_after\";i:6397;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.9100000000000001;s:5:\"bytes\";i:907;s:11:\"size_before\";i:9149;s:10:\"size_after\";i:8242;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.98;s:5:\"bytes\";i:6477;s:11:\"size_before\";i:58979;s:10:\"size_after\";i:52502;s:4:\"time\";d:0.050000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1533","135","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:9.8604276311772683;s:5:\"bytes\";i:8075;s:11:\"size_before\";i:81893;s:10:\"size_after\";i:73818;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.2999999999999998;s:5:\"bytes\";i:518;s:11:\"size_before\";i:7092;s:10:\"size_after\";i:6574;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.2400000000000002;s:5:\"bytes\";i:872;s:11:\"size_before\";i:9438;s:10:\"size_after\";i:8566;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.23;s:5:\"bytes\";i:6685;s:11:\"size_before\";i:65363;s:10:\"size_after\";i:58678;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1534","133","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:8.6987750868931499;s:5:\"bytes\";i:24827;s:11:\"size_before\";i:285408;s:10:\"size_after\";i:260581;s:4:\"time\";d:0.089999999999999997;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.6999999999999993;s:5:\"bytes\";i:1194;s:11:\"size_before\";i:12310;s:10:\"size_after\";i:11116;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.8699999999999992;s:5:\"bytes\";i:2531;s:11:\"size_before\";i:25645;s:10:\"size_after\";i:23114;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.5299999999999994;s:5:\"bytes\";i:21102;s:11:\"size_before\";i:247453;s:10:\"size_after\";i:226351;s:4:\"time\";d:0.059999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1535","129","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.995944952733355;s:5:\"bytes\";i:7885;s:11:\"size_before\";i:157828;s:10:\"size_after\";i:149943;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.9900000000000002;s:5:\"bytes\";i:683;s:11:\"size_before\";i:9773;s:10:\"size_after\";i:9090;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.8499999999999996;s:5:\"bytes\";i:1294;s:11:\"size_before\";i:18904;s:10:\"size_after\";i:17610;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.5700000000000003;s:5:\"bytes\";i:5908;s:11:\"size_before\";i:129151;s:10:\"size_after\";i:123243;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1536","128","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:8.5612209420819791;s:5:\"bytes\";i:14282;s:11:\"size_before\";i:166822;s:10:\"size_after\";i:152540;s:4:\"time\";d:0.070000000000000007;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.5899999999999999;s:5:\"bytes\";i:893;s:11:\"size_before\";i:9312;s:10:\"size_after\";i:8419;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.3200000000000003;s:5:\"bytes\";i:1736;s:11:\"size_before\";i:18625;s:10:\"size_after\";i:16889;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.3900000000000006;s:5:\"bytes\";i:11653;s:11:\"size_before\";i:138885;s:10:\"size_after\";i:127232;s:4:\"time\";d:0.050000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1537","127","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.332895484933442;s:5:\"bytes\";i:10541;s:11:\"size_before\";i:102014;s:10:\"size_after\";i:91473;s:4:\"time\";d:0.090000000000000011;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.3499999999999996;s:5:\"bytes\";i:790;s:11:\"size_before\";i:8448;s:10:\"size_after\";i:7658;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.2899999999999991;s:5:\"bytes\";i:1112;s:11:\"size_before\";i:11970;s:10:\"size_after\";i:10858;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.59;s:5:\"bytes\";i:8639;s:11:\"size_before\";i:81596;s:10:\"size_after\";i:72957;s:4:\"time\";d:0.070000000000000007;}}}");
INSERT INTO `wp_postmeta` VALUES ("1538","126","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.66800767179679;s:5:\"bytes\";i:9122;s:11:\"size_before\";i:85508;s:10:\"size_after\";i:76386;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.5;s:5:\"bytes\";i:634;s:11:\"size_before\";i:7458;s:10:\"size_after\";i:6824;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.51;s:5:\"bytes\";i:1008;s:11:\"size_before\";i:9594;s:10:\"size_after\";i:8586;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.93;s:5:\"bytes\";i:7480;s:11:\"size_before\";i:68456;s:10:\"size_after\";i:60976;s:4:\"time\";d:0.050000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1539","125","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:11.143281860134897;s:5:\"bytes\";i:10045;s:11:\"size_before\";i:90144;s:10:\"size_after\";i:80099;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.5500000000000007;s:5:\"bytes\";i:684;s:11:\"size_before\";i:7166;s:10:\"size_after\";i:6482;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.4700000000000006;s:5:\"bytes\";i:1090;s:11:\"size_before\";i:11509;s:10:\"size_after\";i:10419;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.57;s:5:\"bytes\";i:8271;s:11:\"size_before\";i:71469;s:10:\"size_after\";i:63198;s:4:\"time\";d:0.059999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1540","117","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:12.603142761618189;s:5:\"bytes\";i:9424;s:11:\"size_before\";i:74775;s:10:\"size_after\";i:65351;s:4:\"time\";d:0.11;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.8200000000000003;s:5:\"bytes\";i:644;s:11:\"size_before\";i:6560;s:10:\"size_after\";i:5916;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.25;s:5:\"bytes\";i:950;s:11:\"size_before\";i:8444;s:10:\"size_after\";i:7494;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:13.1;s:5:\"bytes\";i:7830;s:11:\"size_before\";i:59771;s:10:\"size_after\";i:51941;s:4:\"time\";d:0.080000000000000002;}}}");
INSERT INTO `wp_postmeta` VALUES ("1541","116","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:12.464658095055333;s:5:\"bytes\";i:9743;s:11:\"size_before\";i:78165;s:10:\"size_after\";i:68422;s:4:\"time\";d:0.050000000000000003;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.7799999999999994;s:5:\"bytes\";i:706;s:11:\"size_before\";i:7220;s:10:\"size_after\";i:6514;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.43;s:5:\"bytes\";i:956;s:11:\"size_before\";i:9170;s:10:\"size_after\";i:8214;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:13.08;s:5:\"bytes\";i:8081;s:11:\"size_before\";i:61775;s:10:\"size_after\";i:53694;s:4:\"time\";d:0.02;}}}");
INSERT INTO `wp_postmeta` VALUES ("1542","115","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:14.059930410095731;s:5:\"bytes\";i:8122;s:11:\"size_before\";i:57767;s:10:\"size_after\";i:49645;s:4:\"time\";d:0.050000000000000003;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.1899999999999995;s:5:\"bytes\";i:503;s:11:\"size_before\";i:5473;s:10:\"size_after\";i:4970;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.859999999999999;s:5:\"bytes\";i:768;s:11:\"size_before\";i:7072;s:10:\"size_after\";i:6304;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:15.15;s:5:\"bytes\";i:6851;s:11:\"size_before\";i:45222;s:10:\"size_after\";i:38371;s:4:\"time\";d:0.02;}}}");
INSERT INTO `wp_postmeta` VALUES ("1543","114","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:14.259932771256956;s:5:\"bytes\";i:10351;s:11:\"size_before\";i:72588;s:10:\"size_after\";i:62237;s:4:\"time\";d:0.11;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.4199999999999999;s:5:\"bytes\";i:484;s:11:\"size_before\";i:5747;s:10:\"size_after\";i:5263;s:4:\"time\";d:0.029999999999999999;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:8.9900000000000002;s:5:\"bytes\";i:761;s:11:\"size_before\";i:8463;s:10:\"size_after\";i:7702;s:4:\"time\";d:0.029999999999999999;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:15.6;s:5:\"bytes\";i:9106;s:11:\"size_before\";i:58378;s:10:\"size_after\";i:49272;s:4:\"time\";d:0.050000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1544","113","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.9997556923678301;s:5:\"bytes\";i:4093;s:11:\"size_before\";i:81864;s:10:\"size_after\";i:77771;s:4:\"time\";d:0.070000000000000007;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.1200000000000001;s:5:\"bytes\";i:165;s:11:\"size_before\";i:5288;s:10:\"size_after\";i:5123;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.3100000000000001;s:5:\"bytes\";i:199;s:11:\"size_before\";i:8604;s:10:\"size_after\";i:8405;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.4900000000000002;s:5:\"bytes\";i:3729;s:11:\"size_before\";i:67972;s:10:\"size_after\";i:64243;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1545","112","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:5.064737242955065;s:5:\"bytes\";i:6384;s:11:\"size_before\";i:126048;s:10:\"size_after\";i:119664;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.7800000000000002;s:5:\"bytes\";i:442;s:11:\"size_before\";i:7649;s:10:\"size_after\";i:7207;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.9500000000000002;s:5:\"bytes\";i:683;s:11:\"size_before\";i:13808;s:10:\"size_after\";i:13125;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.0300000000000002;s:5:\"bytes\";i:5259;s:11:\"size_before\";i:104591;s:10:\"size_after\";i:99332;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1546","107","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:12.231961890499736;s:5:\"bytes\";i:9475;s:11:\"size_before\";i:77461;s:10:\"size_after\";i:67986;s:4:\"time\";d:0.089999999999999997;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.6699999999999999;s:5:\"bytes\";i:615;s:11:\"size_before\";i:6358;s:10:\"size_after\";i:5743;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.25;s:5:\"bytes\";i:946;s:11:\"size_before\";i:10223;s:10:\"size_after\";i:9277;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:13;s:5:\"bytes\";i:7914;s:11:\"size_before\";i:60880;s:10:\"size_after\";i:52966;s:4:\"time\";d:0.059999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1547","105","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:13.638042212311452;s:5:\"bytes\";i:9602;s:11:\"size_before\";i:70406;s:10:\"size_after\";i:60804;s:4:\"time\";d:0.059999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.369999999999999;s:5:\"bytes\";i:633;s:11:\"size_before\";i:6107;s:10:\"size_after\";i:5474;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.18;s:5:\"bytes\";i:1060;s:11:\"size_before\";i:9485;s:10:\"size_after\";i:8425;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:14.43;s:5:\"bytes\";i:7909;s:11:\"size_before\";i:54814;s:10:\"size_after\";i:46905;s:4:\"time\";d:0.029999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1548","98","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:5.5978917912982054;s:5:\"bytes\";i:4121;s:11:\"size_before\";i:73617;s:10:\"size_after\";i:69496;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.5999999999999996;s:5:\"bytes\";i:288;s:11:\"size_before\";i:6262;s:10:\"size_after\";i:5974;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.27;s:5:\"bytes\";i:277;s:11:\"size_before\";i:8477;s:10:\"size_after\";i:8200;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.04;s:5:\"bytes\";i:3556;s:11:\"size_before\";i:58878;s:10:\"size_after\";i:55322;s:4:\"time\";d:0.050000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1549","97","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:12.61607518586057;s:5:\"bytes\";i:8994;s:11:\"size_before\";i:71290;s:10:\"size_after\";i:62296;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:10.539999999999999;s:5:\"bytes\";i:639;s:11:\"size_before\";i:6063;s:10:\"size_after\";i:5424;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.24;s:5:\"bytes\";i:1061;s:11:\"size_before\";i:9439;s:10:\"size_after\";i:8378;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:13.07;s:5:\"bytes\";i:7294;s:11:\"size_before\";i:55788;s:10:\"size_after\";i:48494;s:4:\"time\";d:0.050000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1550","76","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:0.73865808392832921;s:5:\"bytes\";i:599;s:11:\"size_before\";i:81093;s:10:\"size_after\";i:80494;s:4:\"time\";d:0.080000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.73;s:5:\"bytes\";i:165;s:11:\"size_before\";i:4425;s:10:\"size_after\";i:4260;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.4500000000000002;s:5:\"bytes\";i:369;s:11:\"size_before\";i:10699;s:10:\"size_after\";i:10330;s:4:\"time\";d:0.01;}s:4:\"full\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.10000000000000001;s:5:\"bytes\";i:65;s:11:\"size_before\";i:65969;s:10:\"size_after\";i:65904;s:4:\"time\";d:0.059999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1551","72","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:0.55154676002000425;s:5:\"bytes\";i:386;s:11:\"size_before\";i:69985;s:10:\"size_after\";i:69599;s:4:\"time\";d:0.070000000000000007;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.5499999999999998;s:5:\"bytes\";i:102;s:11:\"size_before\";i:4007;s:10:\"size_after\";i:3905;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.7799999999999998;s:5:\"bytes\";i:284;s:11:\"size_before\";i:10222;s:10:\"size_after\";i:9938;s:4:\"time\";d:0.01;}s:4:\"full\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:55756;s:10:\"size_after\";i:55756;s:4:\"time\";d:0.050000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1552","30","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:20.808577172213536;s:5:\"bytes\";i:9316;s:11:\"size_before\";i:44770;s:10:\"size_after\";i:35454;s:4:\"time\";d:0.23000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:21.199999999999999;s:5:\"bytes\";i:2251;s:11:\"size_before\";i:10619;s:10:\"size_after\";i:8368;s:4:\"time\";d:0.029999999999999999;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:18.969999999999999;s:5:\"bytes\";i:2318;s:11:\"size_before\";i:12221;s:10:\"size_after\";i:9903;s:4:\"time\";d:0.040000000000000001;}s:4:\"full\";O:8:\"stdClass\":5:{s:7:\"percent\";d:21.649999999999999;s:5:\"bytes\";i:4747;s:11:\"size_before\";i:21930;s:10:\"size_after\";i:17183;s:4:\"time\";d:0.16;}}}");
INSERT INTO `wp_postmeta` VALUES ("1553","352","_wp_attached_file","2018/10/logo-dandy.png");
INSERT INTO `wp_postmeta` VALUES ("1554","352","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:40.608404766882714;s:5:\"bytes\";i:19423;s:11:\"size_before\";i:47830;s:10:\"size_after\";i:28407;s:4:\"time\";d:0.27000000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.7300000000000004;s:5:\"bytes\";i:350;s:11:\"size_before\";i:4526;s:10:\"size_after\";i:4176;s:4:\"time\";d:0.040000000000000001;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.4000000000000004;s:5:\"bytes\";i:420;s:11:\"size_before\";i:9536;s:10:\"size_after\";i:9116;s:4:\"time\";d:0.070000000000000007;}s:4:\"full\";O:8:\"stdClass\":5:{s:7:\"percent\";d:55.240000000000002;s:5:\"bytes\";i:18653;s:11:\"size_before\";i:33768;s:10:\"size_after\";i:15115;s:4:\"time\";d:0.16;}}}");
INSERT INTO `wp_postmeta` VALUES ("1555","352","_wp_attachment_metadata","a:5:{s:5:\"width\";i:500;s:6:\"height\";i:552;s:4:\"file\";s:22:\"2018/10/logo-dandy.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"logo-dandy-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"logo-dandy-272x300.png\";s:5:\"width\";i:272;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES ("1556","16","_yoast_wpseo_title","About Us %%sep%% %%sitename%%");
INSERT INTO `wp_postmeta` VALUES ("1557","16","_yoast_wpseo_content_score","60");
INSERT INTO `wp_postmeta` VALUES ("1558","42","_yoast_wpseo_title","Contact %%sep%% %%sitename%%");
INSERT INTO `wp_postmeta` VALUES ("1559","42","_yoast_wpseo_content_score","90");
INSERT INTO `wp_postmeta` VALUES ("1560","354","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES ("1561","354","_edit_lock","1541684971:2");
INSERT INTO `wp_postmeta` VALUES ("1562","355","_wp_attached_file","2018/11/revolver.jpg");
INSERT INTO `wp_postmeta` VALUES ("1563","355","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:2.4296571470285264;s:5:\"bytes\";i:5991;s:11:\"size_before\";i:246578;s:10:\"size_after\";i:240587;s:4:\"time\";d:0.16;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:4:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:9382;s:10:\"size_after\";i:9382;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:0.20000000000000001;s:5:\"bytes\";i:34;s:11:\"size_before\";i:17342;s:10:\"size_after\";i:17308;s:4:\"time\";d:0.02;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:2.0699999999999998;s:5:\"bytes\";i:1661;s:11:\"size_before\";i:80398;s:10:\"size_after\";i:78737;s:4:\"time\";d:0.050000000000000003;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.0800000000000001;s:5:\"bytes\";i:4296;s:11:\"size_before\";i:139456;s:10:\"size_after\";i:135160;s:4:\"time\";d:0.080000000000000002;}}}");
INSERT INTO `wp_postmeta` VALUES ("1564","355","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:20:\"2018/11/revolver.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"revolver-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"revolver-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"revolver-768x428.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:428;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"revolver-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES ("1565","356","_wp_attached_file","2018/11/revolver3.png");
INSERT INTO `wp_postmeta` VALUES ("1566","356","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:643162;s:10:\"size_after\";i:643162;s:4:\"time\";d:1.01;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:4:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:23228;s:10:\"size_after\";i:23228;s:4:\"time\";d:0.059999999999999998;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:36164;s:10:\"size_after\";i:36164;s:4:\"time\";d:0.11;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:210399;s:10:\"size_after\";i:210399;s:4:\"time\";d:0.33000000000000002;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:373371;s:10:\"size_after\";i:373371;s:4:\"time\";d:0.51000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1567","356","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1072;s:4:\"file\";s:21:\"2018/11/revolver3.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"revolver3-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"revolver3-300x166.png\";s:5:\"width\";i:300;s:6:\"height\";i:166;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"revolver3-768x424.png\";s:5:\"width\";i:768;s:6:\"height\";i:424;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"revolver3-1024x566.png\";s:5:\"width\";i:1024;s:6:\"height\";i:566;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES ("1568","357","_wp_attached_file","2018/11/revolver2.png");
INSERT INTO `wp_postmeta` VALUES ("1569","357","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:381186;s:10:\"size_after\";i:381186;s:4:\"time\";d:0.83000000000000007;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:25364;s:10:\"size_after\";i:25364;s:4:\"time\";d:0.080000000000000002;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:36687;s:10:\"size_after\";i:36687;s:4:\"time\";d:0.070000000000000007;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:319135;s:10:\"size_after\";i:319135;s:4:\"time\";d:0.68000000000000005;}}}");
INSERT INTO `wp_postmeta` VALUES ("1570","357","_wp_attachment_metadata","a:5:{s:5:\"width\";i:626;s:6:\"height\";i:1268;s:4:\"file\";s:21:\"2018/11/revolver2.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"revolver2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"revolver2-148x300.png\";s:5:\"width\";i:148;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"revolver2-506x1024.png\";s:5:\"width\";i:506;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES ("1571","358","_wp_attached_file","2018/11/revolver1.png");
INSERT INTO `wp_postmeta` VALUES ("1572","358","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:418533;s:10:\"size_after\";i:418533;s:4:\"time\";d:0.97999999999999998;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:4:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:17414;s:10:\"size_after\";i:17414;s:4:\"time\";d:0.040000000000000001;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:28481;s:10:\"size_after\";i:28481;s:4:\"time\";d:0.080000000000000002;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:139870;s:10:\"size_after\";i:139870;s:4:\"time\";d:0.31;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:232768;s:10:\"size_after\";i:232768;s:4:\"time\";d:0.55000000000000004;}}}");
INSERT INTO `wp_postmeta` VALUES ("1573","358","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:21:\"2018/11/revolver1.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"revolver1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"revolver1-300x167.png\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"revolver1-768x428.png\";s:5:\"width\";i:768;s:6:\"height\";i:428;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"revolver1-1024x570.png\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES ("1574","354","descatar_home","a:1:{i:0;s:2:\"si\";}");
INSERT INTO `wp_postmeta` VALUES ("1575","354","_descatar_home","field_54aec60b5808b");
INSERT INTO `wp_postmeta` VALUES ("1576","354","middle_image","");
INSERT INTO `wp_postmeta` VALUES ("1577","354","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("1578","354","subtitle_esp","Desarrollo E-commerce");
INSERT INTO `wp_postmeta` VALUES ("1579","354","_subtitle_esp","field_54ac29a4ce78c");
INSERT INTO `wp_postmeta` VALUES ("1580","354","subtitle_eng","E-commerce Development");
INSERT INTO `wp_postmeta` VALUES ("1581","354","_subtitle_eng","field_54ac29b6ce78d");
INSERT INTO `wp_postmeta` VALUES ("1582","354","imagen_header","355");
INSERT INTO `wp_postmeta` VALUES ("1583","354","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1584","354","_yoast_wpseo_content_score","60");
INSERT INTO `wp_postmeta` VALUES ("1585","354","_thumbnail_id","358");
INSERT INTO `wp_postmeta` VALUES ("1586","354","_yoast_wpseo_title","Revolver %%sep%% %%sitename%%");
INSERT INTO `wp_postmeta` VALUES ("1587","360","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES ("1588","360","_menu_item_menu_item_parent","349");
INSERT INTO `wp_postmeta` VALUES ("1589","360","_menu_item_object_id","354");
INSERT INTO `wp_postmeta` VALUES ("1590","360","_menu_item_object","works");
INSERT INTO `wp_postmeta` VALUES ("1591","360","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES ("1592","360","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES ("1593","360","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES ("1594","360","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES ("1596","25","_yoast_wpseo_content_score","60");
INSERT INTO `wp_postmeta` VALUES ("1597","361","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES ("1598","361","_edit_lock","1541603044:2");
INSERT INTO `wp_postmeta` VALUES ("1599","362","_wp_attached_file","2018/11/jadepark3.png");
INSERT INTO `wp_postmeta` VALUES ("1600","362","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:476115;s:10:\"size_after\";i:476115;s:4:\"time\";d:0.82999999999999996;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:33239;s:10:\"size_after\";i:33239;s:4:\"time\";d:0.040000000000000001;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:43355;s:10:\"size_after\";i:43355;s:4:\"time\";d:0.059999999999999998;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:399521;s:10:\"size_after\";i:399521;s:4:\"time\";d:0.72999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1601","362","_wp_attachment_metadata","a:5:{s:5:\"width\";i:626;s:6:\"height\";i:1268;s:4:\"file\";s:21:\"2018/11/jadepark3.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"jadepark3-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"jadepark3-148x300.png\";s:5:\"width\";i:148;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"jadepark3-506x1024.png\";s:5:\"width\";i:506;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES ("1602","363","_wp_attached_file","2018/11/jadepark2.png");
INSERT INTO `wp_postmeta` VALUES ("1603","363","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:811189;s:10:\"size_after\";i:811189;s:4:\"time\";d:1.1099999999999999;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:4:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:30408;s:10:\"size_after\";i:30408;s:4:\"time\";d:0.059999999999999998;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:47686;s:10:\"size_after\";i:47686;s:4:\"time\";d:0.089999999999999997;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:267342;s:10:\"size_after\";i:267342;s:4:\"time\";d:0.34999999999999998;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:465753;s:10:\"size_after\";i:465753;s:4:\"time\";d:0.60999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1604","363","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1072;s:4:\"file\";s:21:\"2018/11/jadepark2.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"jadepark2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"jadepark2-300x166.png\";s:5:\"width\";i:300;s:6:\"height\";i:166;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"jadepark2-768x424.png\";s:5:\"width\";i:768;s:6:\"height\";i:424;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"jadepark2-1024x566.png\";s:5:\"width\";i:1024;s:6:\"height\";i:566;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES ("1605","364","_wp_attached_file","2018/11/jadepark1.png");
INSERT INTO `wp_postmeta` VALUES ("1606","364","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:461642;s:10:\"size_after\";i:461642;s:4:\"time\";d:1.1600000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:4:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:20129;s:10:\"size_after\";i:20129;s:4:\"time\";d:0.029999999999999999;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:30380;s:10:\"size_after\";i:30380;s:4:\"time\";d:0.14000000000000001;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:153072;s:10:\"size_after\";i:153072;s:4:\"time\";d:0.31;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:258061;s:10:\"size_after\";i:258061;s:4:\"time\";d:0.68000000000000005;}}}");
INSERT INTO `wp_postmeta` VALUES ("1607","364","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:21:\"2018/11/jadepark1.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"jadepark1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"jadepark1-300x167.png\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"jadepark1-768x428.png\";s:5:\"width\";i:768;s:6:\"height\";i:428;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"jadepark1-1024x570.png\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES ("1608","365","_wp_attached_file","2018/11/jadepark.jpg");
INSERT INTO `wp_postmeta` VALUES ("1609","365","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:120934;s:10:\"size_after\";i:120934;s:4:\"time\";d:0.11000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:4:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:9403;s:10:\"size_after\";i:9403;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:13152;s:10:\"size_after\";i:13152;s:4:\"time\";d:0.02;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:39653;s:10:\"size_after\";i:39653;s:4:\"time\";d:0.029999999999999999;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:58726;s:10:\"size_after\";i:58726;s:4:\"time\";d:0.040000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1610","365","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:20:\"2018/11/jadepark.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"jadepark-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"jadepark-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"jadepark-768x428.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:428;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"jadepark-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES ("1611","361","_thumbnail_id","364");
INSERT INTO `wp_postmeta` VALUES ("1612","361","descatar_home","a:1:{i:0;s:2:\"si\";}");
INSERT INTO `wp_postmeta` VALUES ("1613","361","_descatar_home","field_54aec60b5808b");
INSERT INTO `wp_postmeta` VALUES ("1614","361","middle_image","");
INSERT INTO `wp_postmeta` VALUES ("1615","361","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("1616","361","subtitle_esp","Web Development");
INSERT INTO `wp_postmeta` VALUES ("1617","361","_subtitle_esp","field_54ac29a4ce78c");
INSERT INTO `wp_postmeta` VALUES ("1618","361","subtitle_eng","Web Development");
INSERT INTO `wp_postmeta` VALUES ("1619","361","_subtitle_eng","field_54ac29b6ce78d");
INSERT INTO `wp_postmeta` VALUES ("1620","361","imagen_header","365");
INSERT INTO `wp_postmeta` VALUES ("1621","361","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1622","361","_yoast_wpseo_content_score","60");
INSERT INTO `wp_postmeta` VALUES ("1623","361","_yoast_wpseo_title","JadePark %%sep%% %%sitename%%");
INSERT INTO `wp_postmeta` VALUES ("1624","94","_yoast_wpseo_content_score","60");
INSERT INTO `wp_postmeta` VALUES ("1625","366","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES ("1626","366","_menu_item_menu_item_parent","349");
INSERT INTO `wp_postmeta` VALUES ("1627","366","_menu_item_object_id","361");
INSERT INTO `wp_postmeta` VALUES ("1628","366","_menu_item_object","works");
INSERT INTO `wp_postmeta` VALUES ("1629","366","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES ("1630","366","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES ("1631","366","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES ("1632","366","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES ("1634","361","_yoast_wpseo_meta-robots-noindex","1");
INSERT INTO `wp_postmeta` VALUES ("1635","361","_yoast_wpseo_meta-robots-nofollow","1");
INSERT INTO `wp_postmeta` VALUES ("1636","367","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES ("1637","367","_edit_lock","1541687063:2");
INSERT INTO `wp_postmeta` VALUES ("1638","368","_wp_attached_file","2018/11/alcorta.jpg");
INSERT INTO `wp_postmeta` VALUES ("1639","368","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:95039;s:10:\"size_after\";i:95039;s:4:\"time\";d:0.14000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:4:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:7200;s:10:\"size_after\";i:7200;s:4:\"time\";d:0.029999999999999999;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:9319;s:10:\"size_after\";i:9319;s:4:\"time\";d:0.029999999999999999;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:31465;s:10:\"size_after\";i:31465;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:47055;s:10:\"size_after\";i:47055;s:4:\"time\";d:0.059999999999999998;}}}");
INSERT INTO `wp_postmeta` VALUES ("1640","368","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:19:\"2018/11/alcorta.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"alcorta-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"alcorta-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"alcorta-768x428.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:428;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"alcorta-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES ("1641","367","descatar_home","a:1:{i:0;s:2:\"si\";}");
INSERT INTO `wp_postmeta` VALUES ("1642","367","_descatar_home","field_54aec60b5808b");
INSERT INTO `wp_postmeta` VALUES ("1643","367","middle_image","");
INSERT INTO `wp_postmeta` VALUES ("1644","367","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("1645","367","subtitle_esp","Web Development");
INSERT INTO `wp_postmeta` VALUES ("1646","367","_subtitle_esp","field_54ac29a4ce78c");
INSERT INTO `wp_postmeta` VALUES ("1647","367","subtitle_eng","Web Development");
INSERT INTO `wp_postmeta` VALUES ("1648","367","_subtitle_eng","field_54ac29b6ce78d");
INSERT INTO `wp_postmeta` VALUES ("1649","367","imagen_header","368");
INSERT INTO `wp_postmeta` VALUES ("1650","367","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1651","367","_yoast_wpseo_content_score","60");
INSERT INTO `wp_postmeta` VALUES ("1652","367","_yoast_wpseo_meta-robots-noindex","1");
INSERT INTO `wp_postmeta` VALUES ("1653","367","_yoast_wpseo_meta-robots-nofollow","1");
INSERT INTO `wp_postmeta` VALUES ("1654","369","_wp_attached_file","2018/11/alcorta3.png");
INSERT INTO `wp_postmeta` VALUES ("1655","369","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:380732;s:10:\"size_after\";i:380732;s:4:\"time\";d:1.2600000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:4:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:18127;s:10:\"size_after\";i:18127;s:4:\"time\";d:0.12;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:27121;s:10:\"size_after\";i:27121;s:4:\"time\";d:0.14000000000000001;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:126056;s:10:\"size_after\";i:126056;s:4:\"time\";d:0.34000000000000002;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:209428;s:10:\"size_after\";i:209428;s:4:\"time\";d:0.66000000000000003;}}}");
INSERT INTO `wp_postmeta` VALUES ("1656","369","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:20:\"2018/11/alcorta3.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"alcorta3-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"alcorta3-300x167.png\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"alcorta3-768x428.png\";s:5:\"width\";i:768;s:6:\"height\";i:428;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"alcorta3-1024x570.png\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES ("1657","370","_wp_attached_file","2018/11/alcorta2.png");
INSERT INTO `wp_postmeta` VALUES ("1658","370","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:10.894954113728311;s:5:\"bytes\";i:23779;s:11:\"size_before\";i:218257;s:10:\"size_after\";i:194478;s:4:\"time\";d:1.26;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:4:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:12.289999999999999;s:5:\"bytes\";i:1064;s:11:\"size_before\";i:8657;s:10:\"size_after\";i:7593;s:4:\"time\";d:0.029999999999999999;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.8700000000000001;s:5:\"bytes\";i:958;s:11:\"size_before\";i:16323;s:10:\"size_after\";i:15365;s:4:\"time\";d:0.10000000000000001;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.07;s:5:\"bytes\";i:7972;s:11:\"size_before\";i:71996;s:10:\"size_after\";i:64024;s:4:\"time\";d:0.40999999999999998;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.369999999999999;s:5:\"bytes\";i:13785;s:11:\"size_before\";i:121281;s:10:\"size_after\";i:107496;s:4:\"time\";d:0.71999999999999997;}}}");
INSERT INTO `wp_postmeta` VALUES ("1659","370","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1072;s:4:\"file\";s:20:\"2018/11/alcorta2.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"alcorta2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"alcorta2-300x166.png\";s:5:\"width\";i:300;s:6:\"height\";i:166;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"alcorta2-768x424.png\";s:5:\"width\";i:768;s:6:\"height\";i:424;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"alcorta2-1024x566.png\";s:5:\"width\";i:1024;s:6:\"height\";i:566;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES ("1660","371","_wp_attached_file","2018/11/alcorta1.png");
INSERT INTO `wp_postmeta` VALUES ("1661","371","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:18.595161567662661;s:5:\"bytes\";i:28117;s:11:\"size_before\";i:151206;s:10:\"size_after\";i:123089;s:4:\"time\";d:0.45999999999999996;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:22.309999999999999;s:5:\"bytes\";i:1867;s:11:\"size_before\";i:8368;s:10:\"size_after\";i:6501;s:4:\"time\";d:0.02;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:19.969999999999999;s:5:\"bytes\";i:3931;s:11:\"size_before\";i:19682;s:10:\"size_after\";i:15751;s:4:\"time\";d:0.080000000000000002;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:18.120000000000001;s:5:\"bytes\";i:22319;s:11:\"size_before\";i:123156;s:10:\"size_after\";i:100837;s:4:\"time\";d:0.35999999999999999;}}}");
INSERT INTO `wp_postmeta` VALUES ("1662","371","_wp_attachment_metadata","a:5:{s:5:\"width\";i:626;s:6:\"height\";i:1268;s:4:\"file\";s:20:\"2018/11/alcorta1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"alcorta1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"alcorta1-148x300.png\";s:5:\"width\";i:148;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"alcorta1-506x1024.png\";s:5:\"width\";i:506;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES ("1663","367","_thumbnail_id","369");
INSERT INTO `wp_postmeta` VALUES ("1664","367","_yoast_wpseo_title","Alcorta Shopping %%sep%% %%sitename%%");
INSERT INTO `wp_postmeta` VALUES ("1665","55","_yoast_wpseo_content_score","60");
INSERT INTO `wp_postmeta` VALUES ("1666","373","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES ("1667","373","_menu_item_menu_item_parent","349");
INSERT INTO `wp_postmeta` VALUES ("1668","373","_menu_item_object_id","367");
INSERT INTO `wp_postmeta` VALUES ("1669","373","_menu_item_object","works");
INSERT INTO `wp_postmeta` VALUES ("1670","373","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES ("1671","373","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES ("1672","373","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES ("1673","373","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES ("1675","374","_edit_last","2");
INSERT INTO `wp_postmeta` VALUES ("1676","374","_edit_lock","1541687966:2");
INSERT INTO `wp_postmeta` VALUES ("1677","375","_wp_attached_file","2018/11/tribeca.jpg");
INSERT INTO `wp_postmeta` VALUES ("1678","375","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:105884;s:10:\"size_after\";i:105884;s:4:\"time\";d:0.19;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:4:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:4890;s:10:\"size_after\";i:4890;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:8341;s:10:\"size_after\";i:8341;s:4:\"time\";d:0.029999999999999999;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:35778;s:10:\"size_after\";i:35778;s:4:\"time\";d:0.040000000000000001;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:56875;s:10:\"size_after\";i:56875;s:4:\"time\";d:0.11;}}}");
INSERT INTO `wp_postmeta` VALUES ("1679","375","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:19:\"2018/11/tribeca.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"tribeca-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"tribeca-300x167.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"tribeca-768x428.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:428;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"tribeca-1024x570.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES ("1680","376","_wp_attached_file","2018/11/tribeca3.png");
INSERT INTO `wp_postmeta` VALUES ("1681","376","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:13.212716428120212;s:5:\"bytes\";i:37858;s:11:\"size_before\";i:286527;s:10:\"size_after\";i:248669;s:4:\"time\";d:0.73999999999999999;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:19.829999999999998;s:5:\"bytes\";i:4197;s:11:\"size_before\";i:21167;s:10:\"size_after\";i:16970;s:4:\"time\";d:0.059999999999999998;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:20.239999999999998;s:5:\"bytes\";i:6567;s:11:\"size_before\";i:32451;s:10:\"size_after\";i:25884;s:4:\"time\";d:0.059999999999999998;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:11.630000000000001;s:5:\"bytes\";i:27094;s:11:\"size_before\";i:232909;s:10:\"size_after\";i:205815;s:4:\"time\";d:0.62;}}}");
INSERT INTO `wp_postmeta` VALUES ("1682","376","_wp_attachment_metadata","a:5:{s:5:\"width\";i:626;s:6:\"height\";i:1268;s:4:\"file\";s:20:\"2018/11/tribeca3.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"tribeca3-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"tribeca3-148x300.png\";s:5:\"width\";i:148;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"tribeca3-506x1024.png\";s:5:\"width\";i:506;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES ("1683","377","_wp_attached_file","2018/11/tribeca2.png");
INSERT INTO `wp_postmeta` VALUES ("1684","377","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:309177;s:10:\"size_after\";i:309177;s:4:\"time\";d:1.2200000000000002;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:4:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:15403;s:10:\"size_after\";i:15403;s:4:\"time\";d:0.059999999999999998;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:22986;s:10:\"size_after\";i:22986;s:4:\"time\";d:0.12;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:102959;s:10:\"size_after\";i:102959;s:4:\"time\";d:0.40000000000000002;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:167829;s:10:\"size_after\";i:167829;s:4:\"time\";d:0.64000000000000001;}}}");
INSERT INTO `wp_postmeta` VALUES ("1685","377","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1080;s:4:\"file\";s:20:\"2018/11/tribeca2.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"tribeca2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"tribeca2-300x167.png\";s:5:\"width\";i:300;s:6:\"height\";i:167;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"tribeca2-768x428.png\";s:5:\"width\";i:768;s:6:\"height\";i:428;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"tribeca2-1024x570.png\";s:5:\"width\";i:1024;s:6:\"height\";i:570;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES ("1686","378","_wp_attached_file","2018/11/tribeca1.png");
INSERT INTO `wp_postmeta` VALUES ("1687","378","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:428750;s:10:\"size_after\";i:428750;s:4:\"time\";d:1.1500000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:4:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:19453;s:10:\"size_after\";i:19453;s:4:\"time\";d:0.080000000000000002;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:27848;s:10:\"size_after\";i:27848;s:4:\"time\";d:0.070000000000000007;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:141971;s:10:\"size_after\";i:141971;s:4:\"time\";d:0.32000000000000001;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:239478;s:10:\"size_after\";i:239478;s:4:\"time\";d:0.68000000000000005;}}}");
INSERT INTO `wp_postmeta` VALUES ("1688","378","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:1072;s:4:\"file\";s:20:\"2018/11/tribeca1.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"tribeca1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"tribeca1-300x166.png\";s:5:\"width\";i:300;s:6:\"height\";i:166;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"tribeca1-768x424.png\";s:5:\"width\";i:768;s:6:\"height\";i:424;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"tribeca1-1024x566.png\";s:5:\"width\";i:1024;s:6:\"height\";i:566;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES ("1689","374","_thumbnail_id","377");
INSERT INTO `wp_postmeta` VALUES ("1690","374","descatar_home","a:1:{i:0;s:2:\"si\";}");
INSERT INTO `wp_postmeta` VALUES ("1691","374","_descatar_home","field_54aec60b5808b");
INSERT INTO `wp_postmeta` VALUES ("1692","374","middle_image","");
INSERT INTO `wp_postmeta` VALUES ("1693","374","_middle_image","field_54ac3ffdec05f");
INSERT INTO `wp_postmeta` VALUES ("1694","374","subtitle_esp","Web Development");
INSERT INTO `wp_postmeta` VALUES ("1695","374","_subtitle_esp","field_54ac29a4ce78c");
INSERT INTO `wp_postmeta` VALUES ("1696","374","subtitle_eng","Web Development");
INSERT INTO `wp_postmeta` VALUES ("1697","374","_subtitle_eng","field_54ac29b6ce78d");
INSERT INTO `wp_postmeta` VALUES ("1698","374","imagen_header","375");
INSERT INTO `wp_postmeta` VALUES ("1699","374","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1700","374","_yoast_wpseo_content_score","60");
INSERT INTO `wp_postmeta` VALUES ("1701","374","_yoast_wpseo_meta-robots-noindex","1");
INSERT INTO `wp_postmeta` VALUES ("1702","374","_yoast_wpseo_meta-robots-nofollow","1");
INSERT INTO `wp_postmeta` VALUES ("1703","52","_yoast_wpseo_content_score","60");
INSERT INTO `wp_postmeta` VALUES ("1704","379","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES ("1705","379","_menu_item_menu_item_parent","349");
INSERT INTO `wp_postmeta` VALUES ("1706","379","_menu_item_object_id","374");
INSERT INTO `wp_postmeta` VALUES ("1707","379","_menu_item_object","works");
INSERT INTO `wp_postmeta` VALUES ("1708","379","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES ("1709","379","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES ("1710","379","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES ("1711","379","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES ("1713","374","_yoast_wpseo_title","Tribeca Lofts %%sep%% %%sitename%%");
INSERT INTO `wp_postmeta` VALUES ("1714","380","_wp_attached_file","2018/11/CT000_1.jpg");
INSERT INTO `wp_postmeta` VALUES ("1715","380","wp-smpro-smush-data","a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:59244;s:10:\"size_after\";i:59244;s:4:\"time\";d:0.11000000000000001;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";b:1;}s:5:\"sizes\";a:4:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:6715;s:10:\"size_after\";i:6715;s:4:\"time\";d:0.01;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:8057;s:10:\"size_after\";i:8057;s:4:\"time\";d:0.01;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:18442;s:10:\"size_after\";i:18442;s:4:\"time\";d:0.02;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:26030;s:10:\"size_after\";i:26030;s:4:\"time\";d:0.070000000000000007;}}}");
INSERT INTO `wp_postmeta` VALUES ("1716","380","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1940;s:6:\"height\";i:807;s:4:\"file\";s:19:\"2018/11/CT000_1.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"CT000_1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"CT000_1-300x125.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:125;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"CT000_1-768x319.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:319;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"CT000_1-1024x426.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:426;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES ("1717","381","imagen_header","380");
INSERT INTO `wp_postmeta` VALUES ("1718","381","_imagen_header","field_54aedcf0bf3de");
INSERT INTO `wp_postmeta` VALUES ("1719","381","middle_image","263");
INSERT INTO `wp_postmeta` VALUES ("1720","381","_middle_image","field_54ac3ffdec05f");


CREATE TABLE IF NOT EXISTS `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `post_name` (`post_name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=382 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_posts` VALUES ("5","2","2014-11-19 18:38:54","2014-11-19 18:38:54","<!--:en--><h2>Digital &amp; Graphic Agency
based in Buenos Aires, Argentina.</h2><!--:--><!--:es--><h2>Agencia Digital &amp; Gráfica
establecida en Buenos Aires, Argentina.</h2><!--:-->","Home","","publish","closed","closed","","home","","","2015-03-16 12:27:33","2015-03-16 12:27:33","","0","https://www.wearedandy.com/?page_id=5","5","page","","0");
INSERT INTO `wp_posts` VALUES ("6","2","2014-11-19 18:38:54","2014-11-19 18:38:54","","Home","","inherit","closed","closed","","5-revision-v1","","","2014-11-19 18:38:54","2014-11-19 18:38:54","","5","https://www.wearedandy.com/5-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("16","2","2014-12-17 16:02:22","2014-12-17 16:02:22","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandy_agency_br_eng.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–résumé [pdf format, 8.7Mb]</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.facebook.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandy_agency_br_esp.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–resumen [formato pdf, 8.7Mb]</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.facebook.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","publish","closed","closed","","about-us","","","2018-10-08 15:51:19","2018-10-08 15:51:19","","0","https://www.wearedandy.com/?page_id=16","4","page","","0");
INSERT INTO `wp_posts` VALUES ("17","2","2014-12-17 16:02:22","2014-12-17 16:02:22","","About us","","inherit","closed","closed","","16-revision-v1","","","2014-12-17 16:02:22","2014-12-17 16:02:22","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("18","2","2014-12-17 17:38:05","2014-12-17 17:38:05"," ","","","publish","closed","closed","","18","","","2018-11-08 14:40:25","2018-11-08 14:40:25","","0","https://www.wearedandy.com/?p=18","1","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES ("19","2","2014-12-17 17:38:05","2014-12-17 17:38:05","","About Us","","publish","closed","closed","","19","","","2018-11-08 14:40:26","2018-11-08 14:40:26","","0","https://www.wearedandy.com/?p=19","14","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES ("22","2","2015-01-06 17:00:53","2015-01-06 17:00:53","<!--:en--><span style=\"font-size: 22px;\">Simplicity</span>
[raw]<br class=\"spacer\" />[/raw]
Al Khail Heights is Dubai\'s Exciting 
New Residential Neighbourhood.
We program and design for this real estate development.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.alkhailheights.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">alkhailheights.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"AK_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-86\" alt=\"AK_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_002.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-89\" alt=\"AK_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_006.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-86\" alt=\"AK_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_010.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-87\" alt=\"AK_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_004.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-90\" alt=\"AK_006\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_005.jpg\" width=\"1440\" height=\"900\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Simplicity</span>
[raw]<br class=\"spacer\" />[/raw]
Al Khail Heights es el Nuevo y Emocionante
Barrio Residencial de Dubai.
Programamos y diseñamos el nuevo website.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.alkhailheights.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">alkhailheights.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"AK_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-86\" alt=\"AK_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_002.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-89\" alt=\"AK_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_006.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-86\" alt=\"AK_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_010.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-87\" alt=\"AK_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_004.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-90\" alt=\"AK_006\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_005.jpg\" width=\"1440\" height=\"900\" /><!--:-->","<!--:en-->Al Khail Heights<!--:--><!--:es-->Al Khail Heights<!--:-->","","publish","closed","closed","","alkhailheights","","","2015-03-06 18:58:58","2015-03-06 18:58:58","","0","https://www.wearedandy.com/?post_type=works&#038;p=22","17","works","","0");
INSERT INTO `wp_posts` VALUES ("24","2","2015-01-06 18:30:49","2015-01-06 18:30:49","","Subtitle","","publish","closed","closed","","acf_subtitle","","","2015-01-06 18:30:49","2015-01-06 18:30:49","","0","https://www.wearedandy.com/?post_type=acf&#038;p=24","1","acf","","0");
INSERT INTO `wp_posts` VALUES ("25","2","2015-01-06 19:42:11","2015-01-06 19:42:11","<!--:en--><span style=\"font-size: 22px;\">Simplicity</span>
[raw]<br class=\"spacer\" />[/raw]
Texture is a UAE-based real estate group,
offering premium Development, Investment and Brokerage services.
We develop the corporate website.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.texture.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">texture.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"TX_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/TX_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-86\" alt=\"TX_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/TX_002.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-89\" alt=\"TX_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/TX_003.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-87\" alt=\"TX_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/TX_004.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-90\" alt=\"TX_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/TX_005.jpg\" width=\"1440\" height=\"900\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Simplicity</span>
[raw]<br class=\"spacer\" />[/raw]
Texture Holding es un grupo inmobiliario
con sede en los Emiratos Árabes Unidos, ofreciendo desarrollos,
inversiones y servicios de broker. Desarrollamos la web corporativa.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.texture.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">texture.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"TX_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/TX_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-86\" alt=\"TX_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/TX_002.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-89\" alt=\"TX_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/TX_003.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-87\" alt=\"TX_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/TX_004.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-90\" alt=\"TX_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/TX_005.jpg\" width=\"1440\" height=\"900\" /><!--:-->","<!--:en-->Texture Holding<!--:--><!--:es-->Texture Holding<!--:-->","","publish","closed","closed","","texture","","","2018-11-07 14:01:41","2018-11-07 14:01:41","","0","https://www.wearedandy.com/?post_type=works&#038;p=25","8","works","","0");
INSERT INTO `wp_posts` VALUES ("30","2","2015-01-06 19:52:52","2015-01-06 19:52:52","","royal-feat","","inherit","closed","closed","","royal-feat","","","2015-01-06 19:52:52","2015-01-06 19:52:52","","0","https://www.wearedandy.com/wp-content/uploads/2015/01/royal-feat.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES ("31","2","2015-01-06 20:05:49","2015-01-06 20:05:49","","Parallax Image","","publish","closed","closed","","acf_parallax-image","","","2015-01-19 21:32:41","2015-01-19 21:32:41","","0","https://www.wearedandy.com/?post_type=acf&#038;p=31","1","acf","","0");
INSERT INTO `wp_posts` VALUES ("33","2","2015-01-06 20:06:54","2015-01-06 20:06:54","","Home","","inherit","closed","closed","","5-revision-v1","","","2015-01-06 20:06:54","2015-01-06 20:06:54","","5","https://www.wearedandy.com/5-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("34","2","2015-01-06 20:08:00","2015-01-06 20:08:00","","Home","","inherit","closed","closed","","5-revision-v1","","","2015-01-06 20:08:00","2015-01-06 20:08:00","","5","https://www.wearedandy.com/5-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("35","2","2015-01-07 20:10:11","2015-01-07 20:10:11","","<!--:en-->Works<!--:--><!--:es-->Trabajos<!--:-->","","draft","closed","closed","","works","","","2018-09-26 19:02:21","2018-09-26 19:02:21","","0","https://www.wearedandy.com/?page_id=35","3","page","","0");
INSERT INTO `wp_posts` VALUES ("36","2","2015-01-07 20:10:11","2015-01-07 20:10:11","","<!--:en-->Works<!--:--><!--:es-->Works<!--:-->","","inherit","closed","closed","","35-revision-v1","","","2015-01-07 20:10:11","2015-01-07 20:10:11","","35","https://www.wearedandy.com/35-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("38","2","2015-01-07 20:10:39","2015-01-07 20:10:39","","<!--:en-->About us<!--:--><!--:es-->Sobre nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-01-07 20:10:39","2015-01-07 20:10:39","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("39","2","2015-01-07 20:10:51","2015-01-07 20:10:51","","<!--:en-->Works<!--:--><!--:es-->Trabajos<!--:-->","","inherit","closed","closed","","35-revision-v1","","","2015-01-07 20:10:51","2015-01-07 20:10:51","","35","https://www.wearedandy.com/35-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("40","2","2015-01-07 20:11:20","2015-01-07 20:11:20","","<!--:en-->Clients<!--:--><!--:es-->Clientes<!--:-->","","draft","closed","closed","","clients","","","2018-09-26 18:42:32","2018-09-26 18:42:32","","0","https://www.wearedandy.com/?page_id=40","2","page","","0");
INSERT INTO `wp_posts` VALUES ("41","2","2015-01-07 20:11:20","2015-01-07 20:11:20","","<!--:en-->Clients<!--:--><!--:es-->Clientes<!--:-->","","inherit","closed","closed","","40-revision-v1","","","2015-01-07 20:11:20","2015-01-07 20:11:20","","40","https://www.wearedandy.com/40-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("42","2","2015-01-07 20:11:32","2015-01-07 20:11:32","<!--:en--><span style=\"font-size: 14px;\">Thank you for your interest in our work.</span>
<span style=\"font-size: 14px;\"> Please fill out the form below.</span>
<span style=\"font-size: 14px;\"> We will contact you soon.</span><!--:--><!--:es--><span style=\"font-size: 14px;\"> Gracias por su interés en nuestro trabajo.</span>
<span style=\"font-size: 14px;\"> Por favor, complete el siguiente formulario.</span>
<span style=\"font-size: 14px;\"> Nos pondremos en contacto con usted pronto.</span><!--:-->","<!--:en-->Contact<!--:--><!--:es-->Contacto<!--:-->","","publish","closed","closed","","contact","","","2018-11-08 14:46:04","2018-11-08 14:46:04","","0","https://www.wearedandy.com/?page_id=42","1","page","","0");
INSERT INTO `wp_posts` VALUES ("43","2","2015-01-07 20:11:32","2015-01-07 20:11:32","","<!--:en-->Contact<!--:--><!--:es-->Contacto<!--:-->","","inherit","closed","closed","","42-revision-v1","","","2015-01-07 20:11:32","2015-01-07 20:11:32","","42","https://www.wearedandy.com/42-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("44","2","2015-01-07 20:12:43","2015-01-07 20:12:43","","Contact","","publish","closed","closed","","44","","","2018-11-08 14:40:26","2018-11-08 14:40:26","","0","https://www.wearedandy.com/?p=44","15","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES ("46","2","2015-01-07 20:12:43","2015-01-07 20:12:43","","Al Khail Heights","","publish","closed","closed","","46","","","2018-11-08 14:40:25","2018-11-08 14:40:25","","0","https://www.wearedandy.com/?p=46","4","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES ("47","2","2015-01-07 20:12:43","2015-01-07 20:12:43","","Texture Holding","","publish","closed","closed","","47","","","2018-11-08 14:40:25","2018-11-08 14:40:25","","0","https://www.wearedandy.com/?p=47","11","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES ("49","2","2015-01-07 20:54:09","2015-01-07 20:54:09","","<!--:en-->About Us<!--:--><!--:es-->Sobre nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-01-07 20:54:09","2015-01-07 20:54:09","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("50","2","2015-01-08 18:02:17","2015-01-08 18:02:17","","Destacar en la Home","","publish","closed","closed","","acf_destacar-en-la-home","","","2015-01-08 18:02:17","2015-01-08 18:02:17","","0","https://www.wearedandy.com/?post_type=acf&#038;p=50","1","acf","","0");
INSERT INTO `wp_posts` VALUES ("51","2","2015-01-08 18:14:17","2015-01-08 18:14:17","<!--:en--><span style=\"font-size: 22px;\">Sophisticated</span>
[raw]<br class=\"spacer\" />[/raw]
Zaya is a boutique real estate & hospitality development. 
We could be part of this development
doing all the programming and responsiveness.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.zayanuraiisland.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">zayanuraiisland.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"ZN_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/ZN_002.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"ZN_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/ZN_003.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"ZN_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/ZN_001.jpg\" width=\"1440\" height=\"900\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Sofisticado</span>
[raw]<br class=\"spacer\" />[/raw]
Zaya es un desarrollo boutique inmobiliario.
Pudimos ser parte de este desarrollo
haciendo toda la programación y adaptibilidad.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.zayanuraiisland.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">zayanuraiisland.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"ZN_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/ZN_002.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"ZN_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/ZN_003.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"ZN_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/ZN_001.jpg\" width=\"1440\" height=\"900\" /><!--:-->","<!--:en-->Zaya Nurai Island<!--:--><!--:es-->Zaya Nurai Island<!--:-->","","draft","closed","closed","","zaya","","","2018-11-07 13:58:48","2018-11-07 13:58:48","","0","https://www.wearedandy.com/?post_type=works&#038;p=51","6","works","","0");
INSERT INTO `wp_posts` VALUES ("52","2","2015-01-08 18:15:02","2015-01-08 18:15:02","<!--:en--><span style=\"font-size: 22px;\">Straightforward</span>
[raw]<br class=\"spacer\" />[/raw]
Pal is a Real Estate and Investment company in Dubai.
We were able to set new standards for programming,
animation and design on this project.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.pal.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">pal.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"PL_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/PL_001.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"PL_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/PL_005.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"PL_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/PL_002.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"PL_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/PL_003.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"PL_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/PL_004.jpg\" width=\"1440\" height=\"900\"/><!--:--><!--:es--><span style=\"font-size: 22px;\">Sencillo</span>
[raw]<br class=\"spacer\" />[/raw]
Pal es una empresa inmobiliaria y de inversión en Dubai.
Pudimos establecer nuevos estándares de programación,
animación y diseño en la realización de este proyecto.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.pal.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">pal.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"PL_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/PL_001.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"PL_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/PL_005.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"PL_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/PL_002.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"PL_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/PL_003.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"PL_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/PL_004.jpg\" width=\"1440\" height=\"900\"/><!--:-->","<!--:en-->Pal<!--:--><!--:es-->Pal<!--:-->","","publish","closed","closed","","pal","","","2018-11-08 14:39:20","2018-11-08 14:39:20","","0","https://www.wearedandy.com/?post_type=works&#038;p=52","12","works","","0");
INSERT INTO `wp_posts` VALUES ("53","2","2015-01-08 19:39:59","2015-01-08 19:39:59","","Imagen Header","","publish","closed","closed","","acf_imagen-header","","","2015-01-19 19:18:46","2015-01-19 19:18:46","","0","https://www.wearedandy.com/?post_type=acf&#038;p=53","2","acf","","0");
INSERT INTO `wp_posts` VALUES ("55","2","2015-01-08 22:03:11","2015-01-08 22:03:11","<!--:en--><span style=\"font-size: 22px;\">Responsiveness</span>
[raw]<br class=\"spacer\" />[/raw]
Native Trees, a business dedicated to the planting
and maintenance of trees and palms.
We design and program the actual website responsive.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.nativetrees.com.ar\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">nativetrees.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"NT_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/NT_006.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-88\" alt=\"NT_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/NT_003.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"NT_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/NT_004.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"NT_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/NT_005.jpg\" width=\"1440\" height=\"900\" />

<!--:--><!--:es--><span style=\"font-size: 22px;\">Sensibilidad</span>
[raw]<br class=\"spacer\" />[/raw]
Native Trees, negocio dedicado a la plantación
y mantenimiento de árboles y palmeras.
Diseñamos y programamos el sitio actual responsive.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.andreaanzorena.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">andreaanzorena.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"NT_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/NT_006.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-88\" alt=\"NT_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/NT_003.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"NT_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/NT_004.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"NT_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/NT_005.jpg\" width=\"1440\" height=\"900\" />
<!--:-->","<!--:en-->Native Trees<!--:--><!--:es-->Native Trees<!--:-->","","publish","closed","closed","","nativetrees","","","2018-11-08 13:53:43","2018-11-08 13:53:43","","0","https://www.wearedandy.com/?post_type=works&#038;p=55","13","works","","0");
INSERT INTO `wp_posts` VALUES ("56","2","2015-03-03 19:40:50","2015-03-03 19:40:50","<!--:en--><span style=\"font-size: 22px;\">Simplicity</span>
[raw]<br class=\"spacer\" />[/raw]
Al Khail Heights is Dubai\'s Exciting 
New Residential Neighbourhood.
Services of brand identity and programming are on this project.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.alkhailheights.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">alkhailheights.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"AK_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_001.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-86\" alt=\"AK_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_002.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-89\" alt=\"AK_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_006.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-87\" alt=\"AK_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_004.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-90\" alt=\"AK_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_005.jpg\" width=\"1440\" height=\"900\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Simplicity</span>
[raw]<br class=\"spacer\" />[/raw]
Al Khail Heights es el Nuevo y Emocionante
Barrio Residencial de Dubai.
Services of brand identity and programming are on this project.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.alkhailheights.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">alkhailheights.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"AK_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_001.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-86\" alt=\"AK_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_002.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-89\" alt=\"AK_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_006.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-87\" alt=\"AK_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_004.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-90\" alt=\"AK_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_005.jpg\" width=\"1440\" height=\"900\" /><!--:-->","<!--:en-->Al Khail Heights<!--:--><!--:es-->Al Khail Heights<!--:-->","","inherit","closed","closed","","22-autosave-v1","","","2015-03-03 19:40:50","2015-03-03 19:40:50","","22","https://www.wearedandy.com/22-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("60","2","2015-01-15 17:30:48","2015-01-15 17:30:48","<!--:en-->Digital &amp; Graphic Agency
based in Buenos Aires, Argentina.<!--:-->","Home","","inherit","closed","closed","","5-revision-v1","","","2015-01-15 17:30:48","2015-01-15 17:30:48","","5","https://www.wearedandy.com/5-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("64","2","2015-01-16 19:53:36","2015-01-16 19:53:36","<!--:en--><h2>Digital &amp; Graphic Agency
based in Buenos Aires, Argentina.</h2><!--:-->","Home","","inherit","closed","closed","","5-revision-v1","","","2015-01-16 19:53:36","2015-01-16 19:53:36","","5","https://www.wearedandy.com/5-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("66","2","2015-01-16 20:52:57","2015-01-16 20:52:57","","<!--:en-->About Us<!--:--><!--:es-->Sobre nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-01-16 20:52:57","2015-01-16 20:52:57","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("67","2","2015-04-21 14:34:22","2015-04-21 14:34:22","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandyagency_resume.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–résumé</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandyagency_resume.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–résumé</span></a></span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-autosave-v1","","","2015-04-21 14:34:22","2015-04-21 14:34:22","","16","https://www.wearedandy.com/16-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("68","2","2015-01-16 20:57:09","2015-01-16 20:57:09","<!--:en-->Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco
laboris nisi ut aliquip ex ea commodo consequat.<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-01-16 20:57:09","2015-01-16 20:57:09","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("69","2","2015-01-16 21:01:09","2015-01-16 21:01:09","<!--:en-->Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco
laboris nisi ut aliquip ex ea commodo consequat.<!--:--><!--:es-->Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco
laboris nisi ut aliquip ex ea commodo consequat.<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-01-16 21:01:09","2015-01-16 21:01:09","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("71","2","2015-01-19 16:12:18","2015-01-19 16:12:18","<!--:en-->Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco
laboris nisi ut aliquip ex ea commodo consequat.<!--:--><!--:es-->Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco
laboris nisi ut aliquip ex ea commodo consequat.<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-01-19 16:12:18","2015-01-19 16:12:18","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("72","2","2015-01-19 16:20:31","2015-01-19 16:20:31","","diego","","inherit","closed","closed","","diego","","","2015-01-19 16:20:31","2015-01-19 16:20:31","","16","https://www.wearedandy.com/wp-content/uploads/2014/12/diego.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("74","2","2015-01-19 16:20:37","2015-01-19 16:20:37","<!--:en-->Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco
laboris nisi ut aliquip ex ea commodo consequat.<!--:--><!--:es-->Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco
laboris nisi ut aliquip ex ea commodo consequat.<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-01-19 16:20:37","2015-01-19 16:20:37","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("75","2","2015-01-19 17:51:38","2015-01-19 17:51:38","<!--:en-->Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco
laboris nisi ut aliquip ex ea commodo consequat.<!--:--><!--:es-->Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco
laboris nisi ut aliquip ex ea commodo consequat.<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-01-19 17:51:38","2015-01-19 17:51:38","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("76","2","2015-01-19 17:54:07","2015-01-19 17:54:07","","guille","","inherit","closed","closed","","guille","","","2015-01-19 17:54:07","2015-01-19 17:54:07","","16","https://www.wearedandy.com/wp-content/uploads/2014/12/guille.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("77","2","2015-01-19 17:54:14","2015-01-19 17:54:14","<!--:en-->Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco
laboris nisi ut aliquip ex ea commodo consequat.<!--:--><!--:es-->Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco
laboris nisi ut aliquip ex ea commodo consequat.<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-01-19 17:54:14","2015-01-19 17:54:14","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("79","2","2015-01-19 19:20:02","2015-01-19 19:20:02","","<!--:en-->Contact<!--:--><!--:es-->Contacto<!--:-->","","inherit","closed","closed","","42-revision-v1","","","2015-01-19 19:20:02","2015-01-19 19:20:02","","42","https://www.wearedandy.com/42-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("80","2","2015-01-19 19:33:03","2015-01-19 19:33:03","<!--:en-->Thank you for your interest in our work.
Please fill out the form below.
We will contact you soon.<!--:-->","<!--:en-->Contact<!--:--><!--:es-->Contacto<!--:-->","","inherit","closed","closed","","42-revision-v1","","","2015-01-19 19:33:03","2015-01-19 19:33:03","","42","https://www.wearedandy.com/42-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("81","2","2015-01-19 19:33:33","2015-01-19 19:33:33","<!--:en--><span style=\"font-size: 14px;\">Thank you for your interest in our work.</span>
<span style=\"font-size: 14px;\"> Please fill out the form below.</span>
<span style=\"font-size: 14px;\"> We will contact you soon.</span><!--:-->","<!--:en-->Contact<!--:--><!--:es-->Contacto<!--:-->","","inherit","closed","closed","","42-revision-v1","","","2015-01-19 19:33:33","2015-01-19 19:33:33","","42","https://www.wearedandy.com/42-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("83","2","2015-01-19 21:33:58","2015-01-19 21:33:58","<!--:en--><span style=\"font-size: 14px;\">Thank you for your interest in our work.</span>
<span style=\"font-size: 14px;\"> Please fill out the form below.</span>
<span style=\"font-size: 14px;\"> We will contact you soon.</span><!--:-->","<!--:en-->Contact<!--:--><!--:es-->Contacto<!--:-->","","inherit","closed","closed","","42-revision-v1","","","2015-01-19 21:33:58","2015-01-19 21:33:58","","42","https://www.wearedandy.com/42-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("92","2","2015-03-03 17:58:10","2015-03-03 17:58:10","<!--:en--><span style=\"font-size: 22px;\">Food & Style Development</span>
[raw]<br class=\"spacer\" />[/raw]
Provedore is Lifestyle and Gourmet.
We develop the programming of the website
for this store, restaurant and marketplace.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.provedore.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">provedore.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"PR_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/PR_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"PR_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/PR_002.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"PR_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/PR_003.jpg\" width=\"1440\" height=\"900\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Desarrollo de Estilo & Gourmet</span>
[raw]<br class=\"spacer\" />[/raw]
Provedore es Estilo de Vida y Gourmet.
Desarrollamos la programación del sitio web
para esta tienda, restaurant y mercado.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.provedore.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">provedore.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"PR_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/PR_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"PR_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/PR_002.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"PR_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/PR_003.jpg\" width=\"1440\" height=\"900\" /><!--:-->","Provedore","","draft","closed","closed","","provedore","","","2018-11-07 13:58:27","2018-11-07 13:58:27","","0","https://www.wearedandy.com/?post_type=works&#038;p=92","9","works","","0");
INSERT INTO `wp_posts` VALUES ("94","2","2015-03-03 11:08:04","2015-03-03 11:08:04","<!--:en--><span style=\"font-size: 22px;\">Branding & Digital</span>
[raw]<br class=\"spacer\" />[/raw]
We create the website of the artist and sculptor
Andrea Anzorena, where we develop branding,
design and digital programming.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.andreaanzorena.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">andreaanzorena.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"AA_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/AA_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"AA_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/AA_000.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"AA_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/AA_004.jpg\" width=\"1440\" height=\"900\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Branding & Digital</span>
[raw]<br class=\"spacer\" />[/raw]
Creamos el sitio web de la artista y esculptora
Andrea Anzorena, donde desarrollamos branding,
diseño y programación.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.andreaanzorena.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">andreaanzorena.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"AA_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/AA_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"AA_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/AA_002.jpg\" width=\"1440\" height=\"900\" /><!--:-->","<!--:en-->Andrea Anzorena<!--:--><!--:es-->Andrea Anzorena<!--:-->","","publish","closed","closed","","andreaanzorena","","","2018-11-07 14:55:03","2018-11-07 14:55:03","","0","https://www.wearedandy.com/?post_type=works&#038;p=94","16","works","","0");
INSERT INTO `wp_posts` VALUES ("95","2","2015-03-06 17:00:27","2015-03-06 17:00:27","<!--:en--><span style=\"font-size: 22px;\">Branding & Digital</span>
[raw]<br class=\"spacer\" />[/raw]
We create the website of the artist and sculptor
Andrea Anzorena, where we develop branding,
design and digital programming.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.andreaanzorena.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">andreaanzorena.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"AA_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/AA_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"AA_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/AA_000.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"AA_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/AA_002.jpg\" width=\"1440\" height=\"900\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Branding & Digital</span>
[raw]<br class=\"spacer\" />[/raw]
Creamos el sitio web de la artista y esculptora
Andrea Anzorena, donde desarrollamos branding,
diseño y programación.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.andreaanzorena.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">andreaanzorena.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"AA_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/AA_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"AA_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/AA_002.jpg\" width=\"1440\" height=\"900\" /><!--:-->","<!--:en-->Andrea Anzorena<!--:--><!--:es-->Andrea Anzorena<!--:-->","","inherit","closed","closed","","94-autosave-v1","","","2015-03-06 17:00:27","2015-03-06 17:00:27","","94","https://www.wearedandy.com/94-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("97","2","2015-03-03 11:22:36","2015-03-03 11:22:36","","AA_002","","inherit","closed","closed","","aa_002-2","","","2015-03-03 11:22:36","2015-03-03 11:22:36","","94","https://www.wearedandy.com/wp-content/uploads/2015/03/AA_0021.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("98","2","2015-03-03 11:28:17","2015-03-03 11:28:17","","AA_header","","inherit","closed","closed","","aa_header","","","2015-03-03 11:28:17","2015-03-03 11:28:17","","94","https://www.wearedandy.com/wp-content/uploads/2015/03/AA_header.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("105","2","2015-03-03 13:53:50","2015-03-03 13:53:50","","AA_002","","inherit","closed","closed","","aa_002","","","2015-03-03 13:53:50","2015-03-03 13:53:50","","94","https://www.wearedandy.com/wp-content/uploads/2015/03/AA_002.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("107","2","2015-03-03 14:35:05","2015-03-03 14:35:05","","AA_001","","inherit","closed","closed","","aa_001","","","2015-03-03 14:35:05","2015-03-03 14:35:05","","94","https://www.wearedandy.com/wp-content/uploads/2015/03/AA_001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("110","2","2015-03-03 14:45:11","2015-03-03 14:45:11","","Andrea Anzorena","","publish","closed","closed","","110","","","2018-11-08 14:40:25","2018-11-08 14:40:25","","0","https://www.wearedandy.com/?p=110","5","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES ("111","2","2015-03-09 15:39:38","2015-03-09 15:39:38","<!--:en--><span style=\"font-size: 22px;\">Responsiveness</span>
[raw]<br class=\"spacer\" />[/raw]
Native Trees, a business dedicated to the planting
and maintenance of trees and palms.
We design and program the actual website responsive.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.nativetrees.com.ar\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">nativetrees.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"NT_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/NT_006.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-88\" alt=\"NT_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/NT_003.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"NT_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/NT_004.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"NT_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/NT_005.jpg\" width=\"1440\" height=\"900\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Sensibilidad</span>
[raw]<br class=\"spacer\" />[/raw]
Native Trees, negocio dedicado a la plantación
y mantenimiento de árboles y palmeras.
Diseñamos y programamos el sitio actual responsive.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.andreaanzorena.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">andreaanzorena.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"NT_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/NT_006.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-88\" alt=\"NT_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/NT_003.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"NT_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/NT_004.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"NT_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/NT_005.jpg\" width=\"1440\" height=\"900\" />
<!--:-->","<!--:en-->Native Trees<!--:--><!--:es-->Native Trees<!--:-->","","inherit","closed","closed","","55-autosave-v1","","","2015-03-09 15:39:38","2015-03-09 15:39:38","","55","https://www.wearedandy.com/55-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("112","2","2015-03-03 15:46:43","2015-03-03 15:46:43","","NT_002","","inherit","closed","closed","","nt_002","","","2015-03-03 15:46:43","2015-03-03 15:46:43","","55","https://www.wearedandy.com/wp-content/uploads/2015/01/NT_002.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("113","2","2015-03-03 15:47:20","2015-03-03 15:47:20","","NT_001","","inherit","closed","closed","","nt_001","","","2015-03-03 15:47:20","2015-03-03 15:47:20","","55","https://www.wearedandy.com/wp-content/uploads/2015/01/NT_001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("114","2","2015-03-03 15:47:57","2015-03-03 15:47:57","","NT_006","","inherit","closed","closed","","nt_006","","","2015-03-03 15:47:57","2015-03-03 15:47:57","","55","https://www.wearedandy.com/wp-content/uploads/2015/01/NT_006.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("115","2","2015-03-03 15:48:17","2015-03-03 15:48:17","","NT_005","","inherit","closed","closed","","nt_005","","","2015-03-03 15:48:17","2015-03-03 15:48:17","","55","https://www.wearedandy.com/wp-content/uploads/2015/01/NT_005.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("116","2","2015-03-03 15:48:24","2015-03-03 15:48:24","","NT_004","","inherit","closed","closed","","nt_004","","","2015-03-03 15:48:24","2015-03-03 15:48:24","","55","https://www.wearedandy.com/wp-content/uploads/2015/01/NT_004.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("117","2","2015-03-03 15:48:30","2015-03-03 15:48:30","","NT_003","","inherit","closed","closed","","nt_003","","","2015-03-03 15:48:30","2015-03-03 15:48:30","","55","https://www.wearedandy.com/wp-content/uploads/2015/01/NT_003.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("118","2","2015-03-03 16:34:48","2015-03-03 16:34:48","","Native Trees","","publish","closed","closed","","118","","","2018-11-08 14:40:25","2018-11-08 14:40:25","","0","https://www.wearedandy.com/?p=118","8","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES ("125","2","2015-03-03 17:59:29","2015-03-03 17:59:29","","PR_001","","inherit","closed","closed","","pr_001","","","2015-03-03 17:59:29","2015-03-03 17:59:29","","92","https://www.wearedandy.com/wp-content/uploads/2015/03/PR_001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("126","2","2015-03-03 17:59:35","2015-03-03 17:59:35","","PR_002","","inherit","closed","closed","","pr_002","","","2015-03-03 17:59:35","2015-03-03 17:59:35","","92","https://www.wearedandy.com/wp-content/uploads/2015/03/PR_002.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("127","2","2015-03-03 17:59:40","2015-03-03 17:59:40","","PR_003","","inherit","closed","closed","","pr_003","","","2015-03-03 17:59:40","2015-03-03 17:59:40","","92","https://www.wearedandy.com/wp-content/uploads/2015/03/PR_003.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("128","2","2015-03-03 17:59:46","2015-03-03 17:59:46","","PR_004","","inherit","closed","closed","","pr_004","","","2015-03-03 17:59:46","2015-03-03 17:59:46","","92","https://www.wearedandy.com/wp-content/uploads/2015/03/PR_004.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("129","2","2015-03-03 17:59:52","2015-03-03 17:59:52","","PR_005","","inherit","closed","closed","","pr_005","","","2015-03-03 17:59:52","2015-03-03 17:59:52","","92","https://www.wearedandy.com/wp-content/uploads/2015/03/PR_005.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("130","2","2015-03-03 18:14:29","2015-03-03 18:14:29","<!--:en--><span style=\"font-size: 22px;\">Food & Style Development</span>
[raw]<br class=\"spacer\" />[/raw]
Provedore is Lifestyle and Gourmet.
We develop the programming of the website
for this store, restaurant and marketplace.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.provedore.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">provedore.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"PR_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/PR_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"PR_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/PR_002.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"PR_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/PR_003.jpg\" width=\"1440\" height=\"900\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Desarrollo de Estilo & Gourmet</span>
[raw]<br class=\"spacer\" />[/raw]
Provedore es Estilo de Vida y Gourmet.
Desarrollamos la programación del sitio web
para esta tienda, restaurant y mercado.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.provedore.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">provedore.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"PR_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/PR_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"PR_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/PR_002.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"PR_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/PR_003.jpg\" width=\"1440\" height=\"900\" /><!--:-->","Provedore","","inherit","closed","closed","","92-autosave-v1","","","2015-03-03 18:14:29","2015-03-03 18:14:29","","92","https://www.wearedandy.com/92-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("133","2","2015-03-03 19:07:13","2015-03-03 19:07:13","","AK_008","","inherit","closed","closed","","ak_008","","","2015-03-03 19:07:13","2015-03-03 19:07:13","","22","https://www.wearedandy.com/wp-content/uploads/2015/01/AK_008.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("135","2","2015-03-03 19:07:25","2015-03-03 19:07:25","","AK_006","","inherit","closed","closed","","ak_006","","","2015-03-03 19:07:25","2015-03-03 19:07:25","","22","https://www.wearedandy.com/wp-content/uploads/2015/01/AK_006.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("136","2","2015-03-03 19:07:32","2015-03-03 19:07:32","","AK_005","","inherit","closed","closed","","ak_005","","","2015-03-03 19:07:32","2015-03-03 19:07:32","","22","https://www.wearedandy.com/wp-content/uploads/2015/01/AK_005.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("137","2","2015-03-03 19:07:38","2015-03-03 19:07:38","","AK_004","","inherit","closed","closed","","ak_004","","","2015-03-03 19:07:38","2015-03-03 19:07:38","","22","https://www.wearedandy.com/wp-content/uploads/2015/01/AK_004.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("139","2","2015-03-03 19:07:52","2015-03-03 19:07:52","","AK_002","","inherit","closed","closed","","ak_002","","","2015-03-03 19:07:52","2015-03-03 19:07:52","","22","https://www.wearedandy.com/wp-content/uploads/2015/01/AK_002.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("140","2","2015-03-03 19:07:58","2015-03-03 19:07:58","","AK_001","","inherit","closed","closed","","ak_001","","","2015-03-03 19:07:58","2015-03-03 19:07:58","","22","https://www.wearedandy.com/wp-content/uploads/2015/01/AK_001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("142","2","2015-03-03 20:19:20","2015-03-03 20:19:20","","AK_007","","inherit","closed","closed","","ak_007","","","2015-03-03 20:19:20","2015-03-03 20:19:20","","22","https://www.wearedandy.com/wp-content/uploads/2015/01/AK_007.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("143","2","2015-03-03 21:06:25","2015-03-03 21:06:25","<!--:en--><span style=\"font-size: 22px;\">Simplicity</span>
[raw]<br class=\"spacer\" />[/raw]
Texture is a UAE-based real estate group,
offering premium Development, Investment and Brokerage services.
We develop the corporate website.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.texture.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">texture.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"AK_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_001.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-86\" alt=\"AK_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_002.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-89\" alt=\"AK_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_006.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-87\" alt=\"AK_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_004.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-90\" alt=\"AK_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_005.jpg\" width=\"1440\" height=\"900\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Simplicity</span>
[raw]<br class=\"spacer\" />[/raw]
Al Khail Heights is Dubai\'s Exciting 
New Residential Neighbourhood.
We program and design for this real estate development.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.alkhailheights.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">alkhailheights.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"AK_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_001.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-86\" alt=\"AK_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_002.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-89\" alt=\"AK_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_006.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-87\" alt=\"AK_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_004.jpg\" width=\"1440\" height=\"900\" /><img class=\"alignnone size-full wp-image-90\" alt=\"AK_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/AK_005.jpg\" width=\"1440\" height=\"900\" /><!--:-->","<!--:en-->Texture Holding<!--:--><!--:es-->Texture Holding<!--:-->","","inherit","closed","closed","","25-autosave-v1","","","2015-03-03 21:06:25","2015-03-03 21:06:25","","25","https://www.wearedandy.com/25-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("144","2","2015-03-03 22:28:16","2015-03-03 22:28:16","","TX_001","","inherit","closed","closed","","tx_001","","","2015-03-03 22:28:16","2015-03-03 22:28:16","","25","https://www.wearedandy.com/wp-content/uploads/2015/01/TX_001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("145","2","2015-03-03 22:28:22","2015-03-03 22:28:22","","TX_002","","inherit","closed","closed","","tx_002","","","2015-03-03 22:28:22","2015-03-03 22:28:22","","25","https://www.wearedandy.com/wp-content/uploads/2015/01/TX_002.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("146","2","2015-03-03 22:28:28","2015-03-03 22:28:28","","TX_003","","inherit","closed","closed","","tx_003","","","2015-03-03 22:28:28","2015-03-03 22:28:28","","25","https://www.wearedandy.com/wp-content/uploads/2015/01/TX_003.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("147","2","2015-03-03 22:28:35","2015-03-03 22:28:35","","TX_004","","inherit","closed","closed","","tx_004","","","2015-03-03 22:28:35","2015-03-03 22:28:35","","25","https://www.wearedandy.com/wp-content/uploads/2015/01/TX_004.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("148","2","2015-03-03 22:28:41","2015-03-03 22:28:41","","TX_005","","inherit","closed","closed","","tx_005","","","2015-03-03 22:28:41","2015-03-03 22:28:41","","25","https://www.wearedandy.com/wp-content/uploads/2015/01/TX_005.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("149","2","2015-03-03 22:28:51","2015-03-03 22:28:51","","TX_006","","inherit","closed","closed","","tx_006","","","2015-03-03 22:28:51","2015-03-03 22:28:51","","25","https://www.wearedandy.com/wp-content/uploads/2015/01/TX_006.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("150","2","2015-03-03 22:28:57","2015-03-03 22:28:57","","TX_008","","inherit","closed","closed","","tx_008","","","2015-03-03 22:28:57","2015-03-03 22:28:57","","25","https://www.wearedandy.com/wp-content/uploads/2015/01/TX_008.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("151","2","2015-03-04 16:17:36","2015-03-04 16:17:36","<!--:en--><span style=\"font-size: 22px;\">Straightforward</span>
[raw]<br class=\"spacer\" />[/raw]
Pal is a Real Estate and Investment company in Dubai
We could set new standards of programming,
animation and design on this project.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.pal.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">pal.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"PL_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/PL_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"PL_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/PL_002.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"PL_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/PL_003.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"PL_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/PL_004.jpg\" width=\"1440\" height=\"900\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Sencillo</span>
[raw]<br class=\"spacer\" />[/raw]
Pal is a Real Estate and Investment company in Dubai
We could set new standards of programming,
animation and design on this project.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.pal.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">pal.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"PL_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/PL_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"PL_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/PL_002.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"PL_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/PL_003.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"PL_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/PL_004.jpg\" width=\"1440\" height=\"900\" /><!--:-->","<!--:en-->Pal<!--:--><!--:es-->Pal<!--:-->","","inherit","closed","closed","","52-autosave-v1","","","2015-03-04 16:17:36","2015-03-04 16:17:36","","52","https://www.wearedandy.com/52-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("152","2","2015-03-04 16:02:55","2015-03-04 16:02:55","","PL_001","","inherit","closed","closed","","pl_001","","","2015-03-04 16:02:55","2015-03-04 16:02:55","","52","https://www.wearedandy.com/wp-content/uploads/2015/01/PL_001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("153","2","2015-03-04 16:03:03","2015-03-04 16:03:03","","PL_002","","inherit","closed","closed","","pl_002","","","2015-03-04 16:03:03","2015-03-04 16:03:03","","52","https://www.wearedandy.com/wp-content/uploads/2015/01/PL_002.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("154","2","2015-03-04 16:03:10","2015-03-04 16:03:10","","PL_003","","inherit","closed","closed","","pl_003","","","2015-03-04 16:03:10","2015-03-04 16:03:10","","52","https://www.wearedandy.com/wp-content/uploads/2015/01/PL_003.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("155","2","2015-03-04 16:03:18","2015-03-04 16:03:18","","PL_004","","inherit","closed","closed","","pl_004","","","2015-03-04 16:03:18","2015-03-04 16:03:18","","52","https://www.wearedandy.com/wp-content/uploads/2015/01/PL_004.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("156","2","2015-03-04 16:03:25","2015-03-04 16:03:25","","PL_005","","inherit","closed","closed","","pl_005","","","2015-03-04 16:03:25","2015-03-04 16:03:25","","52","https://www.wearedandy.com/wp-content/uploads/2015/01/PL_005.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("158","2","2015-03-04 16:03:39","2015-03-04 16:03:39","","PL_007","","inherit","closed","closed","","pl_007","","","2015-03-04 16:03:39","2015-03-04 16:03:39","","52","https://www.wearedandy.com/wp-content/uploads/2015/01/PL_007.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("159","2","2015-03-04 16:13:14","2015-03-04 16:13:14","","PL_006","","inherit","closed","closed","","pl_006","","","2015-03-04 16:13:14","2015-03-04 16:13:14","","52","https://www.wearedandy.com/wp-content/uploads/2015/01/PL_006.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("161","2","2015-03-04 16:22:37","2015-03-04 16:22:37","","Pal","","publish","closed","closed","","161","","","2018-11-08 14:40:25","2018-11-08 14:40:25","","0","https://www.wearedandy.com/?p=161","9","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES ("162","2","2015-03-04 19:43:27","2015-03-04 19:43:27","<!--:en--><span style=\"font-size: 22px;\">Sophisticated</span>
[raw]<br class=\"spacer\" />[/raw]
Zaya is a boutique real estate & hospitality development. 
We could be part of this development
doing all the programming and responsiveness.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.pal.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">pal.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"ZN_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/ZN_002.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"ZN_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/ZN_003.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"ZN_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/ZN_001.jpg\" width=\"1440\" height=\"900\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Sofisticado</span>
[raw]<br class=\"spacer\" />[/raw]
Zaya is a boutique real estate & hospitality development. 
We could be part of this development
doing all the programming and responsiveness.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.pal.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">pal.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"ZN_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/ZN_002.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"ZN_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/ZN_003.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"ZN_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/01/ZN_001.jpg\" width=\"1440\" height=\"900\" /><!--:-->","<!--:en-->Zaya Nurai Island<!--:--><!--:es-->Zaya Nurai Island<!--:-->","","inherit","closed","closed","","51-autosave-v1","","","2015-03-04 19:43:27","2015-03-04 19:43:27","","51","https://www.wearedandy.com/51-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("163","2","2015-03-04 19:19:53","2015-03-04 19:19:53","","ZN_001","","inherit","closed","closed","","zn_001","","","2015-03-04 19:19:53","2015-03-04 19:19:53","","51","https://www.wearedandy.com/wp-content/uploads/2015/01/ZN_001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("164","2","2015-03-04 19:20:00","2015-03-04 19:20:00","","ZN_002","","inherit","closed","closed","","zn_002","","","2015-03-04 19:20:00","2015-03-04 19:20:00","","51","https://www.wearedandy.com/wp-content/uploads/2015/01/ZN_002.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("165","2","2015-03-04 19:20:11","2015-03-04 19:20:11","","ZN_003","","inherit","closed","closed","","zn_003","","","2015-03-04 19:20:11","2015-03-04 19:20:11","","51","https://www.wearedandy.com/wp-content/uploads/2015/01/ZN_003.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("167","2","2015-03-04 19:20:28","2015-03-04 19:20:28","","ZN_005","","inherit","closed","closed","","zn_005","","","2015-03-04 19:20:28","2015-03-04 19:20:28","","51","https://www.wearedandy.com/wp-content/uploads/2015/01/ZN_005.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("170","2","2015-03-04 19:31:01","2015-03-04 19:31:01","","ZN_006","","inherit","closed","closed","","zn_006","","","2015-03-04 19:31:01","2015-03-04 19:31:01","","51","https://www.wearedandy.com/wp-content/uploads/2015/01/ZN_006.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("172","2","2015-03-04 20:37:01","2015-03-04 20:37:01","<!--:en--><span style=\"font-size: 22px;\">Stylishness</span>
[raw]<br class=\"spacer\" />[/raw]
Royal Estates is a seamlessly integrated community. 
We could be part of this development
making options for branding & concepts.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.royalestates.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">royalestates.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_010.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_002.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_011.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_008.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_007.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_006\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_012.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_007\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_004.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_008\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_001.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_009\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_013.jpg\" width=\"1440\" height=\"900\"/><!--:--><!--:es--><span style=\"font-size: 22px;\">Elegancia</span>
[raw]<br class=\"spacer\" />[/raw]
Royal Estates es una comunidad perfectamente integrada.
Pudimos ser parte de este desarrollo
realizando opciones para branding y conceptos.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.royalestates.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">royalestates.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_010.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_002.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_011.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_008.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_007.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_006\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_012.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_007\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_004.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_008\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_001.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_009\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_013.jpg\" width=\"1440\" height=\"900\"/><!--:-->","<!--:en-->The Royal Estates<!--:--><!--:es-->The Royal Estates<!--:-->","","publish","closed","closed","","the-royal-estates","","","2015-03-06 19:32:33","2015-03-06 19:32:33","","0","https://www.wearedandy.com/?post_type=works&#038;p=172","7","works","","0");
INSERT INTO `wp_posts` VALUES ("173","2","2015-03-04 20:26:58","2015-03-04 20:26:58","","RE_009","","inherit","closed","closed","","re_009","","","2015-03-04 20:26:58","2015-03-04 20:26:58","","172","https://www.wearedandy.com/wp-content/uploads/2015/03/RE_009.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("174","2","2015-03-04 20:27:06","2015-03-04 20:27:06","","RE_008","","inherit","closed","closed","","re_008","","","2015-03-04 20:27:06","2015-03-04 20:27:06","","172","https://www.wearedandy.com/wp-content/uploads/2015/03/RE_008.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("176","2","2015-03-04 20:27:21","2015-03-04 20:27:21","","RE_007","","inherit","closed","closed","","re_007","","","2015-03-04 20:27:21","2015-03-04 20:27:21","","172","https://www.wearedandy.com/wp-content/uploads/2015/03/RE_007.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("177","2","2015-03-04 20:27:28","2015-03-04 20:27:28","","RE_000","","inherit","closed","closed","","re_000","","","2015-03-04 20:27:28","2015-03-04 20:27:28","","172","https://www.wearedandy.com/wp-content/uploads/2015/03/RE_000.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("180","2","2015-03-04 20:27:49","2015-03-04 20:27:49","","RE_004","","inherit","closed","closed","","re_004","","","2015-03-04 20:27:49","2015-03-04 20:27:49","","172","https://www.wearedandy.com/wp-content/uploads/2015/03/RE_004.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("181","2","2015-03-04 20:27:56","2015-03-04 20:27:56","","RE_002","","inherit","closed","closed","","re_002","","","2015-03-04 20:27:56","2015-03-04 20:27:56","","172","https://www.wearedandy.com/wp-content/uploads/2015/03/RE_002.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("182","2","2015-03-04 20:28:03","2015-03-04 20:28:03","","RE_001","","inherit","closed","closed","","re_001","","","2015-03-04 20:28:03","2015-03-04 20:28:03","","172","https://www.wearedandy.com/wp-content/uploads/2015/03/RE_001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("183","2","2015-03-04 20:41:36","2015-03-04 20:41:36","","The Royal Estates","","publish","closed","closed","","183","","","2018-11-08 14:40:25","2018-11-08 14:40:25","","0","https://www.wearedandy.com/?p=183","12","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES ("184","2","2015-03-04 20:48:33","2015-03-04 20:48:33","","RE_010","","inherit","closed","closed","","re_010","","","2015-03-04 20:48:33","2015-03-04 20:48:33","","172","https://www.wearedandy.com/wp-content/uploads/2015/03/RE_010.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("185","2","2015-03-04 21:08:54","2015-03-04 21:08:54","","RE_012","","inherit","closed","closed","","re_012","","","2015-03-04 21:08:54","2015-03-04 21:08:54","","172","https://www.wearedandy.com/wp-content/uploads/2015/03/RE_012.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("186","2","2015-03-04 21:09:01","2015-03-04 21:09:01","","RE_011","","inherit","closed","closed","","re_011","","","2015-03-04 21:09:01","2015-03-04 21:09:01","","172","https://www.wearedandy.com/wp-content/uploads/2015/03/RE_011.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("187","2","2015-03-06 17:55:09","2015-03-06 17:55:09","<!--:en--><span style=\"font-size: 22px;\">Sophisticated</span>
[raw]<br class=\"spacer\" />[/raw]
Royal Estates is a seamlessly integrated community 
for the urban dweller who knows the value of living in a home they can call their own.
Zaya is a boutique real estate & hospitality development. 
We could be part of this development
doing all the programming and responsiveness.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.royalestates.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">royalestates.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_010.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_002.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_011.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_008.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_007.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_006\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_012.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_007\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_004.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_008\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_001.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_009\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_013.jpg\" width=\"1440\" height=\"900\"/><!--:--><!--:es--><span style=\"font-size: 22px;\">Sophisticated</span>
[raw]<br class=\"spacer\" />[/raw]
Zaya is a boutique real estate & hospitality development. 
We could be part of this development
doing all the programming and responsiveness.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.royalestates.ae\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">royalestates.ae</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_010.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_002.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_011.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_008.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_007.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_006\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_012.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_007\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_004.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_008\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_001.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"RE_009\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/RE_013.jpg\" width=\"1440\" height=\"900\"/><!--:-->","<!--:en-->The Royal Estates<!--:--><!--:es-->The Royal Estates<!--:-->","","inherit","closed","closed","","172-autosave-v1","","","2015-03-06 17:55:09","2015-03-06 17:55:09","","172","https://www.wearedandy.com/172-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("188","2","2015-03-04 21:27:45","2015-03-04 21:27:45","","RE_014","","inherit","closed","closed","","re_014","","","2015-03-04 21:27:45","2015-03-04 21:27:45","","172","https://www.wearedandy.com/wp-content/uploads/2015/03/RE_014.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("189","2","2015-03-04 21:29:20","2015-03-04 21:29:20","","RE_013","","inherit","closed","closed","","re_013","","","2015-03-04 21:29:20","2015-03-04 21:29:20","","172","https://www.wearedandy.com/wp-content/uploads/2015/03/RE_013.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("190","2","2015-03-05 13:51:36","2015-03-05 13:51:36","<!--:en-->Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco
laboris nisi ut aliquip ex ea commodo consequat.<!--:--><!--:es-->Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco
laboris nisi ut aliquip ex ea commodo consequat.<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 13:51:36","2015-03-05 13:51:36","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("191","2","2015-03-05 14:01:02","2015-03-05 14:01:02","<!--:en-->Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco
laboris nisi ut aliquip ex ea commodo consequat.<!--:--><!--:es-->Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco
laboris nisi ut aliquip ex ea commodo consequat.<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 14:01:02","2015-03-05 14:01:02","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("192","2","2015-03-05 15:24:08","2015-03-05 15:24:08","<!--:en-->Dandy is an agency of digital services and design.
We are specialized in Branding & Real Estate developments.
We have extensive experience of production
including print, websites, and management.
<!--:--><!--:es-->Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco
laboris nisi ut aliquip ex ea commodo consequat.<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 15:24:08","2015-03-05 15:24:08","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("193","2","2015-03-05 15:24:19","2015-03-05 15:24:19","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding & Real Estate developments.
We have extensive experience of production
including print, websites, and management.
<!--:--><!--:es-->Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco
laboris nisi ut aliquip ex ea commodo consequat.<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 15:24:19","2015-03-05 15:24:19","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("194","2","2015-03-05 15:28:02","2015-03-05 15:28:02","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding & Real Estate developments.
We have extensive experience of production
including print, websites, and management.
<!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate .
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 15:28:02","2015-03-05 15:28:02","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("195","2","2015-03-05 15:28:27","2015-03-05 15:28:27","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding & Real Estate developments.

We have extensive experience of production
including print, websites, and management.
<!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.

Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 15:28:27","2015-03-05 15:28:27","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("196","2","2015-03-05 15:28:37","2015-03-05 15:28:37","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding & Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.

Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 15:28:37","2015-03-05 15:28:37","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("197","2","2015-03-05 15:28:45","2015-03-05 15:28:45","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding & Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 15:28:45","2015-03-05 15:28:45","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("198","2","2015-03-05 15:45:09","2015-03-05 15:45:09","","AU_003","","inherit","closed","closed","","au_003","","","2015-03-05 15:45:09","2015-03-05 15:45:09","","16","https://www.wearedandy.com/wp-content/uploads/2014/12/AU_003.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("199","2","2015-03-05 15:45:23","2015-03-05 15:45:23","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding & Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 15:45:23","2015-03-05 15:45:23","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("200","2","2015-03-05 15:55:42","2015-03-05 15:55:42","<!--:en--><span style=\"font-size: 14px;\">Thank you for your interest in our work.</span>
<span style=\"font-size: 14px;\"> Please fill out the form below.</span>
<span style=\"font-size: 14px;\"> We will contact you soon.</span><!--:--><!--:es--><span style=\"font-size: 14px;\"> Gracias por su interés en nuestro trabajo.</span>
<span style=\"font-size: 14px;\"> Por favor complete el siguiente formu.</span>
<span style=\"font-size: 14px;\"> We will contact you soon.</span><!--:-->","<!--:en-->Contact<!--:--><!--:es-->Contacto<!--:-->","","inherit","closed","closed","","42-autosave-v1","","","2015-03-05 15:55:42","2015-03-05 15:55:42","","42","https://www.wearedandy.com/42-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("201","2","2015-03-05 15:57:21","2015-03-05 15:57:21","<!--:en--><span style=\"font-size: 14px;\">Thank you for your interest in our work.</span>
<span style=\"font-size: 14px;\"> Please fill out the form below.</span>
<span style=\"font-size: 14px;\"> We will contact you soon.</span><!--:--><!--:es--><span style=\"font-size: 14px;\"> Gracias por su interés en nuestro trabajo.</span>
<span style=\"font-size: 14px;\"> Por favor, complete el siguiente formulario.</span>
<span style=\"font-size: 14px;\"> Nos pondremos en contacto con usted pronto.</span><!--:-->","<!--:en-->Contact<!--:--><!--:es-->Contacto<!--:-->","","inherit","closed","closed","","42-revision-v1","","","2015-03-05 15:57:21","2015-03-05 15:57:21","","42","https://www.wearedandy.com/42-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("204","2","2015-03-05 15:59:35","2015-03-05 15:59:35","<!--:en--><span style=\"font-size: 14px;\">Thank you for your interest in our work.</span>
<span style=\"font-size: 14px;\"> Please fill out the form below.</span>
<span style=\"font-size: 14px;\"> We will contact you soon.</span><!--:--><!--:es--><span style=\"font-size: 14px;\"> Gracias por su interés en nuestro trabajo.</span>
<span style=\"font-size: 14px;\"> Por favor, complete el siguiente formulario.</span>
<span style=\"font-size: 14px;\"> Nos pondremos en contacto con usted pronto.</span><!--:-->","<!--:en-->Contact<!--:--><!--:es-->Contacto<!--:-->","","inherit","closed","closed","","42-revision-v1","","","2015-03-05 15:59:35","2015-03-05 15:59:35","","42","https://www.wearedandy.com/42-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("206","2","2015-03-05 16:14:08","2015-03-05 16:14:08","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding & Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.

<br><a href=\"http://facebook.com/dandyagency\" target=\"_blank\">Facebook®</a><br><a href=\"http://twitter.com/agencydandy\" target=\"_blank\">Twitter®</a><br>
<a href=\"http://behance.net/dandyagency\" target=\"_blank\">Behance®</a><br>
<a href=\"http://instagram.com/dandyagency\" target=\"_blank\">Instagram®</a></p.<!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 16:14:08","2015-03-05 16:14:08","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("207","2","2015-03-05 16:15:00","2015-03-05 16:15:00","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding & Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.

<br><a href=\"http://facebook.com/dandyagency\" target=\"_blank\">Facebook®</a><br><a href=\"http://twitter.com/agencydandy\" target=\"_blank\">Twitter®</a><br><a href=\"http://behance.net/dandyagency\" target=\"_blank\">Behance®</a><br><a href=\"http://instagram.com/dandyagency\" target=\"_blank\">Instagram®</a></p.<!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 16:15:00","2015-03-05 16:15:00","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("208","2","2015-03-05 16:16:05","2015-03-05 16:16:05","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding & Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.

<br><a href=\"http://twitter.com/agencydandy\" target=\"_blank\">Twitter®</a><br><a href=\"http://instagram.com/dandyagency\" target=\"_blank\">Instagram®</a></p.<!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 16:16:05","2015-03-05 16:16:05","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("209","2","2015-03-05 16:18:41","2015-03-05 16:18:41","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 16:18:41","2015-03-05 16:18:41","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("210","2","2015-03-05 16:20:16","2015-03-05 16:20:16","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 16:20:16","2015-03-05 16:20:16","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("211","2","2015-03-05 16:26:21","2015-03-05 16:26:21","","AU_004","","inherit","closed","closed","","au_004","","","2015-03-05 16:26:21","2015-03-05 16:26:21","","16","https://www.wearedandy.com/wp-content/uploads/2014/12/AU_004.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("212","2","2015-03-05 16:26:48","2015-03-05 16:26:48","","AU_005","","inherit","closed","closed","","au_005","","","2015-03-05 16:26:48","2015-03-05 16:26:48","","16","https://www.wearedandy.com/wp-content/uploads/2014/12/AU_005.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("213","2","2015-03-05 16:27:00","2015-03-05 16:27:00","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 16:27:00","2015-03-05 16:27:00","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("214","2","2015-03-05 16:28:01","2015-03-05 16:28:01","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 16:28:01","2015-03-05 16:28:01","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("215","2","2015-03-05 16:33:31","2015-03-05 16:33:31","","CT000","","inherit","closed","closed","","ct000","","","2015-03-05 16:33:31","2015-03-05 16:33:31","","42","https://www.wearedandy.com/wp-content/uploads/2015/01/CT000.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("216","2","2015-03-05 16:33:38","2015-03-05 16:33:38","<!--:en--><span style=\"font-size: 14px;\">Thank you for your interest in our work.</span>
<span style=\"font-size: 14px;\"> Please fill out the form below.</span>
<span style=\"font-size: 14px;\"> We will contact you soon.</span><!--:--><!--:es--><span style=\"font-size: 14px;\"> Gracias por su interés en nuestro trabajo.</span>
<span style=\"font-size: 14px;\"> Por favor, complete el siguiente formulario.</span>
<span style=\"font-size: 14px;\"> Nos pondremos en contacto con usted pronto.</span><!--:-->","<!--:en-->Contact<!--:--><!--:es-->Contacto<!--:-->","","inherit","closed","closed","","42-revision-v1","","","2015-03-05 16:33:38","2015-03-05 16:33:38","","42","https://www.wearedandy.com/42-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("217","2","2015-03-05 17:33:52","2015-03-05 17:33:52","<!--:en--><h2>Digital &amp; Graphic Agency
based in Buenos Aires, Argentina.</h2><!--:--><!--:es--><h2>Agencia Digital &amp; Gráfica
establecida en Buenos Aires, Argentina.</h2><!--:-->","Home","","inherit","closed","closed","","5-revision-v1","","","2015-03-05 17:33:52","2015-03-05 17:33:52","","5","https://www.wearedandy.com/5-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("219","2","2015-03-05 17:34:56","2015-03-05 17:34:56","","AK_007","","inherit","closed","closed","","ak_007-2","","","2015-03-05 17:34:56","2015-03-05 17:34:56","","5","https://www.wearedandy.com/wp-content/uploads/2014/11/AK_007.jpg","2","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("220","2","2015-03-05 17:35:04","2015-03-05 17:35:04","","NT_001","","inherit","closed","closed","","nt_001-2","","","2015-03-05 17:35:04","2015-03-05 17:35:04","","5","https://www.wearedandy.com/wp-content/uploads/2014/11/NT_001.jpg","3","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("221","2","2015-03-05 17:35:12","2015-03-05 17:35:12","","PL_002","","inherit","closed","closed","","pl_002-2","","","2015-03-05 17:35:12","2015-03-05 17:35:12","","5","https://www.wearedandy.com/wp-content/uploads/2014/11/PL_002.jpg","4","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("222","2","2015-03-05 17:35:19","2015-03-05 17:35:19","","PR_005","","inherit","closed","closed","","pr_005-2","","","2015-03-05 17:35:19","2015-03-05 17:35:19","","5","https://www.wearedandy.com/wp-content/uploads/2014/11/PR_005.jpg","6","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("225","2","2015-03-05 17:36:31","2015-03-05 17:36:31","","RE_007","","inherit","closed","closed","","re_007-2","","","2015-03-05 17:36:31","2015-03-05 17:36:31","","5","https://www.wearedandy.com/wp-content/uploads/2014/11/RE_007.jpg","1","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("226","2","2015-03-05 17:36:42","2015-03-05 17:36:42","<!--:en--><h2>Digital &amp; Graphic Agency
based in Buenos Aires, Argentina.</h2><!--:--><!--:es--><h2>Agencia Digital &amp; Gráfica
establecida en Buenos Aires, Argentina.</h2><!--:-->","Home","","inherit","closed","closed","","5-revision-v1","","","2015-03-05 17:36:42","2015-03-05 17:36:42","","5","https://www.wearedandy.com/5-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("227","2","2015-03-05 17:39:39","2015-03-05 17:39:39","","RE_004","","inherit","closed","closed","","re_004-2","","","2015-03-05 17:39:39","2015-03-05 17:39:39","","5","https://www.wearedandy.com/wp-content/uploads/2014/11/RE_004.jpg","5","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("229","2","2015-03-05 18:49:16","2015-03-05 18:49:16","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.


<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®
</span></a><a href=\"http://facebook.com/wearedandy\" target=\"_blank\">Facebook®</a>
</span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 18:49:16","2015-03-05 18:49:16","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("230","2","2015-03-05 18:51:45","2015-03-05 18:51:45","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.

<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®
</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\">
</span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.

<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®
</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\">
</span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 18:51:45","2015-03-05 18:51:45","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("231","2","2015-03-05 18:52:19","2015-03-05 18:52:19","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®
</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\">
</span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®
</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\">
</span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 18:52:19","2015-03-05 18:52:19","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("232","2","2015-03-05 18:58:18","2015-03-05 18:58:18","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®
</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\">
</span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®
</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\">
</span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 18:58:18","2015-03-05 18:58:18","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("233","2","2015-03-05 19:03:01","2015-03-05 19:03:01","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®
</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\">
</span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®
</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\">
</span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-05 19:03:01","2015-03-05 19:03:01","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("234","2","2015-03-06 16:58:49","2015-03-06 16:58:49","","AA_000","","inherit","closed","closed","","aa_000","","","2015-03-06 16:58:49","2015-03-06 16:58:49","","94","https://www.wearedandy.com/wp-content/uploads/2015/03/AA_000.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("235","2","2015-03-06 17:00:44","2015-03-06 17:00:44","","AA_003","","inherit","closed","closed","","aa_003","","","2015-03-06 17:00:44","2015-03-06 17:00:44","","94","https://www.wearedandy.com/wp-content/uploads/2015/03/AA_003.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("236","2","2015-03-06 17:16:21","2015-03-06 17:16:21","","AA_000","","inherit","closed","closed","","aa_000-2","","","2015-03-06 17:16:21","2015-03-06 17:16:21","","94","https://www.wearedandy.com/wp-content/uploads/2015/03/AA_0001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("238","2","2015-03-06 17:22:11","2015-03-06 17:22:11","","AA_004","","inherit","closed","closed","","aa_004","","","2015-03-06 17:22:11","2015-03-06 17:22:11","","94","https://www.wearedandy.com/wp-content/uploads/2015/03/AA_004.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("239","2","2015-03-06 17:42:58","2015-03-06 17:42:58","","AA_005","","inherit","closed","closed","","aa_005","","","2015-03-06 17:42:58","2015-03-06 17:42:58","","94","https://www.wearedandy.com/wp-content/uploads/2015/03/AA_005.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("240","2","2015-03-06 18:58:17","2015-03-06 18:58:17","","AK_010","","inherit","closed","closed","","ak_010","","","2015-03-06 18:58:17","2015-03-06 18:58:17","","22","https://www.wearedandy.com/wp-content/uploads/2015/01/AK_010.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("241","2","2015-03-09 15:28:46","2015-03-09 15:28:46","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®
</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\">
</span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®
</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\">
</span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-09 15:28:46","2015-03-09 15:28:46","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("242","2","2015-03-13 15:19:02","2015-03-13 15:19:02","<!--:en--><span style=\"font-size: 22px;\">Dynamism</span>
[raw]<br class=\"spacer\" />[/raw]
Methanoia is a Studio of Architecture and Renderings. 
We could be part of this development
making design interfase on website.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.methanoia.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">methanoia.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"MT_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/MT_003.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"MT_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/MT_008.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"MT_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/MT_002.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"MT_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/MT_004.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"MT_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/MT_007.jpg\" width=\"1440\" height=\"900\"/><!--:--><!--:es--><span style=\"font-size: 22px;\">Dinamismo</span>
[raw]<br class=\"spacer\" />[/raw]
Methanoia es un Estudio de Arquitectura y Renders.
Podríamos ser parte de este desarrollo
haciendo diseño de interfase en el sitio web.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.methanoia.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">methanoia.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"MT_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/MT_003.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"MT_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/MT_008.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"MT_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/MT_002.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"MT_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/MT_004.jpg\" width=\"1440\" height=\"900\"/>
<img class=\"alignnone size-full wp-image-88\" alt=\"MT_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/MT_007.jpg\" width=\"1440\" height=\"900\"/><!--:-->","<!--:en-->Methanoia<!--:--><!--:es-->Methanoia<!--:-->","","draft","closed","closed","","methanoia","","","2018-11-07 13:58:19","2018-11-07 13:58:19","","0","https://www.wearedandy.com/?post_type=works&#038;p=242","15","works","","0");
INSERT INTO `wp_posts` VALUES ("243","2","2015-03-13 15:09:48","2015-03-13 15:09:48","","MT_006","","inherit","closed","closed","","mt_006","","","2015-03-13 15:09:48","2015-03-13 15:09:48","","242","https://www.wearedandy.com/wp-content/uploads/2015/03/MT_006.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("244","2","2015-03-13 15:09:55","2015-03-13 15:09:55","","MT_000","","inherit","closed","closed","","mt_000","","","2015-03-13 15:09:55","2015-03-13 15:09:55","","242","https://www.wearedandy.com/wp-content/uploads/2015/03/MT_000.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("245","2","2015-03-13 15:10:01","2015-03-13 15:10:01","","MT_005","","inherit","closed","closed","","mt_005","","","2015-03-13 15:10:01","2015-03-13 15:10:01","","242","https://www.wearedandy.com/wp-content/uploads/2015/03/MT_005.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("246","2","2015-03-13 15:10:10","2015-03-13 15:10:10","","MT_004","","inherit","closed","closed","","mt_004","","","2015-03-13 15:10:10","2015-03-13 15:10:10","","242","https://www.wearedandy.com/wp-content/uploads/2015/03/MT_004.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("247","2","2015-03-13 15:10:16","2015-03-13 15:10:16","","MT_003","","inherit","closed","closed","","mt_003","","","2015-03-13 15:10:16","2015-03-13 15:10:16","","242","https://www.wearedandy.com/wp-content/uploads/2015/03/MT_003.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("248","2","2015-03-13 15:10:21","2015-03-13 15:10:21","","MT_002","","inherit","closed","closed","","mt_002","","","2015-03-13 15:10:21","2015-03-13 15:10:21","","242","https://www.wearedandy.com/wp-content/uploads/2015/03/MT_002.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("249","2","2015-03-13 15:10:28","2015-03-13 15:10:28","","MT_001","","inherit","closed","closed","","mt_001","","","2015-03-13 15:10:28","2015-03-13 15:10:28","","242","https://www.wearedandy.com/wp-content/uploads/2015/03/MT_001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("251","2","2015-03-13 19:40:26","2015-03-13 19:40:26","","MT_008","","inherit","closed","closed","","mt_008","","","2015-03-13 19:40:26","2015-03-13 19:40:26","","242","https://www.wearedandy.com/wp-content/uploads/2015/03/MT_008.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("252","2","2015-03-13 19:40:32","2015-03-13 19:40:32","","MT_007","","inherit","closed","closed","","mt_007","","","2015-03-13 19:40:32","2015-03-13 19:40:32","","242","https://www.wearedandy.com/wp-content/uploads/2015/03/MT_007.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("254","2","2015-03-15 20:07:03","2015-03-15 20:07:03","","AU_006","","inherit","closed","closed","","au_006","","","2015-03-15 20:07:03","2015-03-15 20:07:03","","16","https://www.wearedandy.com/wp-content/uploads/2014/12/AU_006.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("255","2","2015-03-15 20:07:13","2015-03-15 20:07:13","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>

<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span>

<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span>

<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>

<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span>

<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span>

<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-03-15 20:07:13","2015-03-15 20:07:13","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("257","2","2015-03-16 12:12:37","2015-03-16 12:12:37","<!--:en--><h2>Digital &amp; Graphic Agency
based in Buenos Aires, Argentina.</h2><!--:--><!--:es--><h2>Agencia Digital &amp; Gráfica
establecida en Buenos Aires, Argentina.</h2><!--:-->","Home","","inherit","closed","closed","","5-revision-v1","","","2015-03-16 12:12:37","2015-03-16 12:12:37","","5","https://www.wearedandy.com/5-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("258","2","2015-03-16 12:16:30","2015-03-16 12:16:30","<!--:en--><h2>Digital &amp; Graphic Agency
based in Buenos Aires, Argentina.</h2><!--:--><!--:es--><h2>Agencia Digital &amp; Gráfica
establecida en Buenos Aires, Argentina.</h2><!--:-->","Home","","inherit","closed","closed","","5-revision-v1","","","2015-03-16 12:16:30","2015-03-16 12:16:30","","5","https://www.wearedandy.com/5-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("261","2","2015-03-16 12:31:25","2015-03-16 12:31:25","<!--:en--><span style=\"font-size: 14px;\">Thank you for your interest in our work.</span>
<span style=\"font-size: 14px;\"> Please fill out the form below.</span>
<span style=\"font-size: 14px;\"> We will contact you soon.</span><!--:--><!--:es--><span style=\"font-size: 14px;\"> Gracias por su interés en nuestro trabajo.</span>
<span style=\"font-size: 14px;\"> Por favor, complete el siguiente formulario.</span>
<span style=\"font-size: 14px;\"> Nos pondremos en contacto con usted pronto.</span><!--:-->","<!--:en-->Contact<!--:--><!--:es-->Contacto<!--:-->","","inherit","closed","closed","","42-revision-v1","","","2015-03-16 12:31:25","2015-03-16 12:31:25","","42","https://www.wearedandy.com/42-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("263","2","2015-03-28 22:59:52","2015-03-28 22:59:52","","AU_008","","inherit","closed","closed","","au_008","","","2015-03-28 22:59:52","2015-03-28 22:59:52","","42","https://www.wearedandy.com/wp-content/uploads/2015/01/AU_008.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("264","2","2015-03-28 23:00:07","2015-03-28 23:00:07","<!--:en--><span style=\"font-size: 14px;\">Thank you for your interest in our work.</span>
<span style=\"font-size: 14px;\"> Please fill out the form below.</span>
<span style=\"font-size: 14px;\"> We will contact you soon.</span><!--:--><!--:es--><span style=\"font-size: 14px;\"> Gracias por su interés en nuestro trabajo.</span>
<span style=\"font-size: 14px;\"> Por favor, complete el siguiente formulario.</span>
<span style=\"font-size: 14px;\"> Nos pondremos en contacto con usted pronto.</span><!--:-->","<!--:en-->Contact<!--:--><!--:es-->Contacto<!--:-->","","inherit","closed","closed","","42-revision-v1","","","2015-03-28 23:00:07","2015-03-28 23:00:07","","42","https://www.wearedandy.com/42-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("265","2","2015-03-30 19:52:50","2015-03-30 19:52:50","<!--:en--><span style=\"font-size: 22px;\">Effortless</span>
[raw]<br class=\"spacer\" />[/raw]
Zaya is a boutique real estate & hospitality development. 
We could be part of this development
doing all the programming and responsiveness.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.zayahameni.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">zayahameni.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"ZH_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/ZH_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"ZH_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/ZH_002.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"ZH_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/ZH_003.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"ZH_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/ZH_004.jpg\" width=\"1440\" height=\"900\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Fácil</span>
[raw]<br class=\"spacer\" />[/raw]
Zaya es un desarrollo boutique inmobiliario.
Pudimos ser parte de este desarrollo
haciendo toda la programación y adaptibilidad.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.zayahameni.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">zayahameni.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"ZH_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/ZH_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"ZH_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/ZH_002.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"ZH_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/ZH_003.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"ZH_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/03/ZH_004.jpg\" width=\"1440\" height=\"900\" /><!--:-->","<!--:en-->Zaya Hameni<!--:--><!--:es-->Zaya Hameni<!--:-->","","draft","closed","closed","","zaya-hameni","","","2018-11-07 13:58:43","2018-11-07 13:58:43","","0","https://www.wearedandy.com/?post_type=works&#038;p=265","5","works","","0");
INSERT INTO `wp_posts` VALUES ("266","2","2015-03-30 18:53:37","2015-03-30 18:53:37","","ZH_002","","inherit","closed","closed","","zh_002","","","2015-03-30 18:53:37","2015-03-30 18:53:37","","265","https://www.wearedandy.com/wp-content/uploads/2015/03/ZH_002.jpg","2","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("267","2","2015-03-30 18:53:46","2015-03-30 18:53:46","","ZH_003","","inherit","closed","closed","","zh_003","","","2015-03-30 18:53:46","2015-03-30 18:53:46","","265","https://www.wearedandy.com/wp-content/uploads/2015/03/ZH_003.jpg","4","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("268","2","2015-03-30 18:53:55","2015-03-30 18:53:55","","ZH_004","","inherit","closed","closed","","zh_004","","","2015-03-30 18:53:55","2015-03-30 18:53:55","","265","https://www.wearedandy.com/wp-content/uploads/2015/03/ZH_004.jpg","3","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("269","2","2015-03-30 18:54:03","2015-03-30 18:54:03","","ZH_001","","inherit","closed","closed","","zh_001","","","2015-03-30 18:54:03","2015-03-30 18:54:03","","265","https://www.wearedandy.com/wp-content/uploads/2015/03/ZH_001.jpg","1","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("270","2","2015-03-30 19:50:14","2015-03-30 19:50:14","","ZH_000","","inherit","closed","closed","","zh_000","","","2015-03-30 19:50:14","2015-03-30 19:50:14","","265","https://www.wearedandy.com/wp-content/uploads/2015/03/ZH_000.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("271","2","2015-03-30 19:50:37","2015-03-30 19:50:37","","ZH_005","","inherit","closed","closed","","zh_005","","","2015-03-30 19:50:37","2015-03-30 19:50:37","","265","https://www.wearedandy.com/wp-content/uploads/2015/03/ZH_005.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("274","2","2015-04-14 20:23:56","2015-04-14 20:23:56","<!--:en--><span style=\"font-size: 22px;\">Release</span>
[raw]<br class=\"spacer\" />[/raw]
Iboux is an innovative online language school that provides one-on-one,
high-quality video-conferencing classes with certified native teachers.
We developed E-commerce and Design.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.zayahameni.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">zayahameni.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_002.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_004.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_006\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_006.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_003.jpg\" width=\"1440\" height=\"900\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Estreno</span>
[raw]<br class=\"spacer\" />[/raw]
Iboux es una innovadora escuela de idiomas on-line que ofrece uno-a-uno,
clases mediante videoconferencia de alta calidad con profesores nativos certificados.
Desarrollamos e implementamos E-commerce y Diseño.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://www.iboux.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">iboux.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_002.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_004.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_006\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_006.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_003.jpg\" width=\"1440\" height=\"900\" /><!--:-->","<!--:en-->Zaya Hameni<!--:--><!--:es-->Zaya Hameni<!--:-->","","inherit","closed","closed","","265-autosave-v1","","","2015-04-14 20:23:56","2015-04-14 20:23:56","","265","https://www.wearedandy.com/265-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("275","2","2015-04-14 20:25:33","2015-04-14 20:25:33","<!--:en--><span style=\"font-size: 22px;\">Release</span>
[raw]<br class=\"spacer\" />[/raw]
Iboux is an innovative online language school that provides one-on-one,
high-quality video-conferencing classes with certified native teachers.
We developed E-commerce and Design.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://iboux.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">iboux.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_004.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_003.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_006\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_006.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_002.jpg\" width=\"1440\" height=\"900\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Estreno</span>
[raw]<br class=\"spacer\" />[/raw]
Iboux es una innovadora escuela de idiomas on-line que ofrece uno-a-uno,
clases mediante videoconferencia de alta calidad con profesores nativos certificados.
Desarrollamos e implementamos E-commerce y Diseño.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://iboux.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">iboux.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_004.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_003.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_006\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_006.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"IB_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/04/IB_002.jpg\" width=\"1440\" height=\"900\" /><!--:-->","<!--:en-->Iboux<!--:--><!--:es-->Iboux<!--:-->","","publish","closed","closed","","iboux","","","2015-04-15 10:48:58","2015-04-15 10:48:58","","0","https://www.wearedandy.com/?post_type=works&#038;p=275","4","works","","0");
INSERT INTO `wp_posts` VALUES ("277","2","2015-04-14 20:15:51","2015-04-14 20:15:51","","IB_000","","inherit","closed","closed","","ib_000","","","2015-04-14 20:15:51","2015-04-14 20:15:51","","275","https://www.wearedandy.com/wp-content/uploads/2015/04/IB_000.jpg","1","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("278","2","2015-04-14 20:16:32","2015-04-14 20:16:32","","IB_001","","inherit","closed","closed","","ib_001","","","2015-04-14 20:16:32","2015-04-14 20:16:32","","275","https://www.wearedandy.com/wp-content/uploads/2015/04/IB_001.jpg","2","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("279","2","2015-04-14 20:16:41","2015-04-14 20:16:41","","IB_002","","inherit","closed","closed","","ib_002","","","2015-04-14 20:16:41","2015-04-14 20:16:41","","275","https://www.wearedandy.com/wp-content/uploads/2015/04/IB_002.jpg","6","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("280","2","2015-04-14 20:16:49","2015-04-14 20:16:49","","IB_003","","inherit","closed","closed","","ib_003","","","2015-04-14 20:16:49","2015-04-14 20:16:49","","275","https://www.wearedandy.com/wp-content/uploads/2015/04/IB_003.jpg","4","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("281","2","2015-04-14 20:17:00","2015-04-14 20:17:00","","IB_004","","inherit","closed","closed","","ib_004","","","2015-04-14 20:17:00","2015-04-14 20:17:00","","275","https://www.wearedandy.com/wp-content/uploads/2015/04/IB_004.jpg","7","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("282","2","2015-04-14 20:17:11","2015-04-14 20:17:11","","IB_006","","inherit","closed","closed","","ib_006","","","2015-04-14 20:17:11","2015-04-14 20:17:11","","275","https://www.wearedandy.com/wp-content/uploads/2015/04/IB_006.jpg","5","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("283","2","2015-04-14 20:24:45","2015-04-14 20:24:45","","IB_002","","inherit","closed","closed","","ib_002-2","","","2015-04-14 20:24:45","2015-04-14 20:24:45","","275","https://www.wearedandy.com/wp-content/uploads/2015/04/IB_0021.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("284","2","2015-04-14 20:26:44","2015-04-14 20:26:44","","Iboux","","publish","closed","closed","","284","","","2018-11-08 14:40:25","2018-11-08 14:40:25","","0","https://www.wearedandy.com/?p=284","6","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES ("287","2","2015-04-14 23:41:21","2015-04-14 23:41:21","","IB_008","","inherit","closed","closed","","ib_008","","","2015-04-14 23:41:21","2015-04-14 23:41:21","","275","https://www.wearedandy.com/wp-content/uploads/2015/04/IB_008.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("288","2","2015-04-21 14:29:39","2015-04-21 14:29:39","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span>

<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span>

<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span>

<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span>

<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span>

<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-04-21 14:29:39","2015-04-21 14:29:39","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("289","2","2015-04-21 14:32:40","2015-04-21 14:32:40","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandyagency_resume.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–résumé</span></a></span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandyagency_resume.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–résumé</span></a></span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-04-21 14:32:40","2015-04-21 14:32:40","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("290","2","2015-04-21 14:33:16","2015-04-21 14:33:16","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandyagency_resume.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–résumé</span></a></span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandyagency_resume.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–résumé</span></a></span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-04-21 14:33:16","2015-04-21 14:33:16","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("291","2","2015-04-21 14:34:28","2015-04-21 14:34:28","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandyagency_resume.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–résumé</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandyagency_resume.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–résumé</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-04-21 14:34:28","2015-04-21 14:34:28","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("292","2","2015-04-21 14:35:56","2015-04-21 14:35:56","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandyagency_resume.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–résumé [pdf format, 8.7Mb]</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandyagency_resume.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–résumé</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-04-21 14:35:56","2015-04-21 14:35:56","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("293","2","2015-04-21 14:38:26","2015-04-21 14:38:26","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandyagency_resume.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–résumé [pdf format, 8.7Mb]</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandyagency_resume.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–resumen [formato pdf, 8.7Mb]</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-04-21 14:38:26","2015-04-21 14:38:26","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("294","2","2015-04-22 15:01:47","2015-04-22 15:01:47","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandy_agency_br_eng.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–résumé [pdf format, 8.7Mb]</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandy_agency_br_esp.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–resumen [formato pdf, 8.7Mb]</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2015-04-22 15:01:47","2015-04-22 15:01:47","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("296","2","2015-07-08 19:20:13","2015-07-08 19:20:13","<!--:en--><span style=\"font-size: 22px;\">Brand New</span>
[raw]<br class=\"spacer\" />[/raw]
Branding development for María BA,
a small brand of bags and handbags in Buenos Aires.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://mariaba.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">mariaba.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_17.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_15.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_16.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_13.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_12.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_006\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_11.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_007\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_10.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_008\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_07.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_009\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_06.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_010\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_05.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_011\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_04.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_012\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_03.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_013\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_02.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_014\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_01.jpg\" width=\"1440\" height=\"900\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Lo Nuevo</span>
[raw]<br class=\"spacer\" />[/raw]
Desarrollo de branding para María BA,
una pequeña marca de bolsos y carteras en Buenos Aires.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://mariaba.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">mariaba.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_17.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_15.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_16.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_13.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_12.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_006\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_11.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_007\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_10.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_008\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_07.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_009\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_06.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_010\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_05.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_011\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_04.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_012\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_03.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_013\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_02.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_014\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_01.jpg\" width=\"1440\" height=\"900\" /><!--:-->","<!--:en-->María BA<!--:--><!--:es-->María BA<!--:-->","","draft","closed","closed","","maria-ba","","","2018-11-07 13:58:12","2018-11-07 13:58:12","","0","https://www.wearedandy.com/?post_type=works&#038;p=296","14","works","","0");
INSERT INTO `wp_posts` VALUES ("297","2","2015-07-08 18:48:44","2015-07-08 18:48:44","","mba_12","","inherit","closed","closed","","mba_12","","","2015-07-08 18:48:44","2015-07-08 18:48:44","","296","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_12.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("298","2","2015-07-08 18:49:26","2015-07-08 18:49:26","","mba_10","","inherit","closed","closed","","mba_10","","","2015-07-08 18:49:26","2015-07-08 18:49:26","","296","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_10.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("299","2","2015-07-08 19:04:03","2015-07-08 19:04:03","","mba_00","","inherit","closed","closed","","mba_00","","","2015-07-08 19:04:03","2015-07-08 19:04:03","","296","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_00.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("300","2","2015-07-08 19:07:17","2015-07-08 19:07:17","","mba_00","","inherit","closed","closed","","mba_00-2","","","2015-07-08 19:07:17","2015-07-08 19:07:17","","296","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("301","2","2015-07-08 19:07:26","2015-07-08 19:07:26","","mba_01","","inherit","closed","closed","","mba_01","","","2015-07-08 19:07:26","2015-07-08 19:07:26","","296","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_01.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("302","2","2015-07-08 19:07:36","2015-07-08 19:07:36","","mba_02","","inherit","closed","closed","","mba_02","","","2015-07-08 19:07:36","2015-07-08 19:07:36","","296","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_02.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("303","2","2015-07-08 19:07:42","2015-07-08 19:07:42","","mba_03","","inherit","closed","closed","","mba_03","","","2015-07-08 19:07:42","2015-07-08 19:07:42","","296","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_03.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("304","2","2015-07-08 19:07:48","2015-07-08 19:07:48","","mba_04","","inherit","closed","closed","","mba_04","","","2015-07-08 19:07:48","2015-07-08 19:07:48","","296","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_04.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("305","2","2015-07-08 19:07:54","2015-07-08 19:07:54","","mba_05","","inherit","closed","closed","","mba_05","","","2015-07-08 19:07:54","2015-07-08 19:07:54","","296","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_05.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("306","2","2015-07-08 19:08:00","2015-07-08 19:08:00","","mba_06","","inherit","closed","closed","","mba_06","","","2015-07-08 19:08:00","2015-07-08 19:08:00","","296","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_06.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("307","2","2015-07-08 19:08:06","2015-07-08 19:08:06","","mba_07","","inherit","closed","closed","","mba_07","","","2015-07-08 19:08:06","2015-07-08 19:08:06","","296","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_07.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("308","2","2015-07-08 19:08:11","2015-07-08 19:08:11","","mba_08","","inherit","closed","closed","","mba_08","","","2015-07-08 19:08:11","2015-07-08 19:08:11","","296","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_08.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("309","2","2015-07-08 19:08:19","2015-07-08 19:08:19","","mba_09","","inherit","closed","closed","","mba_09","","","2015-07-08 19:08:19","2015-07-08 19:08:19","","296","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_09.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("310","2","2015-07-08 19:08:25","2015-07-08 19:08:25","","mba_10","","inherit","closed","closed","","mba_10-2","","","2015-07-08 19:08:25","2015-07-08 19:08:25","","296","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_101.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("311","2","2015-07-08 19:08:30","2015-07-08 19:08:30","","mba_11","","inherit","closed","closed","","mba_11","","","2015-07-08 19:08:30","2015-07-08 19:08:30","","296","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_11.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("312","2","2015-07-08 19:08:37","2015-07-08 19:08:37","","mba_12","","inherit","closed","closed","","mba_12-2","","","2015-07-08 19:08:37","2015-07-08 19:08:37","","296","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_121.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("313","2","2015-07-08 19:08:44","2015-07-08 19:08:44","","mba_13","","inherit","closed","closed","","mba_13","","","2015-07-08 19:08:44","2015-07-08 19:08:44","","296","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_13.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("314","2","2015-07-08 19:08:52","2015-07-08 19:08:52","","mba_14","","inherit","closed","closed","","mba_14","","","2015-07-08 19:08:52","2015-07-08 19:08:52","","296","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_14.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("322","2","2015-07-08 20:15:23","2015-07-08 20:15:23","","mba_16","","inherit","closed","closed","","mba_16","","","2015-07-08 20:15:23","2015-07-08 20:15:23","","0","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_16.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("323","2","2015-07-08 20:15:28","2015-07-08 20:15:28","","mba_17","","inherit","closed","closed","","mba_17","","","2015-07-08 20:15:28","2015-07-08 20:15:28","","0","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_17.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("324","2","2015-07-08 20:40:18","2015-07-08 20:40:18","","mba_15","","inherit","closed","closed","","mba_15","","","2015-07-08 20:40:18","2015-07-08 20:40:18","","0","https://www.wearedandy.com/wp-content/uploads/2015/07/mba_15.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("325","2","2015-07-08 20:49:06","2015-07-08 20:49:06","<!--:en--><span style=\"font-size: 22px;\">Brand</span>
[raw]<br class=\"spacer\" />[/raw]
Branding development for María BA,
a small brand of bags and handbags in Buenos Aires.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://mariaba.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">mariaba.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_17.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_15.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_16.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_13.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_12.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_006\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_11.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_007\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_10.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_008\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_07.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_009\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_06.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_010\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_05.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_011\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_04.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_012\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_03.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_013\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_02.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_014\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_01.jpg\" width=\"1440\" height=\"900\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Release</span>
[raw]<br class=\"spacer\" />[/raw]
Desarrollo de branding para María BA,
una pequeña marca de bolsos y carteras en Buenos Aires.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://mariaba.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">mariaba.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_17.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_15.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_16.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_004\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_13.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_005\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_12.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_006\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_11.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_007\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_10.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_008\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_07.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_009\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_06.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_010\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_05.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_011\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_04.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_012\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_03.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_013\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_02.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"MBA_014\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/07/mba_01.jpg\" width=\"1440\" height=\"900\" /><!--:-->","<!--:en-->María BA<!--:--><!--:es-->María BA<!--:-->","","inherit","closed","closed","","296-autosave-v1","","","2015-07-08 20:49:06","2015-07-08 20:49:06","","296","https://www.wearedandy.com/296-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("327","2","2015-08-01 03:37:07","2015-08-01 03:37:07","<!--:en--><span style=\"font-size: 22px;\">Activated</span>
[raw]<br class=\"spacer\" />[/raw]
R+ is a creative studio that provides services
of brand activation, marketing and planning.
We developed the website responsive.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://rmas-studio.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">rmas-studio.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"R+_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/08/RM_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"R+_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/08/RM_004.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"R+_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/08/RM_002.jpg\" width=\"1440\" height=\"900\" />
<!--:--><!--:es--><span style=\"font-size: 22px;\">Activado</span>
[raw]<br class=\"spacer\" />[/raw]
R+ es un estudio creativo que provee servicios
de activación de marca, marketing y planificación.
Desarollamos el sitio web corporativo.
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://rmas-studio.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">rmas-studio.com</span></a></span>
<img class=\"alignnone size-full wp-image-88\" alt=\"R+_001\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/08/RM_001.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"R+_002\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/08/RM_004.jpg\" width=\"1440\" height=\"900\" />
<img class=\"alignnone size-full wp-image-88\" alt=\"R+_003\" src=\"https://www.wearedandy.com/wp-content/uploads/2015/08/RM_002.jpg\" width=\"1440\" height=\"900\" />
<!--:-->","<!--:en-->R+<!--:--><!--:es-->R+<!--:-->","","draft","closed","closed","","rmas","","","2018-11-07 13:58:36","2018-11-07 13:58:36","","0","https://www.wearedandy.com/?post_type=works&#038;p=327","3","works","","0");
INSERT INTO `wp_posts` VALUES ("328","2","2015-08-01 03:30:06","2015-08-01 03:30:06","","RM_003","","inherit","closed","closed","","rm_003","","","2015-08-01 03:30:06","2015-08-01 03:30:06","","327","https://www.wearedandy.com/wp-content/uploads/2015/08/RM_003.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("329","2","2015-08-01 03:30:29","2015-08-01 03:30:29","","RM_000","","inherit","closed","closed","","rm_000","","","2015-08-01 03:30:29","2015-08-01 03:30:29","","327","https://www.wearedandy.com/wp-content/uploads/2015/08/RM_000.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("330","2","2015-08-01 03:31:51","2015-08-01 03:31:51","","RM_001","","inherit","closed","closed","","rm_001","","","2015-08-01 03:31:51","2015-08-01 03:31:51","","0","https://www.wearedandy.com/wp-content/uploads/2015/08/RM_001.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("331","2","2015-08-01 03:31:57","2015-08-01 03:31:57","","RM_004","","inherit","closed","closed","","rm_004","","","2015-08-01 03:31:57","2015-08-01 03:31:57","","0","https://www.wearedandy.com/wp-content/uploads/2015/08/RM_004.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("332","2","2015-08-01 03:32:03","2015-08-01 03:32:03","","RM_002","","inherit","closed","closed","","rm_002","","","2015-08-01 03:32:03","2015-08-01 03:32:03","","0","https://www.wearedandy.com/wp-content/uploads/2015/08/RM_002.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("333","2","2015-08-01 03:35:41","2015-08-01 03:35:41","","RM_004","","inherit","closed","closed","","rm_004-2","","","2015-08-01 03:35:41","2015-08-01 03:35:41","","327","https://www.wearedandy.com/wp-content/uploads/2015/08/RM_0041.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("336","2","2016-08-08 14:29:48","2016-08-08 14:29:48","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandy_agency_br_eng.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–résumé [pdf format, 8.7Mb]</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.facebook.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandy_agency_br_esp.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–resumen [formato pdf, 8.7Mb]</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://facebook.com/wearedandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2016-08-08 14:29:48","2016-08-08 14:29:48","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("337","2","2016-08-08 14:30:36","2016-08-08 14:30:36","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandy_agency_br_eng.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–résumé [pdf format, 8.7Mb]</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.facebook.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandy_agency_br_esp.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–resumen [formato pdf, 8.7Mb]</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.facebook.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2016-08-08 14:30:36","2016-08-08 14:30:36","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("338","2","2016-08-08 14:51:17","2016-08-08 14:51:17","<!--:en-->Dandy® is an agency of digital services and design.
We are specialized in Branding &amp; Real Estate developments.
~
We have extensive experience of production
including print, websites, and management.
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandy_agency_br_eng.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–résumé [pdf format, 8.7Mb]</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.facebook.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:--><!--:es-->Dandy® es una agencia de servicios digitales y diseño.
Nos especializamos en desarrollos de Branding y Real Estate.
~
Nuestra amplia experiencia de producción
incluye identidad, websites y management.
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.wearedandy.com/downloads/dandy_agency_br_esp.pdf\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Dandy Agency ~ portfolio–resumen [formato pdf, 8.7Mb]</span></a></span></span>
<br/>
<span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://twitter.com/agencydandy\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Twitter®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"http://instagram.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Instagram®</span></a></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.facebook.com/dandyagency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Facebook®</span></a></span></span><span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"></span></span> ~ <span style=\"text-decoration: underline; color: #ff5859;\"><span style=\"text-decoration: underline;\"><a href=\"https://www.linkedin.com/company/dandy-agency\" target=\"_blank\"><span style=\"color: #ff5859; text-decoration: underline;\">Linked In®</span></a></span></span><!--:-->","<!--:en-->About Us<!--:--><!--:es-->Sobre Nosotros<!--:-->","","inherit","closed","closed","","16-revision-v1","","","2016-08-08 14:51:17","2016-08-08 14:51:17","","16","https://www.wearedandy.com/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("340","2","2018-09-26 18:53:22","2018-09-26 18:53:22","a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:5:\"works\";}}}s:8:\"position\";s:4:\"side\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:0:{}s:11:\"description\";s:0:\"\";}","Destacar en la Home","destacar-en-la-home","publish","closed","closed","","group_5babd5a20f00d","","","2018-09-26 18:53:22","2018-09-26 18:53:22","","0","https://www.wearedandy.com/?post_type=acf-field-group&p=340","1","acf-field-group","","0");
INSERT INTO `wp_posts` VALUES ("341","2","2018-09-26 18:53:22","2018-09-26 18:53:22","a:12:{s:4:\"type\";s:8:\"checkbox\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:1:{s:2:\"si\";s:2:\"Si\";}s:13:\"default_value\";a:0:{}s:6:\"layout\";s:10:\"horizontal\";s:12:\"allow_custom\";i:0;s:11:\"save_custom\";i:0;s:6:\"toggle\";i:0;s:13:\"return_format\";s:5:\"value\";}","","descatar_home","publish","closed","closed","","field_54aec60b5808b","","","2018-09-26 18:53:22","2018-09-26 18:53:22","","340","https://www.wearedandy.com/?post_type=acf-field&p=341","0","acf-field","","0");
INSERT INTO `wp_posts` VALUES ("342","2","2018-09-26 18:53:22","2018-09-26 18:53:22","a:7:{s:8:\"location\";a:3:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:8:\"home.php\";}}i:1;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:5:\"works\";}}i:2;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:16:\"page-contact.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:0:{}s:11:\"description\";s:0:\"\";}","Parallax Image","parallax-image","publish","closed","closed","","group_5babd5a214a32","","","2018-09-26 18:53:22","2018-09-26 18:53:22","","0","https://www.wearedandy.com/?post_type=acf-field-group&p=342","1","acf-field-group","","0");
INSERT INTO `wp_posts` VALUES ("343","2","2018-09-26 18:53:22","2018-09-26 18:53:22","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:13:\"return_format\";s:3:\"url\";s:9:\"min_width\";i:0;s:10:\"min_height\";i:0;s:8:\"min_size\";i:0;s:9:\"max_width\";i:0;s:10:\"max_height\";i:0;s:8:\"max_size\";i:0;s:10:\"mime_types\";s:0:\"\";}","","middle_image","publish","closed","closed","","field_54ac3ffdec05f","","","2018-09-26 18:53:22","2018-09-26 18:53:22","","342","https://www.wearedandy.com/?post_type=acf-field&p=343","0","acf-field","","0");
INSERT INTO `wp_posts` VALUES ("344","2","2018-09-26 18:53:22","2018-09-26 18:53:22","a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:5:\"works\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:0:{}s:11:\"description\";s:0:\"\";}","Subtitle","subtitle","publish","closed","closed","","group_5babd5a219a9e","","","2018-09-26 18:53:22","2018-09-26 18:53:22","","0","https://www.wearedandy.com/?post_type=acf-field-group&p=344","1","acf-field-group","","0");
INSERT INTO `wp_posts` VALUES ("345","2","2018-09-26 18:53:22","2018-09-26 18:53:22","a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:10:\"formatting\";s:4:\"html\";s:9:\"maxlength\";s:0:\"\";}","Español","subtitle_esp","publish","closed","closed","","field_54ac29a4ce78c","","","2018-09-26 18:53:22","2018-09-26 18:53:22","","344","https://www.wearedandy.com/?post_type=acf-field&p=345","0","acf-field","","0");
INSERT INTO `wp_posts` VALUES ("346","2","2018-09-26 18:53:22","2018-09-26 18:53:22","a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:10:\"formatting\";s:4:\"html\";s:9:\"maxlength\";s:0:\"\";}","English","subtitle_eng","publish","closed","closed","","field_54ac29b6ce78d","","","2018-09-26 18:53:22","2018-09-26 18:53:22","","344","https://www.wearedandy.com/?post_type=acf-field&p=346","1","acf-field","","0");
INSERT INTO `wp_posts` VALUES ("347","2","2018-09-26 18:53:22","2018-09-26 18:53:22","a:7:{s:8:\"location\";a:3:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:5:\"works\";}}i:1;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:14:\"page-about.php\";}}i:2;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:16:\"page-contact.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:0:{}s:11:\"description\";s:0:\"\";}","Imagen Header","imagen-header","publish","closed","closed","","group_5babd5a220b37","","","2018-09-26 18:53:22","2018-09-26 18:53:22","","0","https://www.wearedandy.com/?post_type=acf-field-group&p=347","2","acf-field-group","","0");
INSERT INTO `wp_posts` VALUES ("348","2","2018-09-26 18:53:22","2018-09-26 18:53:22","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:10:\"uploadedTo\";s:13:\"return_format\";s:3:\"url\";s:9:\"min_width\";i:0;s:10:\"min_height\";i:0;s:8:\"min_size\";i:0;s:9:\"max_width\";i:0;s:10:\"max_height\";i:0;s:8:\"max_size\";i:0;s:10:\"mime_types\";s:0:\"\";}","","imagen_header","publish","closed","closed","","field_54aedcf0bf3de","","","2018-09-26 18:53:22","2018-09-26 18:53:22","","347","https://www.wearedandy.com/?post_type=acf-field&p=348","0","acf-field","","0");
INSERT INTO `wp_posts` VALUES ("349","2","2018-09-26 19:01:39","2018-09-26 19:01:39","","Works","","publish","closed","closed","","works","","","2018-11-08 14:40:25","2018-11-08 14:40:25","","0","https://www.wearedandy.com/?p=349","2","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES ("352","2","2018-10-08 15:49:10","2018-10-08 15:49:10","","logo-dandy","","inherit","closed","closed","","logo-dandy","","","2018-10-08 15:49:10","2018-10-08 15:49:10","","0","https://www.wearedandy.com/wp-content/uploads/2018/10/logo-dandy.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES ("354","2","2018-11-07 13:35:29","2018-11-07 13:35:29","<!--:en--><span style=\"font-size: 22px;\">E-commerce</span>
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"https://roparevolver.com/\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">roparevolver.com</span></a></span>
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/revolver1.png\" alt=\"\" width=\"1940\" height=\"1080\" class=\"aligncenter size-full wp-image-358\" />
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/revolver2.png\" alt=\"\" width=\"313\" height=\"634\" class=\"aligncenter size-full wp-image-357\" />
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/revolver3.png\" alt=\"\" width=\"1940\" height=\"1072\" class=\"aligncenter size-full wp-image-356\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">E-commerce</span>
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"https://roparevolver.com/\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">roparevolver.com</span></a></span>
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/revolver1.png\" alt=\"\" width=\"1940\" height=\"1080\" class=\"aligncenter size-full wp-image-358\" />
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/revolver2.png\" alt=\"\" width=\"313\" height=\"634\" class=\"aligncenter size-full wp-image-357\" />
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/revolver3.png\" alt=\"\" width=\"1940\" height=\"1072\" class=\"aligncenter size-full wp-image-356\" /><!--:-->","<!--:en-->Revolver<!--:--><!--:es-->Revolver<!--:-->","","publish","closed","closed","","revolver","","","2018-11-07 14:54:10","2018-11-07 14:54:10","","0","https://www.wearedandy.com/?post_type=works&#038;p=354","2","works","","0");
INSERT INTO `wp_posts` VALUES ("355","2","2018-11-07 13:31:16","2018-11-07 13:31:16","","revolver","","inherit","closed","closed","","revolver","","","2018-11-07 13:31:16","2018-11-07 13:31:16","","354","https://www.wearedandy.com/wp-content/uploads/2018/11/revolver.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("356","2","2018-11-07 13:34:19","2018-11-07 13:34:19","","revolver3","","inherit","closed","closed","","revolver3","","","2018-11-07 13:34:19","2018-11-07 13:34:19","","354","https://www.wearedandy.com/wp-content/uploads/2018/11/revolver3.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES ("357","2","2018-11-07 13:34:28","2018-11-07 13:34:28","","revolver2","","inherit","closed","closed","","revolver2","","","2018-11-07 13:34:28","2018-11-07 13:34:28","","354","https://www.wearedandy.com/wp-content/uploads/2018/11/revolver2.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES ("358","2","2018-11-07 13:34:38","2018-11-07 13:34:38","","revolver1","","inherit","closed","closed","","revolver1","","","2018-11-07 13:34:38","2018-11-07 13:34:38","","354","https://www.wearedandy.com/wp-content/uploads/2018/11/revolver1.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES ("359","2","2018-11-07 13:36:32","2018-11-07 13:36:32","<!--:en--><span style=\"font-size: 22px;\">E-commerce</span>
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"https://roparevolver.com/\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">roparevolver.com</span></a></span>
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/revolver1.png\" alt=\"\" width=\"1940\" height=\"1080\" class=\"alignnone size-full wp-image-358\" />
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/revolver2.png\" alt=\"\" width=\"626\" height=\"1268\" class=\"aligncenter size-full wp-image-357\" />
<!--:--><!--:es--><span style=\"font-size: 22px;\">E-commerce</span>
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"https://roparevolver.com/\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">roparevolver.com</span></a></span>
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/revolver1.png\" alt=\"\" width=\"1940\" height=\"1080\" class=\"alignnone size-full wp-image-358\" />
<!--:-->","<!--:en-->Revolver<!--:--><!--:es-->Revolver<!--:-->","","inherit","closed","closed","","354-autosave-v1","","","2018-11-07 13:36:32","2018-11-07 13:36:32","","354","https://www.wearedandy.com/354-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("360","2","2018-11-07 14:00:14","2018-11-07 14:00:14","","Revolver","","publish","closed","closed","","revolver","","","2018-11-08 14:40:25","2018-11-08 14:40:25","","0","https://www.wearedandy.com/?p=360","10","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES ("361","2","2018-11-07 14:51:56","2018-11-07 14:51:56","<!--:en--><span style=\"font-size: 22px;\">Real State Web Development</span>
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://jadepark.com/\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">jadepark.com</span></a></span>
[raw]<br class=\"spacer\" />[/raw]
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/jadepark2.png\" alt=\"\" width=\"1940\" height=\"1072\" class=\"aligncenter size-full wp-image-363\" />
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/jadepark1.png\" alt=\"\" width=\"1940\" height=\"1080\" class=\"aligncenter size-full wp-image-364\" />
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/jadepark3.png\" alt=\"\" width=\"313\" height=\"634\" class=\"aligncenter size-full wp-image-362\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Web Development</span>
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://jadepark.com/\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">jadepark.com</span></a></span>
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/jadepark2.png\" alt=\"\" width=\"1940\" height=\"1072\" class=\"aligncenter size-full wp-image-363\" />
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/jadepark1.png\" alt=\"\" width=\"1940\" height=\"1080\" class=\"aligncenter size-full wp-image-364\" />
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/jadepark3.png\" alt=\"\" width=\"313\" height=\"634\" class=\"aligncenter size-full wp-image-362\" /><!--:-->","<!--:en-->JadePark<!--:--><!--:es-->JadePark<!--:-->","","publish","closed","closed","","jadepark","","","2018-11-07 15:02:21","2018-11-07 15:02:21","","0","https://www.wearedandy.com/?post_type=works&#038;p=361","10","works","","0");
INSERT INTO `wp_posts` VALUES ("362","2","2018-11-07 14:48:23","2018-11-07 14:48:23","","jadepark3","","inherit","closed","closed","","jadepark3","","","2018-11-07 14:48:23","2018-11-07 14:48:23","","361","https://www.wearedandy.com/wp-content/uploads/2018/11/jadepark3.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES ("363","2","2018-11-07 14:48:50","2018-11-07 14:48:50","","jadepark2","","inherit","closed","closed","","jadepark2","","","2018-11-07 14:48:50","2018-11-07 14:48:50","","361","https://www.wearedandy.com/wp-content/uploads/2018/11/jadepark2.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES ("364","2","2018-11-07 14:49:06","2018-11-07 14:49:06","","jadepark1","","inherit","closed","closed","","jadepark1","","","2018-11-07 14:49:06","2018-11-07 14:49:06","","361","https://www.wearedandy.com/wp-content/uploads/2018/11/jadepark1.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES ("365","2","2018-11-07 14:49:16","2018-11-07 14:49:16","","jadepark","","inherit","closed","closed","","jadepark","","","2018-11-07 14:49:16","2018-11-07 14:49:16","","361","https://www.wearedandy.com/wp-content/uploads/2018/11/jadepark.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("366","2","2018-11-07 15:01:34","2018-11-07 15:01:34","","JadePark","","publish","closed","closed","","jadepark","","","2018-11-08 14:40:25","2018-11-08 14:40:25","","0","https://www.wearedandy.com/?p=366","7","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES ("367","2","2018-11-08 13:27:54","2018-11-08 13:27:54","<!--:en--><span style=\"font-size: 22px;\">Web Development</span>
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"https://www.alcortashopping.com.ar\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">alcortashopping.com.ar</span></a></span>
[raw]<br class=\"spacer\" />[/raw]
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/alcorta1.png\" alt=\"\" width=\"313\" height=\"634\" class=\"aligncenter size-full wp-image-371\" />
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/alcorta2.png\" alt=\"\" width=\"1940\" height=\"1072\" class=\"aligncenter size-full wp-image-370\" />
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/alcorta3.png\" alt=\"\" width=\"1940\" height=\"1080\" class=\"aligncenter size-full wp-image-369\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Web Development</span>
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"https://www.alcortashopping.com.ar\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">alcortashopping.com.ar</span></a></span>
[raw]<br class=\"spacer\" />[/raw]
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/alcorta1.png\" alt=\"\" width=\"313\" height=\"634\" class=\"aligncenter size-full wp-image-371\" />
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/alcorta2.png\" alt=\"\" width=\"1940\" height=\"1072\" class=\"aligncenter size-full wp-image-370\" />
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/alcorta3.png\" alt=\"\" width=\"1940\" height=\"1080\" class=\"aligncenter size-full wp-image-369\" /><!--:-->","<!--:en-->Alcorta Shopping<!--:--><!--:es-->Alcorta Shopping<!--:-->","","publish","closed","closed","","alcorta-shopping","","","2018-11-08 13:53:09","2018-11-08 13:53:09","","0","https://www.wearedandy.com/?post_type=works&#038;p=367","1","works","","0");
INSERT INTO `wp_posts` VALUES ("368","2","2018-11-08 13:27:33","2018-11-08 13:27:33","","alcorta","","inherit","closed","closed","","alcorta","","","2018-11-08 13:27:33","2018-11-08 13:27:33","","367","https://www.wearedandy.com/wp-content/uploads/2018/11/alcorta.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("369","2","2018-11-08 13:49:26","2018-11-08 13:49:26","","alcorta3","","inherit","closed","closed","","alcorta3","","","2018-11-08 13:49:26","2018-11-08 13:49:26","","367","https://www.wearedandy.com/wp-content/uploads/2018/11/alcorta3.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES ("370","2","2018-11-08 13:49:37","2018-11-08 13:49:37","","alcorta2","","inherit","closed","closed","","alcorta2","","","2018-11-08 13:49:37","2018-11-08 13:49:37","","367","https://www.wearedandy.com/wp-content/uploads/2018/11/alcorta2.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES ("371","2","2018-11-08 13:49:46","2018-11-08 13:49:46","","alcorta1","","inherit","closed","closed","","alcorta1","","","2018-11-08 13:49:46","2018-11-08 13:49:46","","367","https://www.wearedandy.com/wp-content/uploads/2018/11/alcorta1.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES ("372","2","2018-11-08 13:50:10","2018-11-08 13:50:10","<!--:en--><span style=\"font-size: 22px;\">Web Development</span>
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"https://www.alcortashopping.com.ar\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">alcortashopping.com.ar</span></a></span>

<!--:--><!--:es--><span style=\"font-size: 22px;\">Web Development</span>
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"https://www.alcortashopping.com.ar\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">alcortashopping.com.ar</span></a></span>
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/alcorta3.png\" alt=\"\" width=\"1940\" height=\"1080\" class=\"aligncenter size-full wp-image-369\" />

<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/alcorta2.png\" alt=\"\" width=\"1940\" height=\"1072\" class=\"aligncenter size-full wp-image-370\" />

<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/alcorta1.png\" alt=\"\" width=\"626\" height=\"1268\" class=\"aligncenter size-full wp-image-371\" /><!--:-->","<!--:en-->Alcorta Shopping<!--:--><!--:es-->Alcorta Shopping<!--:-->","","inherit","closed","closed","","367-autosave-v1","","","2018-11-08 13:50:10","2018-11-08 13:50:10","","367","https://www.wearedandy.com/367-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES ("373","2","2018-11-08 14:02:26","2018-11-08 14:02:26","","Alcorta Shopping","","publish","closed","closed","","alcorta-shopping","","","2018-11-08 14:40:25","2018-11-08 14:40:25","","0","https://www.wearedandy.com/?p=373","3","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES ("374","2","2018-11-08 14:37:59","2018-11-08 14:37:59","<!--:en--><span style=\"font-size: 22px;\">Real State Web Development</span>
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://tribecaloftsnyc.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">tribecaloftsnyc.com</span></a></span>
[raw]<br class=\"spacer\" />[/raw]
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/tribeca1.png\" alt=\"\" width=\"1940\" height=\"1072\" class=\"aligncenter size-full wp-image-378\" />
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/tribeca2.png\" alt=\"\" width=\"1940\" height=\"1080\" class=\"aligncenter size-full wp-image-377\" />
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/tribeca3.png\" alt=\"\" width=\"313\" height=\"634\" class=\"aligncenter size-full wp-image-376\" /><!--:--><!--:es--><span style=\"font-size: 22px;\">Real State Web Development</span>
[raw]<br class=\"spacer\" />[/raw]
<span style=\"color: #ff5859;\"><a href=\"http://tribecaloftsnyc.com\" target=\"_blank\"><span style=\"font-size: 18px; color: #ff5859;\">tribecaloftsnyc.com</span></a></span>
[raw]<br class=\"spacer\" />[/raw]
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/tribeca1.png\" alt=\"\" width=\"1940\" height=\"1072\" class=\"aligncenter size-full wp-image-378\" />
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/tribeca2.png\" alt=\"\" width=\"1940\" height=\"1080\" class=\"aligncenter size-full wp-image-377\" />
<img src=\"https://www.wearedandy.com/wp-content/uploads/2018/11/tribeca3.png\" alt=\"\" width=\"313\" height=\"634\" class=\"aligncenter size-full wp-image-376\" /><!--:-->","<!--:en-->Tribeca Lofts<!--:--><!--:es-->Tribeca Lofts<!--:-->","","publish","closed","closed","","tribeca-lofts","","","2018-11-08 14:41:02","2018-11-08 14:41:02","","0","https://www.wearedandy.com/?post_type=works&#038;p=374","11","works","","0");
INSERT INTO `wp_posts` VALUES ("375","2","2018-11-08 14:28:37","2018-11-08 14:28:37","","tribeca","","inherit","closed","closed","","tribeca","","","2018-11-08 14:28:37","2018-11-08 14:28:37","","374","https://www.wearedandy.com/wp-content/uploads/2018/11/tribeca.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("376","2","2018-11-08 14:36:39","2018-11-08 14:36:39","","tribeca3","","inherit","closed","closed","","tribeca3","","","2018-11-08 14:36:39","2018-11-08 14:36:39","","374","https://www.wearedandy.com/wp-content/uploads/2018/11/tribeca3.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES ("377","2","2018-11-08 14:36:53","2018-11-08 14:36:53","","tribeca2","","inherit","closed","closed","","tribeca2","","","2018-11-08 14:36:53","2018-11-08 14:36:53","","374","https://www.wearedandy.com/wp-content/uploads/2018/11/tribeca2.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES ("378","2","2018-11-08 14:37:03","2018-11-08 14:37:03","","tribeca1","","inherit","closed","closed","","tribeca1","","","2018-11-08 14:37:03","2018-11-08 14:37:03","","374","https://www.wearedandy.com/wp-content/uploads/2018/11/tribeca1.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES ("379","2","2018-11-08 14:40:25","2018-11-08 14:40:25","","Tribeca Lofts","","publish","closed","closed","","tribeca-lofts","","","2018-11-08 14:40:25","2018-11-08 14:40:25","","0","https://www.wearedandy.com/?p=379","13","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES ("380","2","2018-11-08 14:45:48","2018-11-08 14:45:48","","CT000_1","","inherit","closed","closed","","ct000_1","","","2018-11-08 14:45:48","2018-11-08 14:45:48","","42","https://www.wearedandy.com/wp-content/uploads/2018/11/CT000_1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES ("381","2","2018-11-08 14:46:04","2018-11-08 14:46:04","<!--:en--><span style=\"font-size: 14px;\">Thank you for your interest in our work.</span>
<span style=\"font-size: 14px;\"> Please fill out the form below.</span>
<span style=\"font-size: 14px;\"> We will contact you soon.</span><!--:--><!--:es--><span style=\"font-size: 14px;\"> Gracias por su interés en nuestro trabajo.</span>
<span style=\"font-size: 14px;\"> Por favor, complete el siguiente formulario.</span>
<span style=\"font-size: 14px;\"> Nos pondremos en contacto con usted pronto.</span><!--:-->","<!--:en-->Contact<!--:--><!--:es-->Contacto<!--:-->","","inherit","closed","closed","","42-revision-v1","","","2018-11-08 14:46:04","2018-11-08 14:46:04","","42","https://www.wearedandy.com/42-revision-v1/","0","revision","","0");


CREATE TABLE IF NOT EXISTS `wp_smush_dir_images` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `path` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `path_hash` char(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `resize` varchar(55) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lossy` varchar(55) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `error` varchar(55) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `image_size` int(10) unsigned DEFAULT NULL,
  `orig_size` int(10) unsigned DEFAULT NULL,
  `file_time` int(10) unsigned DEFAULT NULL,
  `last_scan` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `meta` text COLLATE utf8mb4_unicode_520_ci,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `path_hash` (`path_hash`),
  KEY `image_size` (`image_size`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



CREATE TABLE IF NOT EXISTS `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_term_relationships` VALUES ("18","2","0");
INSERT INTO `wp_term_relationships` VALUES ("19","2","0");
INSERT INTO `wp_term_relationships` VALUES ("44","2","0");
INSERT INTO `wp_term_relationships` VALUES ("46","2","0");
INSERT INTO `wp_term_relationships` VALUES ("47","2","0");
INSERT INTO `wp_term_relationships` VALUES ("110","2","0");
INSERT INTO `wp_term_relationships` VALUES ("118","2","0");
INSERT INTO `wp_term_relationships` VALUES ("161","2","0");
INSERT INTO `wp_term_relationships` VALUES ("183","2","0");
INSERT INTO `wp_term_relationships` VALUES ("284","2","0");
INSERT INTO `wp_term_relationships` VALUES ("349","2","0");
INSERT INTO `wp_term_relationships` VALUES ("360","2","0");
INSERT INTO `wp_term_relationships` VALUES ("366","2","0");
INSERT INTO `wp_term_relationships` VALUES ("373","2","0");
INSERT INTO `wp_term_relationships` VALUES ("379","2","0");


CREATE TABLE IF NOT EXISTS `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_term_taxonomy` VALUES ("1","1","category","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES ("2","2","nav_menu","","0","15");


CREATE TABLE IF NOT EXISTS `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  `term_order` int(4) DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_terms` VALUES ("1","Sin categoría","sin-categoria","0","0");
INSERT INTO `wp_terms` VALUES ("2","main","main","0","0");


CREATE TABLE IF NOT EXISTS `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_usermeta` VALUES ("1","2","first_name","");
INSERT INTO `wp_usermeta` VALUES ("2","2","last_name","");
INSERT INTO `wp_usermeta` VALUES ("3","2","nickname","admin");
INSERT INTO `wp_usermeta` VALUES ("4","2","description","");
INSERT INTO `wp_usermeta` VALUES ("5","2","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES ("6","2","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES ("7","2","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES ("8","2","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES ("9","2","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES ("10","2","wp_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES ("11","2","wp_user_level","10");
INSERT INTO `wp_usermeta` VALUES ("12","2","dismissed_wp_pointers","wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks,wp496_privacy,theme_editor_notice");
INSERT INTO `wp_usermeta` VALUES ("13","2","show_welcome_panel","1");
INSERT INTO `wp_usermeta` VALUES ("14","2","wp_dashboard_quick_press_last_post_id","382");
INSERT INTO `wp_usermeta` VALUES ("15","2","wp_user-settings","hidetb=1&libraryContent=browse&editor=html&urlbutton=none&imgsize=full&align=center");
INSERT INTO `wp_usermeta` VALUES ("16","2","wp_user-settings-time","1541597820");
INSERT INTO `wp_usermeta` VALUES ("17","2","managenav-menuscolumnshidden","a:3:{i:0;s:11:\"link-target\";i:1;s:3:\"xfn\";i:2;s:11:\"description\";}");
INSERT INTO `wp_usermeta` VALUES ("18","2","metaboxhidden_nav-menus","a:2:{i:0;s:12:\"add-category\";i:1;s:12:\"add-post_tag\";}");
INSERT INTO `wp_usermeta` VALUES ("19","2","closedpostboxes_nav-menus","a:0:{}");
INSERT INTO `wp_usermeta` VALUES ("20","2","nav_menu_recently_edited","2");
INSERT INTO `wp_usermeta` VALUES ("21","2","meta-box-order_works","a:4:{s:15:\"acf_after_title\";s:0:\"\";s:4:\"side\";s:29:\"submitdiv,postimagediv,acf_50\";s:6:\"normal\";s:28:\"acf_24,acf_53,acf_31,slugdiv\";s:8:\"advanced\";s:0:\"\";}");
INSERT INTO `wp_usermeta` VALUES ("22","2","screen_layout_works","2");
INSERT INTO `wp_usermeta` VALUES ("23","2","closedpostboxes_works","a:0:{}");
INSERT INTO `wp_usermeta` VALUES ("24","2","metaboxhidden_works","a:2:{i:0;s:6:\"acf_70\";i:1;s:7:\"slugdiv\";}");
INSERT INTO `wp_usermeta` VALUES ("25","2","default_password_nag","");
INSERT INTO `wp_usermeta` VALUES ("26","2","session_tokens","a:1:{s:64:\"2db7578da86813a8edcc9914d3045f2d1d81e40513ab8fcf903a54bb0e23fb59\";a:4:{s:10:\"expiration\";i:1547913489;s:2:\"ip\";s:15:\"181.167.100.209\";s:2:\"ua\";s:120:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36\";s:5:\"login\";i:1547740689;}}");
INSERT INTO `wp_usermeta` VALUES ("27","2","community-events-location","a:1:{s:2:\"ip\";s:13:\"181.167.100.0\";}");
INSERT INTO `wp_usermeta` VALUES ("28","2","itsec_user_activity_last_seen","1547752481");
INSERT INTO `wp_usermeta` VALUES ("30","2","wp_wpseo-dismiss-gsc","seen");
INSERT INTO `wp_usermeta` VALUES ("31","2","itsec-settings-view","list");
INSERT INTO `wp_usermeta` VALUES ("32","2","itsec-password-strength","4");
INSERT INTO `wp_usermeta` VALUES ("33","2","_itsec_password_requirements","a:1:{s:16:\"evaluation_times\";a:1:{s:8:\"strength\";i:1539013131;}}");
INSERT INTO `wp_usermeta` VALUES ("34","2","_itsec_has_logged_in","1539013131");
INSERT INTO `wp_usermeta` VALUES ("35","2","wpseo-remove-upsell-notice","1");
INSERT INTO `wp_usermeta` VALUES ("36","2","wp_yoast_notifications","a:1:{i:0;a:2:{s:7:\"message\";s:169:\"Don\'t miss your crawl errors: <a href=\"https://www.wearedandy.com/wp-admin/admin.php?page=wpseo_search_console&tab=settings\">connect with Google Search Console here</a>.\";s:7:\"options\";a:9:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:17:\"wpseo-dismiss-gsc\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}}");


CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_users` VALUES ("2","dandyadmin","$P$BzZZRijgq6dpzvqGCTzOlZyOECzjBj.","admin","guille070@gmail.com","","2014-11-18 22:06:08","","0","admin");


CREATE TABLE IF NOT EXISTS `wp_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `target_post_id` bigint(20) unsigned NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_yoast_seo_links` VALUES ("11","https://www.wearedandy.com/downloads/dandy_agency_br_eng.pdf","16","0","internal");
INSERT INTO `wp_yoast_seo_links` VALUES ("12","http://twitter.com/agencydandy","16","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES ("13","http://instagram.com/dandyagency","16","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES ("14","https://www.facebook.com/dandyagency","16","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES ("15","https://www.linkedin.com/company/dandy-agency","16","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES ("26","http://mariaba.com","296","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES ("27","http://www.methanoia.com","242","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES ("28","http://www.provedore.ae","92","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES ("29","http://rmas-studio.com","327","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES ("30","http://www.zayahameni.com","265","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES ("31","http://www.zayanuraiisland.com","51","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES ("32","http://www.texture.ae","25","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES ("41","https://roparevolver.com/","354","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES ("43","http://www.andreaanzorena.com","94","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES ("44","http://jadepark.com/","361","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES ("50","https://www.alcortashopping.com.ar","367","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES ("51","http://www.nativetrees.com.ar","55","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES ("57","http://www.pal.ae","52","0","external");
INSERT INTO `wp_yoast_seo_links` VALUES ("58","http://tribecaloftsnyc.com","374","0","external");


CREATE TABLE IF NOT EXISTS `wp_yoast_seo_meta` (
  `object_id` bigint(20) unsigned NOT NULL,
  `internal_link_count` int(10) unsigned DEFAULT NULL,
  `incoming_link_count` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_yoast_seo_meta` VALUES ("1","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("16","1","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("25","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("35","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("37","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("42","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("51","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("52","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("55","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("92","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("94","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("160","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("168","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("242","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("250","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("265","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("272","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("296","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("316","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("327","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("334","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("339","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("350","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("351","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("353","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("354","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("361","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("367","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("374","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES ("382","0","0");




